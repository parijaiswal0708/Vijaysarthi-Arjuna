-- =========================================================
-- SUPABASE DATABASE SCHEMA FOR E-CELL & NEC 2026 PLATFORM
-- Execute this SQL script in your Supabase SQL Editor:
-- https://app.supabase.com/project/_/sql
-- =========================================================

-- Enable UUID extension if needed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ---------------------------------------------------------
-- 1. TEAM MEMBERS TABLE
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.team_members (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('core', 'domain', 'member')),
  department TEXT NOT NULL,
  year TEXT,
  domain TEXT,
  image TEXT NOT NULL,
  description TEXT NOT NULL,
  linkedin TEXT DEFAULT '',
  instagram TEXT DEFAULT '',
  email TEXT DEFAULT '',
  featured BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------------------------------------------------------
-- 2. GALLERY ITEMS TABLE
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.gallery_items (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('image', 'video')),
  category TEXT NOT NULL,
  url TEXT NOT NULL,
  thumbnail TEXT,
  youtube_id TEXT,
  upload_date TEXT NOT NULL,
  featured BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------------------------------------------------------
-- 3. RESOURCES TABLE
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.resources (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size TEXT NOT NULL,
  download_url TEXT NOT NULL,
  upload_date TEXT NOT NULL,
  tags TEXT[] DEFAULT '{}',
  downloads_count INT DEFAULT 0,
  preview_summary TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------------------------------------------------------
-- 4. MILESTONES TABLE
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.milestones (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  phase TEXT NOT NULL,
  date TEXT NOT NULL,
  status TEXT NOT NULL,
  description TEXT NOT NULL,
  deliverables TEXT[] DEFAULT '{}',
  impact_score INT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------------------------------------------------------
-- 5. FAQS TABLE
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.faqs (
  id TEXT PRIMARY KEY,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  category TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------------------------------------------------------
-- 6. CONTACT MESSAGES TABLE
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.contact_messages (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  subject TEXT DEFAULT 'General Inquiry',
  message TEXT NOT NULL,
  timestamp TEXT NOT NULL,
  replied BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------------------------------------------------------
-- 7. EVENTS TABLE
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.events (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  tagline TEXT NOT NULL,
  category TEXT NOT NULL,
  status TEXT NOT NULL,
  date TEXT NOT NULL,
  time TEXT,
  venue TEXT NOT NULL,
  prize_pool TEXT,
  description TEXT NOT NULL,
  highlights TEXT[] DEFAULT '{}',
  eligibility TEXT,
  luma_event_id TEXT,
  luma_url TEXT,
  image_url TEXT,
  is_featured BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------------------------------------------------------
-- 8. APP SETTINGS TABLE
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.app_settings (
  id TEXT PRIMARY KEY DEFAULT 'global',
  sound_enabled BOOLEAN DEFAULT true,
  particle_density TEXT DEFAULT 'medium',
  font_size_scale TEXT DEFAULT 'normal',
  reduced_motion BOOLEAN DEFAULT false,
  high_contrast BOOLEAN DEFAULT false,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ---------------------------------------------------------
-- ENABLE ROW LEVEL SECURITY (RLS) & SET POLICIES
-- ---------------------------------------------------------
ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gallery_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.milestones ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.faqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

-- Create permissive RLS policies allowing public read & admin write operations
DROP POLICY IF EXISTS "Public Read Team Members" ON public.team_members;
CREATE POLICY "Public Read Team Members" ON public.team_members FOR SELECT USING (true);
CREATE POLICY "Public Write Team Members" ON public.team_members FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public Read Gallery" ON public.gallery_items;
CREATE POLICY "Public Read Gallery" ON public.gallery_items FOR SELECT USING (true);
CREATE POLICY "Public Write Gallery" ON public.gallery_items FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public Read Resources" ON public.resources;
CREATE POLICY "Public Read Resources" ON public.resources FOR SELECT USING (true);
CREATE POLICY "Public Write Resources" ON public.resources FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public Read Milestones" ON public.milestones;
CREATE POLICY "Public Read Milestones" ON public.milestones FOR SELECT USING (true);
CREATE POLICY "Public Write Milestones" ON public.milestones FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public Read FAQs" ON public.faqs;
CREATE POLICY "Public Read FAQs" ON public.faqs FOR SELECT USING (true);
CREATE POLICY "Public Write FAQs" ON public.faqs FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public Read Contact Messages" ON public.contact_messages;
CREATE POLICY "Public Read Contact Messages" ON public.contact_messages FOR SELECT USING (true);
CREATE POLICY "Public Write Contact Messages" ON public.contact_messages FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public Read Events" ON public.events;
CREATE POLICY "Public Read Events" ON public.events FOR SELECT USING (true);
CREATE POLICY "Public Write Events" ON public.events FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public Read App Settings" ON public.app_settings;
CREATE POLICY "Public Read App Settings" ON public.app_settings FOR SELECT USING (true);
CREATE POLICY "Public Write App Settings" ON public.app_settings FOR ALL USING (true) WITH CHECK (true);

-- ---------------------------------------------------------
-- REALTIME PUBLICATION SETUP FOR INSTANT MULTI-USER SYNC
-- ---------------------------------------------------------
BEGIN;
  DROP PUBLICATION IF EXISTS supabase_realtime;
  CREATE PUBLICATION supabase_realtime FOR ALL TABLES;
COMMIT;
