import { TeamMember, GalleryItem, ResourceItem, FAQItem, MilestoneItem, ContactMessage, EventItem } from '../types';

export const initialTeamMembers: TeamMember[] = [
  // Core Team (4 Members - 2x2 layout)
  {
    id: 'core-1',
    name: 'Kartik Tayade',
    role: 'President',
    category: 'core',
    department: 'DIC',
    year: 'Third Year',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=600',
    description: 'Leading Vijaysarthi Arjuna with strategic foresight and driving operational excellence across all NEC modules.',
    linkedin: 'https://linkedin.com/in/tejas-deshmukh-ghrce',
    instagram: 'https://instagram.com/tejas_deshmukh_01',
    email: 'tejas.deshmukh@ghrce.edu.in',
    featured: true
  },
  {
    id: 'core-2',
    name: 'Ananya Sharma',
    role: 'Head of Operations & Strategy',
    category: 'core',
    department: 'Information Technology',
    year: 'Final Year',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=600',
    description: 'Orchestrating campus outreach, execution strategies, and institutional partnerships for E-Cell GHRCE.',
    linkedin: 'https://linkedin.com/in/ananya-sharma-ghrce',
    instagram: 'https://instagram.com/ananya_sharma_ecell',
    email: 'ananya.sharma@ghrce.edu.in',
    featured: true
  },
  {
    id: 'core-3',
    name: 'Rohan Kulkarni',
    role: 'Technical & Product Lead',
    category: 'core',
    department: 'Artificial Intelligence & Data Science',
    year: 'Pre-Final Year',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=600',
    description: 'Architecting digital platforms, portal systems, and AI tools for NEC innovation tracks.',
    linkedin: 'https://linkedin.com/in/rohan-kulkarni-tech',
    instagram: 'https://instagram.com/rohan_kulkarni_tech',
    email: 'rohan.kulkarni@ghrce.edu.in',
    featured: true
  },
  {
    id: 'core-4',
    name: 'Priya Verma',
    role: 'Finance & Venture Relations Lead',
    category: 'core',
    department: 'Electronics Engineering',
    year: 'Final Year',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=600',
    description: 'Managing financial planning, startup funding proposals, and angel investor liaisoning.',
    linkedin: 'https://linkedin.com/in/priya-verma-finance',
    instagram: 'https://instagram.com/priya_verma_ecell',
    email: 'priya.verma@ghrce.edu.in',
    featured: true
  },

  // Domain Leads (9 Members)
  {
    id: 'domain-1',
    name: 'Aditya Patil',
    role: 'Tech Lead',
    category: 'domain',
    domain: 'Technology',
    department: 'Computer Science',
    year: 'Pre-Final Year',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=600',
    description: 'Managing full-stack web architectures, server pipelines, and web performance.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'aditya.p@ghrce.edu.in'
  },
  {
    id: 'domain-2',
    name: 'Snehil Gupta',
    role: 'Marketing & Growth Lead',
    category: 'domain',
    domain: 'Marketing',
    department: 'Management Studies',
    year: 'Pre-Final Year',
    image: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&q=80&w=600',
    description: 'Spearheading viral social media campaigns, brand messaging, and student engagement.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'snehil.g@ghrce.edu.in'
  },
  {
    id: 'domain-3',
    name: 'Kavya Nair',
    role: 'Design & UI/UX Lead',
    category: 'domain',
    domain: 'Design',
    department: 'Mechanical Engineering',
    year: 'Pre-Final Year',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=600',
    description: 'Crafting brand guidelines, visual identity, UI components, and pitch deck visual design.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'kavya.n@ghrce.edu.in'
  },
  {
    id: 'domain-4',
    name: 'Siddharth Joshi',
    role: 'Public Relations & Sponsorship Lead',
    category: 'domain',
    domain: 'PR & Sponsorship',
    department: 'Civil Engineering',
    year: 'Pre-Final Year',
    image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=600',
    description: 'Securing corporate sponsors, media coverage, and inter-collegiate alliances.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'siddharth.j@ghrce.edu.in'
  },
  {
    id: 'domain-5',
    name: 'Shreya Mehta',
    role: 'Events & Workshop Lead',
    category: 'domain',
    domain: 'Events',
    department: 'Information Technology',
    year: 'Pre-Final Year',
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=600',
    description: 'Organizing bootcamps, hackathons, and founder speaker sessions at GHRCE.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'shreya.m@ghrce.edu.in'
  },
  {
    id: 'domain-6',
    name: 'Aarav Bhonsle',
    role: 'Research & Content Lead',
    category: 'domain',
    domain: 'Content',
    department: 'Electrical Engineering',
    year: 'Pre-Final Year',
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=600',
    description: 'Curating submission reports, market research whitepapers, and editorial copy.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'aarav.b@ghrce.edu.in'
  },
  {
    id: 'domain-7',
    name: 'Tanvi Saxena',
    role: 'Incubation & Startup Relations Lead',
    category: 'domain',
    domain: 'Incubation',
    department: 'Biotech Engineering',
    year: 'Pre-Final Year',
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=600',
    description: 'Facilitating campus startup mentorship, IPR support, and incubation grants.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'tanvi.s@ghrce.edu.in'
  },
  {
    id: 'domain-8',
    name: 'Nikhil Rane',
    role: 'Logistics & Infrastructure Lead',
    category: 'domain',
    domain: 'Logistics',
    department: 'Mechanical Engineering',
    year: 'Pre-Final Year',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=600',
    description: 'Managing venue arrangements, equipment setup, and event logistics.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'nikhil.r@ghrce.edu.in'
  },
  {
    id: 'domain-9',
    name: 'Meera Deshpande',
    role: 'Community & Alumni Network Lead',
    category: 'domain',
    domain: 'Community',
    department: 'Computer Science',
    year: 'Pre-Final Year',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=600',
    description: 'Connecting GHRCE alumni entrepreneurs with student teams for advisory sessions.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'meera.d@ghrce.edu.in'
  },

  // Additional Team Members
  {
    id: 'member-1',
    name: 'Kunal Deshmukh',
    role: 'Frontend Developer',
    category: 'member',
    department: 'CSE',
    year: '2nd Year',
    image: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=600',
    description: 'Building responsive UI components and canvas interactions.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'kunal@ghrce.edu.in'
  },
  {
    id: 'member-2',
    name: 'Riddhi Wagh',
    role: 'Social Media Manager',
    category: 'member',
    department: 'IT',
    year: '2nd Year',
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=600',
    description: 'Managing Instagram reels and LinkedIn campaign outreach.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'riddhi@ghrce.edu.in'
  },
  {
    id: 'member-3',
    name: 'Varun Kulkarni',
    role: 'Video & Motion Graphics Specialist',
    category: 'member',
    department: 'Electronics',
    year: '2nd Year',
    image: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?auto=format&fit=crop&q=80&w=600',
    description: 'Editing NEC pitch videos, promotional teasers, and event recaps.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'varun@ghrce.edu.in'
  },
  {
    id: 'member-4',
    name: 'Saniya Mirza',
    role: 'Content Strategist',
    category: 'member',
    department: 'Civil',
    year: '2nd Year',
    image: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&q=80&w=600',
    description: 'Drafting press releases, email newsletters, and presentation scripts.',
    linkedin: 'https://linkedin.com',
    instagram: 'https://instagram.com',
    email: 'saniya@ghrce.edu.in'
  }
];

export const initialGalleryItems: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'National Entrepreneurship Challenge Orientation at GHRCE',
    description: 'Inaugural session of Vijaysarthi Arjuna setting the milestone roadmap for IIT Bombay NEC 2026.',
    type: 'image',
    category: 'Featured Photos',
    url: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&q=80&w=1200',
    uploadDate: '2026-07-15',
    featured: true
  },
  {
    id: 'gal-2',
    title: 'E-Cell GHRCE Innovation Summit 2026',
    description: 'Keynote address by leading venture capitalists and startup founders hosted at GHRCE Nagpur campus.',
    type: 'image',
    category: 'Achievements',
    url: 'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?auto=format&fit=crop&q=80&w=1200',
    uploadDate: '2026-06-20',
    featured: true
  },
  {
    id: 'gal-3',
    title: 'Vijaysarthi Arjuna Brand Launch Teaser Video',
    description: 'Official video release detailing the Fight, Aim, Win spirit representing GHRCE at IIT Bombay.',
    type: 'video',
    category: 'Featured Videos',
    url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    youtubeId: 'dQw4w9WgXcQ',
    thumbnail: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=1200',
    uploadDate: '2026-07-28',
    featured: true
  },
  {
    id: 'gal-4',
    title: 'Campus Pitching Competition Winners',
    description: 'Top student teams receiving seed grants and mentorship from GHRCE Incubation Center.',
    type: 'image',
    category: 'Achievements',
    url: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&q=80&w=1200',
    uploadDate: '2026-05-10',
    featured: false
  },
  {
    id: 'gal-5',
    title: 'Design Thinking & B-Plan Workshop',
    description: 'Hands-on practical bootcamp covering business model canvas, financial projections, and GTM strategy.',
    type: 'image',
    category: 'Workshops',
    url: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80&w=1200',
    uploadDate: '2026-06-05',
    featured: false
  },
  {
    id: 'gal-6',
    title: 'IIT Bombay NEC Track Phase 1 Review Highlights',
    description: 'Behind-the-scenes video documentary of Vijaysarthi Arjuna preparing team submissions.',
    type: 'video',
    category: 'Featured Videos',
    url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    youtubeId: 'dQw4w9WgXcQ',
    thumbnail: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=1200',
    uploadDate: '2026-07-02',
    featured: false
  }
];

export const initialResources: ResourceItem[] = [
  {
    id: 'res-1',
    title: 'Brand Your E-Cell',
    description: 'Designed a comprehensive branding strategy for VijaySarthi Arjuna, establishing a distinctive identity through visual branding, storytelling, and a structured entrepreneurship-focused content calendar.',
    category: 'Preliminary Task',
    fileType: 'pdf',
    fileSize: '4.2 MB',
    downloadUrl: '#',
    uploadDate: '23 July 2026',
    tags: ['Branding', 'Identity', 'Content Strategy', 'Social Media'],
    downloadsCount: 342,
    previewSummary: 'Established the official brand identity and four-month content strategy that became the foundation of our digital presence throughout NEC 2026.'
  },
  {
    id: 'res-2',
    title: 'Draft a Work Report',
    description: 'A strategic execution blueprint outlining team structure, departmental responsibilities, operational workflows, and the roadmap for achieving milestones throughout the National Entrepreneurship Challenge.',
    category: 'Preliminary Task',
    fileType: 'pdf',
    fileSize: '2.4 MB',
    downloadUrl: '#',
    uploadDate: '22 July 2026',
    tags: ['Planning', 'Operations', 'Documentation', 'Execution'],
    downloadsCount: 512,
    previewSummary: 'Created the operational framework that aligned every team member with clear responsibilities, objectives, and execution timelines.'
  },
  {
    id: 'res-3',
    title: 'Idea Box',
    description: 'Developed and executed a dedicated entrepreneurship awareness campaign through Instagram, delivering educational content, startup insights, and engaging social media initiatives to inspire future innovators.',
    category: 'Preliminary Task',
    fileType: 'pdf',
    fileSize: '3.1 MB',
    downloadUrl: '#',
    uploadDate: '22 July 2026',
    tags: ['Networking', 'Community', 'Collaboration', 'Engagement'],
    downloadsCount: 680,
    previewSummary: 'Successfully published an eight-post entrepreneurship series to strengthen awareness, engagement, and the digital reach of VijaySarthi Arjuna.'
  },
  {
    id: 'res-4',
    title: 'Head Start Challenge',
    description: 'Strengthened team collaboration through virtual engagement, nationwide networking, and cross-campus outreach while expanding the entrepreneurial community beyond GHRCE.',
    category: 'Preliminary Task',
    fileType: 'pdf',
    fileSize: '1.8 MB',
    downloadUrl: '#',
    uploadDate: '22 July 2026',
    tags: ['Networking', 'Community', 'Collaboration', 'Engagement'],
    downloadsCount: 219,
    previewSummary: 'Connected students across multiple institutions through collaborative social campaigns, expanding the reach of the National Entrepreneurship Challenge.'
  },
  {
    id: 'res-5',
    title: 'Know Your Surroundings',
    description: 'Conducted a comprehensive campus-wide survey to identify entrepreneurial challenges, opportunities, and problem statements while curating actionable solutions based on collected responses.',
    category: 'Preliminary Task',
    fileType: 'pdf',
    fileSize: '3.5 MB',
    downloadUrl: '#',
    uploadDate: '16 July 2026',
    tags: ['Survey', 'Research', 'Problem Solving', 'Innovation'],
    downloadsCount: 890,
    previewSummary: 'Converted community insights into practical solutions by analyzing local challenges and validating opportunities through structured research.'
  },
  {
    id: 'res-6',
    title: 'Gather Insights',
    description: 'Collected stakeholder feedback, analyzed previous participant experiences, and developed a strategic action plan to improve future entrepreneurial initiatives, event execution, and participant engagement.',
    category: 'Preliminary Task',
    fileType: 'pdf',
    fileSize: '2.9 MB',
    downloadUrl: '#',
    uploadDate: '29 July 2026',
    tags: ['Stakeholders', 'Analytics', 'Strategy', 'Improvement'],
    downloadsCount: 415,
    previewSummary: 'Transformed stakeholder feedback into a data-driven roadmap for continuous improvement, mentorship, collaboration, and ecosystem growth.'
  }
];

export const initialMilestones: MilestoneItem[] = [
  {
    id: 'm-1',
    title: 'Preliminary Task Submission',
    phase: 'Phase 1 - Preliminary Challenge',
    date: '28 June – 2 August 2026',
    status: 'Under Evaluation',
    description: 'The first milestone of our NEC 2026 journey focused on team formation, branding, social media activation, documentation, and establishing a strong entrepreneurial foundation at GHRCE.',
    deliverables: [
      'Team Registration & Formation',
      'Brand Identity & Digital Presence',
      'Social Media Initiatives',
      'Preliminary Task Report Submission'
    ],
    impactScore: 98
  },
  {
    id: 'm-2',
    title: 'Mentor Allotment & Ignite Propel',
    phase: 'Phase 02 • Ignite Propel',
    date: '3 August – 14 September 2026',
    status: 'Upcoming',
    description: 'With mentor guidance from IIT Bombay, this phase focuses on strengthening the entrepreneurial ecosystem through structured activities, execution, and innovation.',
    deliverables: [
      'Mentor Allocation',
      'Ignite Propel Task Execution',
      'Activity Documentation',
      'Phase Submission Report'
    ],
    impactScore: 95
  },
  {
    id: 'm-3',
    title: 'Venture Quest Challenge',
    phase: 'Phase 03 • Venture Quest',
    date: '15 September – 16 October 2026',
    status: 'Upcoming',
    description: 'The final execution phase where teams undertake advanced entrepreneurial activities and complete the Venture Quest challenge.',
    deliverables: [
      'Venture Quest Activities',
      'Innovation Reports',
      'Final Documentation',
      'Task Submission'
    ],
    impactScore: 99
  },
  {
    id: 'm-4',
    title: 'Leaderboard & Finalist Announcement',
    phase: 'Phase 04 • National Evaluation',
    date: '22 October – 24 October 2026',
    status: 'Upcoming',
    description: 'The national evaluation determines the highest-performing teams, followed by the announcement of finalists advancing to the Grand Finale.',
    deliverables: [
      'National Leaderboard',
      'Final Evaluation',
      'Finalist Selection'
    ],
    impactScore: 92
  },
  {
    id: 'm-5',
    title: 'National Grand Finale',
    phase: 'Phase 05 • Grand Finale',
    date: 'E-Summit 2026 • IIT Bombay',
    status: 'Upcoming',
    description: 'The concluding stage of the National Entrepreneurship Challenge, where finalist teams present their journey before entrepreneurs, investors, and industry leaders at IIT Bombay.',
    deliverables: [
      'Grand Finale Presentation',
      'Jury Evaluation',
      'National Recognition'
    ],
    impactScore: 100
  }
];

export const initialFAQs: FAQItem[] = [
  {
    id: 'faq-1',
    question: 'What is Vijaysarthi Arjuna?',
    answer: 'Vijaysarthi Arjuna is the official flagship team representing G.H. Raisoni College of Engineering (GHRCE), Nagpur, at IIT Bombay’s National Entrepreneurship Challenge (NEC) 2026. The name symbolizes the unyielding focus and determination of Arjuna paired with strategic leadership.',
    category: 'General'
  },
  {
    id: 'faq-2',
    question: 'What is the National Entrepreneurship Challenge (NEC) by IIT Bombay?',
    answer: 'NEC is India’s largest pan-India competition organized by E-Cell, IIT Bombay, designed to foster, incentivize, and establish vibrant entrepreneurial ecosystems across engineering and management colleges nationwide.',
    category: 'NEC 2026'
  },
  {
    id: 'faq-3',
    question: 'How can GHRCE students participate or join Team Vijaysarthi Arjuna?',
    answer: 'Students can join through our regular recruitment drives, volunteering for E-Cell workshops, or applying for specialized domain roles (Tech, Content, Events, Marketing, Design) on the Team page or by contacting us.',
    category: 'Team & E-Cell'
  },
  {
    id: 'faq-4',
    question: 'Where can I access submission reports, pitch decks, and resources?',
    answer: 'All public submission decks, guidelines, startup policy documents, and toolkits are available for free download on our Resources page.',
    category: 'Submissions'
  }
];

export const initialContactMessages: ContactMessage[] = [
  {
    id: 'msg-1',
    email: 'investor.relations@ecell.in',
    subject: 'Mentorship Collaboration Inquiry',
    message: 'Interested in conducting a guest speaker session for GHRCE student founders in August 2026.',
    timestamp: '2026-07-29 14:32:00',
    replied: true
  },
  {
    id: 'msg-2',
    email: 'student.founder@ghrce.edu.in',
    subject: 'Incubation Support Application',
    message: 'We have an AI prototype in healthcare and would like guidance from Team Vijaysarthi Arjuna for IPR filing.',
    timestamp: '2026-08-01 09:15:22',
    replied: false
  }
];

export const initialEvents: EventItem[] = [
  {
    id: 'eureka-2026',
    title: 'Eureka! 2026',
    tagline: "Asia's Largest Business Model & Startup Competition",
    category: 'Flagship',
    status: 'Registration Open',
    date: 'February 2026 - March 2026',
    time: '10:00 AM IST onwards',
    venue: 'GHRCE Campus & Online Hybrid',
    prizePool: '₹5,00,000+ Incubation Perks & Cash Grants',
    description:
      'Eureka! is the flagship business model competition organized by Vijaysarthi Arjuna (E-Cell GHRCE) in collaboration with IIT Bombay’s National Entrepreneurship Challenge (NEC). It bridges the gap between visionary student ideas and market-ready startups through intensive mentorship, pitch training, investor exposure, and funding grants.',
    highlights: [
      '1-on-1 Mentorship with IIT Bombay Alumni & VCs',
      'Direct Pitching Opportunity to Angel Investors',
      'Free Cloud Credits, Incubation & Legal Support',
      'National Finals Representation at IIT Bombay E-Summit',
    ],
    eligibility: 'Open to all School/College students, Innovators & Early-Stage Startups',
    lumaEventId: 'evt-3hgeOcdbkW0vOQn',
    lumaUrl: 'https://luma.com/event/evt-3hgeOcdbkW0vOQn',
    imageUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&q=80&w=1200',
    isFeatured: true,
  },
  {
    id: 'ipl-auction-2026',
    title: 'IPL Bidding & Valuation Challenge',
    tagline: 'High-Stakes Strategic Auction & Financial Planning Simulation',
    category: 'Competition',
    status: 'Registration Open',
    date: 'February 25, 2026',
    time: '02:00 PM - 06:00 PM IST',
    venue: 'Auditorium 2, GHRCE Campus',
    prizePool: '₹15,00,000 Virtual Wallet • ₹15,000 Cash Prizes',
    description:
      'Test your analytical grit, team strategy, and quick decision-making under intense bidding pressure. Manage player stats, purse limits, and squad balance to construct a championship-winning team.',
    highlights: [
      'Real-time live auction bidding platform',
      'Data-driven squad evaluation analytics',
      'Certificates & Cash Rewards for Top 3 Franchises',
    ],
    eligibility: 'Teams of 2 to 4 members from any domain',
    lumaEventId: 'evt-3hgeOcdbkW0vOQn',
    lumaUrl: 'https://luma.com/event/evt-3hgeOcdbkW0vOQn',
    imageUrl: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'venture-quest-2026',
    title: 'Venture Quest Pitching Summit',
    tagline: '3-Minute Elevator Pitch to Seed Investors & Founders',
    category: 'Pitching',
    status: 'Upcoming',
    date: 'March 10, 2026',
    time: '11:00 AM IST',
    venue: 'Incubation Center, GHRCE',
    prizePool: 'Direct Seed Grant & Incubation Offer',
    description:
      'A fast-paced startup pitching arena where student founders present their pitch deck and prototype to a panel of venture capitalists, angel investors, and industry veterans.',
    highlights: [
      'Immediate Feedback from VC Panelists',
      'Networking Session with Angel Investors',
      'Spot Grants for Top Innovative Ideas',
    ],
    eligibility: 'Student Startups with a MVP or Validated Prototype',
    lumaEventId: 'evt-3hgeOcdbkW0vOQn',
    lumaUrl: 'https://luma.com/event/evt-3hgeOcdbkW0vOQn',
    imageUrl: 'https://images.unsplash.com/photo-1475721027785-f74eccf877e2?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'brand-your-ecell',
    title: 'Brand & Growth Hacking Masterclass',
    tagline: 'Building High-Impact Student Tech Brands & Digital PR',
    category: 'Workshop',
    status: 'Upcoming',
    date: 'March 18, 2026',
    time: '04:00 PM - 06:30 PM IST',
    venue: 'Seminar Hall B, GHRCE',
    prizePool: 'Certificates of Mastery & Swag Kits',
    description:
      'Learn modern digital storytelling, community building, design systems, and viral social media marketing techniques tailored for campus entrepreneurs and club leaders.',
    highlights: [
      'Hands-on Brand Kit Design Session',
      'Social Media Algorithm & PR Strategies',
      'Case Studies from Top IIT/IIM E-Cells',
    ],
    eligibility: 'Free for all registered GHRCE & NEC participants',
    lumaEventId: 'evt-3hgeOcdbkW0vOQn',
    lumaUrl: 'https://luma.com/event/evt-3hgeOcdbkW0vOQn',
    imageUrl: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80&w=1200',
  },
  {
    id: 'founders-fireside',
    title: "Founders' Fireside Chat & Q&A",
    tagline: 'Real Stories of Failure, Pivot, & Product-Market Fit',
    category: 'Speaker Series',
    status: 'Upcoming',
    date: 'April 02, 2026',
    time: '05:00 PM IST',
    venue: 'Main Campus Amphitheatre',
    prizePool: 'Mentorship & Networking',
    description:
      'An intimate, unfiltered conversation with alumni startup founders who turned campus projects into funded tech enterprises. Ask questions, build connections, and discover real founder insights.',
    highlights: [
      'Interactive Live Audience Q&A',
      '1-on-1 Networking Coffee Break',
      'Exclusive Mentorship Sign-ups',
    ],
    eligibility: 'Open to all students, faculty, and aspiring entrepreneurs',
    lumaEventId: 'evt-3hgeOcdbkW0vOQn',
    lumaUrl: 'https://luma.com/event/evt-3hgeOcdbkW0vOQn',
    imageUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=1200',
  },
];
