import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  PageRoute,
  TeamMember,
  GalleryItem,
  ResourceItem,
  MilestoneItem,
  FAQItem,
  ContactMessage,
  EventItem,
  SettingsState
} from '../types';
import {
  initialTeamMembers,
  initialGalleryItems,
  initialResources,
  initialMilestones,
  initialFAQs,
  initialContactMessages,
  initialEvents
} from '../data/seedData';
import {
  supabase,
  isSupabaseConfigured,
  mapTeamMemberFromDb,
  mapTeamMemberToDb,
  mapGalleryItemFromDb,
  mapGalleryItemToDb,
  mapResourceFromDb,
  mapResourceToDb,
  mapMilestoneFromDb,
  mapMilestoneToDb,
  mapFaqFromDb,
  mapFaqToDb,
  mapContactMessageFromDb,
  mapContactMessageToDb,
  mapEventFromDb,
  mapEventToDb,
  mapSettingsFromDb,
  mapSettingsToDb
} from '../lib/supabase';

export interface AppContextType {
  currentRoute: PageRoute;
  setCurrentRoute: (route: PageRoute, targetSectionId?: string) => void;
  isPageLoading: boolean;
  setIsPageLoading: (val: boolean) => void;
  loadingPageTitle: string;
  settings: SettingsState;
  updateSettings: (newSettings: Partial<SettingsState>) => void;
  isAdminLoggedIn: boolean;
  setIsAdminLoggedIn: (val: boolean) => void;
  showAdminModal: boolean;
  setShowAdminModal: (val: boolean) => void;
  showSettingsDrawer: boolean;
  setShowSettingsDrawer: (val: boolean) => void;
  showWhatIsNecModal: boolean;
  setShowWhatIsNecModal: (val: boolean) => void;
  showPartnerModal: boolean;
  setShowPartnerModal: (val: boolean) => void;

  // Supabase Database Status
  isSupabaseActive: boolean;
  syncStatus: 'synced' | 'syncing' | 'error' | 'offline';
  dbError: string | null;

  // Data collections
  teamMembers: TeamMember[];
  galleryItems: GalleryItem[];
  resources: ResourceItem[];
  milestones: MilestoneItem[];
  faqs: FAQItem[];
  contactMessages: ContactMessage[];
  events: EventItem[];

  // CRUD actions
  addTeamMember: (member: Omit<TeamMember, 'id'>) => Promise<void>;
  updateTeamMember: (id: string, member: Partial<TeamMember>) => Promise<void>;
  deleteTeamMember: (id: string) => Promise<void>;

  addGalleryItem: (item: Omit<GalleryItem, 'id'>) => Promise<void>;
  updateGalleryItem: (id: string, item: Partial<GalleryItem>) => Promise<void>;
  deleteGalleryItem: (id: string) => Promise<void>;

  addResource: (res: Omit<ResourceItem, 'id' | 'downloadsCount'>) => Promise<void>;
  updateResource: (id: string, res: Partial<ResourceItem>) => Promise<void>;
  deleteResource: (id: string) => Promise<void>;
  incrementResourceDownload: (id: string) => Promise<void>;

  addMilestone: (m: Omit<MilestoneItem, 'id'>) => Promise<void>;
  updateMilestone: (id: string, m: Partial<MilestoneItem>) => Promise<void>;
  deleteMilestone: (id: string) => Promise<void>;

  addFAQ: (faq: Omit<FAQItem, 'id'>) => Promise<void>;
  updateFAQ: (id: string, faq: Partial<FAQItem>) => Promise<void>;
  deleteFAQ: (id: string) => Promise<void>;

  addContactMessage: (email: string, message: string, subject?: string) => Promise<{ success: boolean; error?: string }>;
  markMessageReplied: (id: string) => Promise<void>;
  deleteContactMessage: (id: string) => Promise<void>;

  addEvent: (event: Omit<EventItem, 'id'>) => Promise<void>;
  updateEvent: (id: string, event: Partial<EventItem>) => Promise<void>;
  deleteEvent: (id: string) => Promise<void>;

  resetToDefaultData: () => Promise<void>;
  pushAllDataToSupabase: () => Promise<{ success: boolean; message: string }>;
  refetchAllData: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const defaultSettings: SettingsState = {
  soundEnabled: true,
  particleDensity: 'medium',
  fontSizeScale: 'normal',
  reducedMotion: false,
  highContrast: false,
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentRoute, setCurrentRouteState] = useState<PageRoute>('home');
  const [isPageLoading, setIsPageLoading] = useState<boolean>(true);
  const [loadingPageTitle, setLoadingPageTitle] = useState<string>('Home');

  // Supabase Database State
  const [isSupabaseActive] = useState<boolean>(isSupabaseConfigured);
  const [syncStatus, setSyncStatus] = useState<'synced' | 'syncing' | 'error' | 'offline'>('syncing');
  const [dbError, setDbError] = useState<string | null>(null);

  // Settings State
  const [settings, setSettingsState] = useState<SettingsState>(defaultSettings);

  // Auth & Modals State
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
  const [showAdminModal, setShowAdminModal] = useState<boolean>(false);
  const [showSettingsDrawer, setShowSettingsDrawer] = useState<boolean>(false);
  const [showWhatIsNecModal, setShowWhatIsNecModal] = useState<boolean>(false);
  const [showPartnerModal, setShowPartnerModal] = useState<boolean>(false);

  // Data Collections State
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>(initialTeamMembers);
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>(initialGalleryItems);
  const [resources, setResources] = useState<ResourceItem[]>(initialResources);
  const [milestones, setMilestones] = useState<MilestoneItem[]>(initialMilestones);
  const [faqs, setFaqs] = useState<FAQItem[]>(initialFAQs);
  const [contactMessages, setContactMessages] = useState<ContactMessage[]>(initialContactMessages);
  const [events, setEvents] = useState<EventItem[]>(initialEvents);

  // Navigation Helper
  const setCurrentRoute = (route: PageRoute, targetSectionId?: string) => {
    setCurrentRouteState(route);
    try {
      if (typeof window !== 'undefined') {
        if (window.location) {
          window.location.hash = route;
        }
        if (targetSectionId) {
          const yOffset = -90;
          let attempts = 0;
          const maxAttempts = 40;

          const tryScroll = () => {
            attempts++;
            const el = document.getElementById(targetSectionId);
            if (el) {
              const elementTop = el.getBoundingClientRect().top + window.pageYOffset;
              const targetY = Math.max(0, elementTop + yOffset);

              window.scrollTo({
                top: targetY,
                behavior: 'smooth',
              });

              setTimeout(() => {
                const freshEl = document.getElementById(targetSectionId);
                if (freshEl) {
                  const freshTop = freshEl.getBoundingClientRect().top + window.pageYOffset + yOffset;
                  window.scrollTo({ top: Math.max(0, freshTop), behavior: 'smooth' });
                }
              }, 400);

              setTimeout(() => {
                const finalEl = document.getElementById(targetSectionId);
                if (finalEl) {
                  const finalTop = finalEl.getBoundingClientRect().top + window.pageYOffset + yOffset;
                  window.scrollTo({ top: Math.max(0, finalTop), behavior: 'smooth' });
                }
              }, 750);
            } else if (attempts < maxAttempts) {
              setTimeout(tryScroll, 50);
            }
          };

          tryScroll();
        } else {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      }
    } catch (e) {
      console.warn('Navigation scroll or hash update ignored:', e);
    }
  };

  // Hash route listener
  useEffect(() => {
    const handleHashChange = () => {
      try {
        if (typeof window !== 'undefined' && window.location) {
          const rawHash = (window.location.hash || '').replace(/^#\/?/, '').trim();
          const cleanHash = rawHash.split('?')[0].toLowerCase();

          if (cleanHash === 'arjuna') {
            setShowSettingsDrawer(false);
            setShowAdminModal(true);
            setCurrentRouteState('home');
            window.location.hash = 'home';
          } else if (['home', 'team', 'nec-journey', 'resources', 'gallery', 'events'].includes(cleanHash)) {
            setCurrentRouteState(cleanHash as PageRoute);
          } else {
            setCurrentRouteState('home');
            window.location.hash = 'home';
          }
        }
      } catch (e) {
        console.warn('Hash change handler ignored:', e);
      }
    };

    handleHashChange();
    try {
      if (typeof window !== 'undefined') {
        window.addEventListener('hashchange', handleHashChange);
        window.addEventListener('popstate', handleHashChange);
        return () => {
          window.removeEventListener('hashchange', handleHashChange);
          window.removeEventListener('popstate', handleHashChange);
        };
      }
    } catch (e) {
      console.warn('Hash listener setup ignored:', e);
    }
  }, []);

  // Check Supabase session on mount
  useEffect(() => {
    if (!isSupabaseConfigured) return;

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        setIsAdminLoggedIn(true);
      }
    }).catch(err => {
      console.warn('Error fetching Supabase session:', err);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setIsAdminLoggedIn(true);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  // Helper to handle CRUD errors gracefully
  const handleCrudError = useCallback((actionName: string, err: any) => {
    console.warn(`Supabase ${actionName} notification:`, err);
    const msg = err?.message || 'Database action failed.';
    if (err?.code === '42P01' || msg.includes('does not exist') || msg.includes('relation')) {
      setDbError(`Table missing in Supabase. Run 'supabase-schema.sql' in Supabase SQL Editor.`);
    } else {
      setDbError(msg);
    }
  }, []);

  // Fetch all collections from Supabase & Auto-seed if empty
  const fetchAllData = useCallback(async () => {
    if (!isSupabaseConfigured) {
      setSyncStatus('offline');
      return;
    }

    setSyncStatus('syncing');
    let hasTableErrors = false;
    const tableErrorDetails: string[] = [];

    // Helper function to fetch or auto-seed each collection independently
    const syncCollection = async <T, DB>(
      tableName: string,
      mapperFromDb: (row: DB) => T,
      mapperToDb: (item: T) => any,
      initialData: T[],
      setState: (data: T[]) => void
    ) => {
      try {
        const { data, error } = await supabase.from(tableName).select('*');
        if (error) {
          console.warn(`Supabase collection '${tableName}' notice:`, error.message);
          hasTableErrors = true;
          tableErrorDetails.push(tableName);
          // Keep initial seed data in state so app functions normally
          setState(initialData);
          return;
        }

        if (data && data.length > 0) {
          setState(data.map(mapperFromDb));
        } else {
          // Table is empty, seed initial data
          const seedPayload = initialData.map(mapperToDb);
          const { error: seedErr } = await supabase.from(tableName).upsert(seedPayload);
          if (seedErr) {
            console.warn(`Supabase seed notice for '${tableName}':`, seedErr.message);
          }
          setState(initialData);
        }
      } catch (err: any) {
        console.warn(`Supabase '${tableName}' sync notice:`, err);
        hasTableErrors = true;
        tableErrorDetails.push(tableName);
        setState(initialData);
      }
    };

    // Sync all 7 content collections + 1 settings table
    await Promise.all([
      syncCollection('team_members', mapTeamMemberFromDb, mapTeamMemberToDb, initialTeamMembers, setTeamMembers),
      syncCollection('gallery_items', mapGalleryItemFromDb, mapGalleryItemToDb, initialGalleryItems, setGalleryItems),
      syncCollection('resources', mapResourceFromDb, mapResourceToDb, initialResources, setResources),
      syncCollection('milestones', mapMilestoneFromDb, mapMilestoneToDb, initialMilestones, setMilestones),
      syncCollection('faqs', mapFaqFromDb, mapFaqToDb, initialFAQs, setFaqs),
      syncCollection('contact_messages', mapContactMessageFromDb, mapContactMessageToDb, initialContactMessages, setContactMessages),
      syncCollection('events', mapEventFromDb, mapEventToDb, initialEvents, setEvents),
    ]);

    // App Settings
    try {
      const { data: setArr, error: setErr } = await supabase.from('app_settings').select('*').eq('id', 'global').maybeSingle();
      if (!setErr && setArr) {
        setSettingsState(mapSettingsFromDb(setArr));
      } else if (!setErr && !setArr) {
        await supabase.from('app_settings').upsert([mapSettingsToDb(defaultSettings)]);
        setSettingsState(defaultSettings);
      }
    } catch (e) {
      console.warn('App settings sync notice:', e);
    }

    if (hasTableErrors) {
      setSyncStatus('error');
      setDbError(
        `Tables (${tableErrorDetails.join(', ')}) not found in Supabase database. Please execute 'supabase-schema.sql' in your Supabase SQL Editor.`
      );
    } else {
      setSyncStatus('synced');
      setDbError(null);
    }
  }, []);

  // Initial load
  useEffect(() => {
    fetchAllData();
  }, [fetchAllData]);

  // Realtime multi-user synchronization channel
  useEffect(() => {
    if (!isSupabaseConfigured) return;

    const channel = supabase
      .channel('public-db-sync')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public' },
        (payload) => {
          console.log('Supabase Realtime update received:', payload);
          fetchAllData();
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          console.log('Supabase Realtime channel active');
          setSyncStatus('synced');
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchAllData]);

  // Update Settings in Supabase
  const updateSettings = async (newSettings: Partial<SettingsState>) => {
    const updated = { ...settings, ...newSettings };
    setSettingsState(updated);

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('app_settings').upsert([mapSettingsToDb(updated)]);
        if (error) throw error;
      } catch (err) {
        console.error('Failed to update app_settings in Supabase:', err);
      }
    }
  };

  // CRUD IMPLEMENTATIONS USING SUPABASE

  // 1. Team Members
  const addTeamMember = async (member: Omit<TeamMember, 'id'>) => {
    const newItem: TeamMember = { ...member, id: 'tm-' + Date.now() };
    setTeamMembers((prev) => [newItem, ...prev]);

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('team_members').insert([mapTeamMemberToDb(newItem)]);
        if (error) handleCrudError('addTeamMember', error);
      } catch (err: any) {
        handleCrudError('addTeamMember', err);
      }
    }
  };

  const updateTeamMember = async (id: string, updated: Partial<TeamMember>) => {
    setTeamMembers((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );

    if (isSupabaseConfigured) {
      try {
        const target = teamMembers.find((item) => item.id === id);
        if (target) {
          const merged = { ...target, ...updated };
          const { error } = await supabase.from('team_members').update(mapTeamMemberToDb(merged)).eq('id', id);
          if (error) handleCrudError('updateTeamMember', error);
        }
      } catch (err: any) {
        handleCrudError('updateTeamMember', err);
      }
    }
  };

  const deleteTeamMember = async (id: string) => {
    setTeamMembers((prev) => prev.filter((item) => item.id !== id));

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('team_members').delete().eq('id', id);
        if (error) handleCrudError('deleteTeamMember', error);
      } catch (err: any) {
        handleCrudError('deleteTeamMember', err);
      }
    }
  };

  // 2. Gallery Items
  const addGalleryItem = async (item: Omit<GalleryItem, 'id'>) => {
    const newItem: GalleryItem = { ...item, id: 'gal-' + Date.now() };
    setGalleryItems((prev) => [newItem, ...prev]);

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('gallery_items').insert([mapGalleryItemToDb(newItem)]);
        if (error) handleCrudError('addGalleryItem', error);
      } catch (err: any) {
        handleCrudError('addGalleryItem', err);
      }
    }
  };

  const updateGalleryItem = async (id: string, updated: Partial<GalleryItem>) => {
    setGalleryItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );

    if (isSupabaseConfigured) {
      try {
        const target = galleryItems.find((item) => item.id === id);
        if (target) {
          const merged = { ...target, ...updated };
          const { error } = await supabase.from('gallery_items').update(mapGalleryItemToDb(merged)).eq('id', id);
          if (error) handleCrudError('updateGalleryItem', error);
        }
      } catch (err: any) {
        handleCrudError('updateGalleryItem', err);
      }
    }
  };

  const deleteGalleryItem = async (id: string) => {
    setGalleryItems((prev) => prev.filter((item) => item.id !== id));

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('gallery_items').delete().eq('id', id);
        if (error) handleCrudError('deleteGalleryItem', error);
      } catch (err: any) {
        handleCrudError('deleteGalleryItem', err);
      }
    }
  };

  // 3. Resources
  const addResource = async (res: Omit<ResourceItem, 'id' | 'downloadsCount'>) => {
    const newItem: ResourceItem = {
      ...res,
      id: 'res-' + Date.now(),
      downloadsCount: 0,
    };
    setResources((prev) => [newItem, ...prev]);

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('resources').insert([mapResourceToDb(newItem)]);
        if (error) handleCrudError('addResource', error);
      } catch (err: any) {
        handleCrudError('addResource', err);
      }
    }
  };

  const updateResource = async (id: string, updated: Partial<ResourceItem>) => {
    setResources((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );

    if (isSupabaseConfigured) {
      try {
        const target = resources.find((item) => item.id === id);
        if (target) {
          const merged = { ...target, ...updated };
          const { error } = await supabase.from('resources').update(mapResourceToDb(merged)).eq('id', id);
          if (error) handleCrudError('updateResource', error);
        }
      } catch (err: any) {
        handleCrudError('updateResource', err);
      }
    }
  };

  const deleteResource = async (id: string) => {
    setResources((prev) => prev.filter((item) => item.id !== id));

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('resources').delete().eq('id', id);
        if (error) handleCrudError('deleteResource', error);
      } catch (err: any) {
        handleCrudError('deleteResource', err);
      }
    }
  };

  const incrementResourceDownload = async (id: string) => {
    setResources((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, downloadsCount: item.downloadsCount + 1 } : item
      )
    );

    if (isSupabaseConfigured) {
      try {
        const target = resources.find((item) => item.id === id);
        const newCount = (target?.downloadsCount || 0) + 1;
        const { error } = await supabase.from('resources').update({ downloads_count: newCount }).eq('id', id);
        if (error) handleCrudError('incrementResourceDownload', error);
      } catch (err: any) {
        handleCrudError('incrementResourceDownload', err);
      }
    }
  };

  // 4. Milestones
  const addMilestone = async (m: Omit<MilestoneItem, 'id'>) => {
    const newItem: MilestoneItem = { ...m, id: 'm-' + Date.now() };
    setMilestones((prev) => [...prev, newItem]);

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('milestones').insert([mapMilestoneToDb(newItem)]);
        if (error) handleCrudError('addMilestone', error);
      } catch (err: any) {
        handleCrudError('addMilestone', err);
      }
    }
  };

  const updateMilestone = async (id: string, updated: Partial<MilestoneItem>) => {
    setMilestones((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );

    if (isSupabaseConfigured) {
      try {
        const target = milestones.find((item) => item.id === id);
        if (target) {
          const merged = { ...target, ...updated };
          const { error } = await supabase.from('milestones').update(mapMilestoneToDb(merged)).eq('id', id);
          if (error) handleCrudError('updateMilestone', error);
        }
      } catch (err: any) {
        handleCrudError('updateMilestone', err);
      }
    }
  };

  const deleteMilestone = async (id: string) => {
    setMilestones((prev) => prev.filter((item) => item.id !== id));

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('milestones').delete().eq('id', id);
        if (error) handleCrudError('deleteMilestone', error);
      } catch (err: any) {
        handleCrudError('deleteMilestone', err);
      }
    }
  };

  // 5. FAQs
  const addFAQ = async (faq: Omit<FAQItem, 'id'>) => {
    const newItem: FAQItem = { ...faq, id: 'faq-' + Date.now() };
    setFaqs((prev) => [...prev, newItem]);

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('faqs').insert([mapFaqToDb(newItem)]);
        if (error) handleCrudError('addFAQ', error);
      } catch (err: any) {
        handleCrudError('addFAQ', err);
      }
    }
  };

  const updateFAQ = async (id: string, updated: Partial<FAQItem>) => {
    setFaqs((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );

    if (isSupabaseConfigured) {
      try {
        const target = faqs.find((item) => item.id === id);
        if (target) {
          const merged = { ...target, ...updated };
          const { error } = await supabase.from('faqs').update(mapFaqToDb(merged)).eq('id', id);
          if (error) handleCrudError('updateFAQ', error);
        }
      } catch (err: any) {
        handleCrudError('updateFAQ', err);
      }
    }
  };

  const deleteFAQ = async (id: string) => {
    setFaqs((prev) => prev.filter((item) => item.id !== id));

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('faqs').delete().eq('id', id);
        if (error) handleCrudError('deleteFAQ', error);
      } catch (err: any) {
        handleCrudError('deleteFAQ', err);
      }
    }
  };

  // 6. Contact Messages
  const addContactMessage = async (email: string, message: string, subject?: string): Promise<{ success: boolean; error?: string }> => {
    const newMsg: ContactMessage = {
      id: 'msg-' + Date.now(),
      email,
      subject: subject || 'General Inquiry',
      message,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      replied: false,
    };
    setContactMessages((prev) => [newMsg, ...prev]);

    if (isSupabaseConfigured) {
      try {
        // Attempt 1: Standard insert using full payload
        let { error } = await supabase.from('contact_messages').insert([mapContactMessageToDb(newMsg)]);

        // Attempt 2: If failed because 'timestamp' column is missing in user's schema
        if (error && (error.message.includes('timestamp') || error.code === '42703')) {
          console.warn('Retrying insert without timestamp column...');
          const retryRes = await supabase.from('contact_messages').insert([{
            id: newMsg.id,
            email: newMsg.email,
            subject: newMsg.subject,
            message: newMsg.message,
            replied: false,
          }]);
          error = retryRes.error;
        }

        // Attempt 3: If failed because custom string 'id' primary key mismatches uuid/int8
        if (error && (error.message.includes('id') || error.code === '22P02' || error.code === '42703')) {
          console.warn('Retrying insert letting Supabase generate primary key...');
          const retryRes = await supabase.from('contact_messages').insert([{
            email: newMsg.email,
            subject: newMsg.subject,
            message: newMsg.message,
            replied: false,
          }]);
          error = retryRes.error;
        }

        if (error) {
          console.error('Supabase addContactMessage error:', error);
          handleCrudError('addContactMessage', error);
          return { success: false, error: error.message };
        }
        return { success: true };
      } catch (err: any) {
        console.error('Supabase addContactMessage exception:', err);
        handleCrudError('addContactMessage', err);
        return { success: false, error: err?.message || 'Database connection error' };
      }
    }
    return { success: true };
  };

  const markMessageReplied = async (id: string) => {
    setContactMessages((prev) =>
      prev.map((m) => (m.id === id ? { ...m, replied: true } : m))
    );

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('contact_messages').update({ replied: true }).eq('id', id);
        if (error) handleCrudError('markMessageReplied', error);
      } catch (err: any) {
        handleCrudError('markMessageReplied', err);
      }
    }
  };

  const deleteContactMessage = async (id: string) => {
    setContactMessages((prev) => prev.filter((m) => m.id !== id));

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('contact_messages').delete().eq('id', id);
        if (error) handleCrudError('deleteContactMessage', error);
      } catch (err: any) {
        handleCrudError('deleteContactMessage', err);
      }
    }
  };

  // 7. Events
  const addEvent = async (event: Omit<EventItem, 'id'>) => {
    const newItem: EventItem = { ...event, id: 'evt-' + Date.now() };
    setEvents((prev) => [newItem, ...prev]);

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('events').insert([mapEventToDb(newItem)]);
        if (error) handleCrudError('addEvent', error);
      } catch (err: any) {
        handleCrudError('addEvent', err);
      }
    }
  };

  const updateEvent = async (id: string, updated: Partial<EventItem>) => {
    setEvents((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );

    if (isSupabaseConfigured) {
      try {
        const target = events.find((item) => item.id === id);
        if (target) {
          const merged = { ...target, ...updated };
          const { error } = await supabase.from('events').update(mapEventToDb(merged)).eq('id', id);
          if (error) handleCrudError('updateEvent', error);
        }
      } catch (err: any) {
        handleCrudError('updateEvent', err);
      }
    }
  };

  const deleteEvent = async (id: string) => {
    setEvents((prev) => prev.filter((item) => item.id !== id));

    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.from('events').delete().eq('id', id);
        if (error) handleCrudError('deleteEvent', error);
      } catch (err: any) {
        handleCrudError('deleteEvent', err);
      }
    }
  };

  // Reset to default seed data in Supabase & Local state
  const resetToDefaultData = async () => {
    setTeamMembers(initialTeamMembers);
    setGalleryItems(initialGalleryItems);
    setResources(initialResources);
    setMilestones(initialMilestones);
    setFaqs(initialFAQs);
    setContactMessages(initialContactMessages);
    setEvents(initialEvents);
    setSettingsState(defaultSettings);

    if (isSupabaseConfigured) {
      try {
        await Promise.all([
          supabase.from('team_members').delete().neq('id', ''),
          supabase.from('gallery_items').delete().neq('id', ''),
          supabase.from('resources').delete().neq('id', ''),
          supabase.from('milestones').delete().neq('id', ''),
          supabase.from('faqs').delete().neq('id', ''),
          supabase.from('contact_messages').delete().neq('id', ''),
          supabase.from('events').delete().neq('id', ''),
        ]);

        await Promise.all([
          supabase.from('team_members').upsert(initialTeamMembers.map(mapTeamMemberToDb)),
          supabase.from('gallery_items').upsert(initialGalleryItems.map(mapGalleryItemToDb)),
          supabase.from('resources').upsert(initialResources.map(mapResourceToDb)),
          supabase.from('milestones').upsert(initialMilestones.map(mapMilestoneToDb)),
          supabase.from('faqs').upsert(initialFAQs.map(mapFaqToDb)),
          supabase.from('contact_messages').upsert(initialContactMessages.map(mapContactMessageToDb)),
          supabase.from('events').upsert(initialEvents.map(mapEventToDb)),
          supabase.from('app_settings').upsert([mapSettingsToDb(defaultSettings)])
        ]);
        setSyncStatus('synced');
      } catch (err: any) {
        console.error('Supabase resetToDefaultData error:', err);
        setDbError(err.message);
      }
    }
  };

  const pushAllDataToSupabase = async (): Promise<{ success: boolean; message: string }> => {
    if (!isSupabaseConfigured) {
      return { success: false, message: 'Supabase credentials are not configured in environment.' };
    }

    try {
      setSyncStatus('syncing');
      
      const results = await Promise.all([
        teamMembers.length > 0 ? supabase.from('team_members').upsert(teamMembers.map(mapTeamMemberToDb)) : Promise.resolve({ error: null }),
        galleryItems.length > 0 ? supabase.from('gallery_items').upsert(galleryItems.map(mapGalleryItemToDb)) : Promise.resolve({ error: null }),
        resources.length > 0 ? supabase.from('resources').upsert(resources.map(mapResourceToDb)) : Promise.resolve({ error: null }),
        milestones.length > 0 ? supabase.from('milestones').upsert(milestones.map(mapMilestoneToDb)) : Promise.resolve({ error: null }),
        faqs.length > 0 ? supabase.from('faqs').upsert(faqs.map(mapFaqToDb)) : Promise.resolve({ error: null }),
        contactMessages.length > 0 ? supabase.from('contact_messages').upsert(contactMessages.map(mapContactMessageToDb)) : Promise.resolve({ error: null }),
        events.length > 0 ? supabase.from('events').upsert(events.map(mapEventToDb)) : Promise.resolve({ error: null }),
        supabase.from('app_settings').upsert([mapSettingsToDb(settings)])
      ]);

      const firstError = results.find(r => r.error);
      if (firstError && firstError.error) {
        throw firstError.error;
      }

      setSyncStatus('synced');
      setDbError(null);
      return { success: true, message: 'All local data and site settings successfully pushed to global Supabase database!' };
    } catch (err: any) {
      console.error('pushAllDataToSupabase error:', err);
      setSyncStatus('error');
      setDbError(err?.message || 'Failed to upload data to Supabase database.');
      return { success: false, message: err?.message || 'Failed to upload data to Supabase database.' };
    }
  };

  const refetchAllData = async (): Promise<void> => {
    await fetchAllData();
  };

  return (
    <AppContext.Provider
      value={{
        currentRoute,
        setCurrentRoute,
        isPageLoading,
        setIsPageLoading,
        loadingPageTitle,
        settings,
        updateSettings,
        isAdminLoggedIn,
        setIsAdminLoggedIn,
        showAdminModal,
        setShowAdminModal,
        showSettingsDrawer,
        setShowSettingsDrawer,
        showWhatIsNecModal,
        setShowWhatIsNecModal,
        showPartnerModal,
        setShowPartnerModal,
        isSupabaseActive,
        syncStatus,
        dbError,
        teamMembers,
        galleryItems,
        resources,
        milestones,
        faqs,
        contactMessages,
        events,
        addTeamMember,
        updateTeamMember,
        deleteTeamMember,
        addGalleryItem,
        updateGalleryItem,
        deleteGalleryItem,
        addResource,
        updateResource,
        deleteResource,
        incrementResourceDownload,
        addMilestone,
        updateMilestone,
        deleteMilestone,
        addFAQ,
        updateFAQ,
        deleteFAQ,
        addContactMessage,
        markMessageReplied,
        deleteContactMessage,
        addEvent,
        updateEvent,
        deleteEvent,
        resetToDefaultData,
        pushAllDataToSupabase,
        refetchAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
