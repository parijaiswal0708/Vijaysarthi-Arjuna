import React from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { SettingsDrawer } from './components/SettingsDrawer';
import { Modals } from './components/Modals';
import { PremiumBackground } from './components/PremiumBackground';
import { CursorLight } from './components/CursorLight';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Home } from './pages/Home';
import { NECJourney } from './pages/NECJourney';
import { Resources } from './pages/Resources';
import { Gallery } from './pages/Gallery';
import { Events } from './pages/Events';
import { Team } from './pages/Team';
import { AdminDashboard } from './pages/AdminDashboard';
import { BrandedPageLoader } from './components/BrandedPageLoader';

const MainContent: React.FC = () => {
  const { currentRoute, isPageLoading, setIsPageLoading, settings } = useApp();

  const fontScaleClass =
    settings.fontSizeScale === 'large'
      ? 'text-[1.05rem]'
      : settings.fontSizeScale === 'xlarge'
      ? 'text-[1.15rem]'
      : '';

  return (
    <div className={`min-h-screen flex flex-col relative text-slate-900 selection:bg-orange-100 selection:text-[#0D3B8C] overflow-x-hidden ${fontScaleClass}`}>
      {/* Arjuna Bow & Arrow Page Loader - Initial Launch Only */}
      <AnimatePresence>
        {isPageLoading && (
          <BrandedPageLoader
            key="initial-app-loader"
            pageName="Vijaysarthi Arjuna"
            onComplete={() => setIsPageLoading(false)}
          />
        )}
      </AnimatePresence>

      {/* Global Cursor Following Light Effect */}
      <CursorLight />

      {/* Global Layered Banner-Inspired Light Theme Background */}
      <PremiumBackground />

      <Header />

      <main className="flex-1 relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentRoute}
            initial={{ opacity: 0, y: 12, filter: 'blur(4px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -12, filter: 'blur(4px)' }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          >
            {currentRoute === 'home' && <Home />}
            {currentRoute === 'team' && <Team />}
            {currentRoute === 'nec-journey' && <NECJourney />}
            {currentRoute === 'resources' && <Resources />}
            {currentRoute === 'gallery' && <Gallery />}
            {currentRoute === 'events' && <Events />}
          </motion.div>
        </AnimatePresence>
      </main>

      <Footer />

      {/* Global Drawers & Modals */}
      <SettingsDrawer />
      <Modals />
      <AdminDashboard />
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <MainContent />
      </AppProvider>
    </ErrorBoundary>
  );
}

