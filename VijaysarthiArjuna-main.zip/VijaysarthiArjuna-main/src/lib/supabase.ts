import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  TeamMember,
  GalleryItem,
  ResourceItem,
  MilestoneItem,
  FAQItem,
  ContactMessage,
  EventItem,
  SettingsState
} from '../types';

// Retrieve environment variables safely
const metaEnv = (import.meta as any).env || {};
const rawSupabaseUrl = String(metaEnv.VITE_SUPABASE_URL || '');
const rawSupabaseAnonKey = String(metaEnv.VITE_SUPABASE_ANON_KEY || '');

function sanitizeSupabaseUrl(urlStr: string): string {
  if (!urlStr) return '';
  // Strip quotes, whitespace, /rest/v1 suffixes and trailing slashes
  let cleaned = urlStr.trim().replace(/^["']|["']$/g, '').trim();
  cleaned = cleaned.replace(/\/rest\/v1\/?$/, '').replace(/\/$/, '');
  
  if (cleaned && !cleaned.startsWith('http://') && !cleaned.startsWith('https://')) {
    cleaned = 'https://' + cleaned;
  }
  
  try {
    const parsed = new URL(cleaned);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
      return parsed.origin;
    }
  } catch {
    // Invalid URL format
  }
  return '';
}

function sanitizeAnonKey(keyStr: string): string {
  if (!keyStr) return '';
  return keyStr.trim().replace(/^["']|["']$/g, '').trim();
}

export const supabaseUrl = sanitizeSupabaseUrl(rawSupabaseUrl);
export const supabaseAnonKey = sanitizeAnonKey(rawSupabaseAnonKey);

// Check if credentials are properly configured
export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  supabaseAnonKey &&
  (supabaseUrl.startsWith('https://') || supabaseUrl.startsWith('http://')) &&
  !supabaseUrl.includes('example-project') &&
  !supabaseUrl.includes('placeholder.supabase.co') &&
  supabaseAnonKey !== 'your-supabase-anon-key' &&
  supabaseAnonKey !== 'placeholder-anon-key'
);

const effectiveUrl = (supabaseUrl && (supabaseUrl.startsWith('https://') || supabaseUrl.startsWith('http://')))
  ? supabaseUrl
  : 'https://placeholder.supabase.co';
const effectiveKey = supabaseAnonKey || 'placeholder-anon-key';

// Create Supabase client instance
export const supabase: SupabaseClient = createClient(
  effectiveUrl,
  effectiveKey,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    },
    realtime: {
      params: {
        eventsPerSecond: 10,
      },
    },
  }
);

// ============================================================================
// DATA MAPPERS (Snake_case DB columns <-> CamelCase TS Models)
// ============================================================================

export const mapTeamMemberFromDb = (row: any): TeamMember => ({
  id: row.id,
  name: row.name,
  role: row.role,
  category: row.category,
  department: row.department,
  year: row.year || undefined,
  domain: row.domain || undefined,
  image: row.image,
  description: row.description,
  linkedin: row.linkedin || '',
  instagram: row.instagram || '',
  email: row.email || '',
  featured: row.featured ?? false,
});

export const mapTeamMemberToDb = (member: TeamMember) => ({
  id: member.id,
  name: member.name,
  role: member.role,
  category: member.category,
  department: member.department,
  year: member.year || null,
  domain: member.domain || null,
  image: member.image,
  description: member.description,
  linkedin: member.linkedin || '',
  instagram: member.instagram || '',
  email: member.email || '',
  featured: member.featured ?? false,
});

export const mapGalleryItemFromDb = (row: any): GalleryItem => ({
  id: row.id,
  title: row.title,
  description: row.description,
  type: row.type,
  category: row.category,
  url: row.url,
  thumbnail: row.thumbnail || undefined,
  youtubeId: row.youtube_id || undefined,
  uploadDate: row.upload_date,
  featured: row.featured ?? false,
});

export const mapGalleryItemToDb = (item: GalleryItem) => ({
  id: item.id,
  title: item.title,
  description: item.description,
  type: item.type,
  category: item.category,
  url: item.url,
  thumbnail: item.thumbnail || null,
  youtube_id: item.youtubeId || null,
  upload_date: item.uploadDate,
  featured: item.featured ?? false,
});

export const mapResourceFromDb = (row: any): ResourceItem => ({
  id: row.id,
  title: row.title,
  description: row.description,
  category: row.category,
  fileType: row.file_type,
  fileSize: row.file_size,
  downloadUrl: row.download_url,
  uploadDate: row.upload_date,
  tags: row.tags || [],
  downloadsCount: row.downloads_count || 0,
  previewSummary: row.preview_summary || undefined,
});

export const mapResourceToDb = (res: ResourceItem) => ({
  id: res.id,
  title: res.title,
  description: res.description,
  category: res.category,
  file_type: res.fileType,
  file_size: res.fileSize,
  download_url: res.downloadUrl,
  upload_date: res.uploadDate,
  tags: res.tags || [],
  downloads_count: res.downloadsCount || 0,
  preview_summary: res.previewSummary || null,
});

export const mapMilestoneFromDb = (row: any): MilestoneItem => ({
  id: row.id,
  title: row.title,
  phase: row.phase,
  date: row.date,
  status: row.status,
  description: row.description,
  deliverables: row.deliverables || [],
  impactScore: row.impact_score || undefined,
});

export const mapMilestoneToDb = (m: MilestoneItem) => ({
  id: m.id,
  title: m.title,
  phase: m.phase,
  date: m.date,
  status: m.status,
  description: m.description,
  deliverables: m.deliverables || [],
  impact_score: m.impactScore || null,
});

export const mapFaqFromDb = (row: any): FAQItem => ({
  id: row.id,
  question: row.question,
  answer: row.answer,
  category: row.category,
});

export const mapFaqToDb = (faq: FAQItem) => ({
  id: faq.id,
  question: faq.question,
  answer: faq.answer,
  category: faq.category,
});

export const mapContactMessageFromDb = (row: any): ContactMessage => ({
  id: row.id,
  email: row.email,
  subject: row.subject || undefined,
  message: row.message,
  timestamp: row.timestamp,
  replied: row.replied ?? false,
});

export const mapContactMessageToDb = (msg: ContactMessage) => ({
  id: msg.id,
  email: msg.email,
  subject: msg.subject || 'General Inquiry',
  message: msg.message,
  timestamp: msg.timestamp,
  replied: msg.replied ?? false,
});

export const mapEventFromDb = (row: any): EventItem => ({
  id: row.id,
  title: row.title,
  tagline: row.tagline,
  category: row.category,
  status: row.status,
  date: row.date,
  time: row.time || undefined,
  venue: row.venue,
  prizePool: row.prize_pool || undefined,
  description: row.description,
  highlights: row.highlights || [],
  eligibility: row.eligibility || undefined,
  lumaEventId: row.luma_event_id || undefined,
  lumaUrl: row.luma_url || undefined,
  imageUrl: row.image_url || undefined,
  isFeatured: row.is_featured ?? false,
});

export const mapEventToDb = (evt: EventItem) => ({
  id: evt.id,
  title: evt.title,
  tagline: evt.tagline,
  category: evt.category,
  status: evt.status,
  date: evt.date,
  time: evt.time || null,
  venue: evt.venue,
  prize_pool: evt.prizePool || null,
  description: evt.description,
  highlights: evt.highlights || [],
  eligibility: evt.eligibility || null,
  luma_event_id: evt.lumaEventId || null,
  luma_url: evt.lumaUrl || null,
  image_url: evt.imageUrl || null,
  is_featured: evt.isFeatured ?? false,
});

export const mapSettingsFromDb = (row: any): SettingsState => ({
  soundEnabled: row.sound_enabled ?? true,
  particleDensity: row.particle_density || 'medium',
  fontSizeScale: row.font_size_scale || 'normal',
  reducedMotion: row.reduced_motion ?? false,
  highContrast: row.high_contrast ?? false,
});

export const mapSettingsToDb = (s: SettingsState) => ({
  id: 'global',
  sound_enabled: s.soundEnabled,
  particle_density: s.particleDensity,
  font_size_scale: s.fontSizeScale,
  reduced_motion: s.reducedMotion,
  high_contrast: s.highContrast,
  updated_at: new Date().toISOString(),
});
