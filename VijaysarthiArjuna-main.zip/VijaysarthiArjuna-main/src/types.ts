export type PageRoute = 'home' | 'team' | 'nec-journey' | 'resources' | 'gallery' | 'events';

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  category: 'core' | 'domain' | 'member';
  department: string;
  year?: string;
  domain?: string;
  image: string;
  description: string;
  linkedin: string;
  instagram: string;
  email: string;
  featured?: boolean;
}

export interface GalleryItem {
  id: string;
  title: string;
  description: string;
  type: 'image' | 'video';
  category: 'Achievements' | 'Featured Photos' | 'Featured Videos' | 'Workshops' | 'Events';
  url: string;
  thumbnail?: string;
  youtubeId?: string;
  uploadDate: string;
  featured?: boolean;
}

export interface ResourceItem {
  id: string;
  title: string;
  description: string;
  category: 'Announcements' | 'Preliminary Task' | 'Brand Your E-Cell' | 'Ignite Propel' | 'Venture Quest' | 'Grand Finale' | string;
  fileType: 'pdf' | 'pptx' | 'docx' | 'xlsx';
  fileSize: string;
  downloadUrl: string;
  uploadDate: string;
  tags: string[];
  downloadsCount: number;
  previewSummary?: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'General' | 'NEC 2026' | 'Submissions' | 'Team & E-Cell';
}

export interface MilestoneItem {
  id: string;
  title: string;
  phase: string;
  date: string;
  status: 'Completed' | 'Ongoing' | 'Upcoming' | 'Under Evaluation';
  description: string;
  deliverables: string[];
  impactScore?: number;
}

export interface ContactMessage {
  id: string;
  email: string;
  subject?: string;
  message: string;
  timestamp: string;
  replied?: boolean;
}

export interface EventItem {
  id: string;
  title: string;
  tagline: string;
  category: 'Flagship' | 'Competition' | 'Workshop' | 'Pitching' | 'Speaker Series' | string;
  status: 'Registration Open' | 'Upcoming' | 'Completed' | string;
  date: string;
  time?: string;
  venue: string;
  prizePool?: string;
  description: string;
  highlights: string[];
  eligibility?: string;
  lumaEventId?: string;
  lumaUrl?: string;
  imageUrl?: string;
  isFeatured?: boolean;
}

export interface SettingsState {
  soundEnabled: boolean;
  particleDensity: 'low' | 'medium' | 'high';
  fontSizeScale: 'normal' | 'large' | 'xlarge';
  reducedMotion: boolean;
  highContrast: boolean;
}
