import React from 'react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import { VijaysarthiArjunaLogo, ECellGhrceLogo } from './Logos';
import { Linkedin, Instagram, Mail, ArrowUp } from 'lucide-react';
import { PageRoute } from '../types';

export const Footer: React.FC = () => {
  const { setCurrentRoute } = useApp();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const quickLinks: { label: string; route: PageRoute; targetSectionId?: string }[] = [
    { label: 'Home', route: 'home' },
    { label: 'Core Team & Domain Leads', route: 'team' },
    { label: 'NEC Journey', route: 'nec-journey' },
    { label: 'Resources & PPTs', route: 'resources' },
    { label: 'Gallery & Highlights', route: 'gallery' },
    { label: 'Events & Competitions', route: 'events' },
    { label: 'Contact E-Cell Team', route: 'home', targetSectionId: 'terminal-contact-section' },
  ];

  const socialLinks = [
    {
      name: 'LinkedIn',
      href: 'https://www.linkedin.com/company/e-cell-ghrce/',
      icon: Linkedin,
      hoverBg: 'hover:bg-[#0D3B8C]',
    },
    {
      name: 'Instagram',
      href: 'https://www.instagram.com/ecellghrce?igsh=MW1hZGQ0NGRucDh6OQ==',
      icon: Instagram,
      hoverBg: 'hover:bg-[#F97316]',
    },
    {
      name: 'Email',
      href: 'mailto:vijaysarthiarjuna@gmail.com',
      icon: Mail,
      hoverBg: 'hover:bg-emerald-600',
    },
  ];

  return (
    <footer className="bg-slate-900 text-slate-300 relative overflow-hidden pt-16 pb-8 border-t-4 border-[#0D3B8C]">
      {/* Subtle Background Circuit Mesh */}
      <div className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(#F97316_1px,transparent_1px)] [background-size:24px_24px]"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 pb-12 border-b border-slate-800">
          {/* Column 1: Brand & Slogan - Fades in from Left */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-4"
          >
            <div
              className="flex items-center gap-3 cursor-pointer group"
              onClick={() => setCurrentRoute('home')}
            >
              <motion.div
                whileHover={{ scale: 1.06 }}
                transition={{ type: 'spring', stiffness: 400, damping: 20 }}
                className="flex items-center gap-3"
              >
                <VijaysarthiArjunaLogo size={64} showText={true} />
              </motion.div>
            </div>
            <div className="pt-2">
              <motion.div
                whileHover={{ scale: 1.06 }}
                transition={{ type: 'spring', stiffness: 400, damping: 20 }}
                className="inline-block cursor-pointer"
                onClick={() => setCurrentRoute('home')}
              >
                <ECellGhrceLogo size={75} lightText={true} />
              </motion.div>
            </div>
          </motion.div>

          {/* Column 2: Quick Links - Staggered Slide In */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-3"
          >
            <h4 className="text-sm font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              {quickLinks.map((link, idx) => (
                <motion.li
                  key={link.label}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: '-20px' }}
                  transition={{
                    duration: 0.4,
                    delay: idx * 0.08,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                >
                  <button
                    onClick={() => setCurrentRoute(link.route, link.targetSectionId)}
                    className="hover:text-[#F97316] transition-all flex items-center gap-1.5 group text-left cursor-pointer"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-700 group-hover:bg-[#F97316] transition-colors" />
                    <span className="group-hover:translate-x-1 transition-transform inline-block">
                      {link.label}
                    </span>
                  </button>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          {/* Column 3: Socials & Contact - Fades in from Right */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-3"
          >
            <h4 className="text-sm font-bold text-white uppercase tracking-wider border-b border-slate-800 pb-2">
              Connect With Us
            </h4>
            <div className="flex flex-wrap gap-2 pt-1">
              {socialLinks.map((s, idx) => {
                const IconComponent = s.icon;
                return (
                  <motion.a
                    key={s.name}
                    href={s.href}
                    target="_blank"
                    rel="noreferrer"
                    initial={{ opacity: 0, scale: 0.8, y: 10 }}
                    whileInView={{ opacity: 1, scale: 1, y: 0 }}
                    whileHover={{ scale: 1.1, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    viewport={{ once: true }}
                    transition={{
                      duration: 0.3,
                      delay: idx * 0.1,
                      ease: 'easeOut',
                    }}
                    className={`p-2.5 rounded-xl bg-slate-800 ${s.hoverBg} text-slate-300 hover:text-white border border-slate-700 transition-all shadow-sm`}
                    title={s.name}
                  >
                    <IconComponent className="w-4 h-4" />
                  </motion.a>
                );
              })}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="pt-2 text-xs text-slate-400 space-y-1"
            >
              <p>Email: vijaysarthiarjuna@gmail.com</p>
              <p>Location: GHRCE Campus, CRPF Gate No 3, Hingna Road, Nagpur, Maharashtra</p>
            </motion.div>
          </motion.div>
        </div>

        {/* Bottom Bar - Fades up on scroll */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-20px' }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="pt-8 flex flex-col sm:flex-row items-center justify-end gap-4 text-xs text-slate-500"
        >
          <div className="flex items-center gap-4">
            <span>IIT Bombay National Entrepreneurship Challenge 2026</span>
            <motion.button
              whileHover={{ scale: 1.15, y: -2 }}
              whileTap={{ scale: 0.9 }}
              onClick={scrollToTop}
              className="p-2 rounded-full bg-slate-800 hover:bg-[#0D3B8C] text-slate-300 hover:text-white transition-all border border-slate-700 shadow-md"
              title="Back to Top"
            >
              <ArrowUp className="w-4 h-4" />
            </motion.button>
          </div>
        </motion.div>
      </div>
    </footer>
  );
};
