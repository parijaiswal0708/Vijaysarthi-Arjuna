import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Code, Palette, Megaphone, Calendar, Users, Radio, Sparkles, ArrowUpRight } from 'lucide-react';

interface DomainCard {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  tags: string[];
  accentColor: string;
  gradient: string;
  icon: React.ReactNode;
  stat: string;
  statLabel: string;
  characterBg: string;
}

const DOMAINS: DomainCard[] = [
  {
    id: 'innovation-entrepreneurship',
    title: 'Innovation & Entrepreneurship',
    subtitle: 'Ideas In Motion',
    description: 'From identifying problems to validating ideas, we cultivate an entrepreneurial mindset that transforms possibilities into real-world solutions.',
    tags: ['Startups', 'Innovation', 'Ideation'],
    accentColor: '#0D3B8C',
    gradient: 'from-blue-600/90 to-indigo-900/90',
    icon: <Sparkles className="w-6 h-6 text-blue-400" />,
    stat: '100%',
    statLabel: 'Idea Validation',
    characterBg: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'tech-dev',
    title: 'Technology & Development',
    subtitle: 'Built with Technology',
    description: 'We design and develop digital solutions, interactive platforms, and scalable technologies that empower innovation and elevate every initiative.',
    tags: ['Development', 'UI/UX', 'Automation'],
    accentColor: '#F97316',
    gradient: 'from-orange-500/90 to-amber-700/90',
    icon: <Code className="w-6 h-6 text-orange-400" />,
    stat: '25+',
    statLabel: 'Tech Assets',
    characterBg: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'design-branding',
    title: 'Design & Branding',
    subtitle: 'Design That Speaks',
    description: 'From compelling visuals to cohesive brand experiences, we create designs that inspire, communicate, and leave a lasting impression.',
    tags: ['Branding', 'Design', 'Storytelling'],
    accentColor: '#8B5CF6',
    gradient: 'from-purple-600/90 to-violet-900/90',
    icon: <Palette className="w-6 h-6 text-purple-400" />,
    stat: '100%',
    statLabel: 'Brand Identity',
    characterBg: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'marketing-outreach',
    title: 'Marketing & Outreach',
    subtitle: 'Beyond the Campus',
    description: 'Through strategic campaigns and meaningful engagement, we connect ideas with communities and opportunities with aspiring innovators.',
    tags: ['Marketing', 'Growth', 'Community'],
    accentColor: '#10B981',
    gradient: 'from-emerald-600/90 to-teal-900/90',
    icon: <Megaphone className="w-6 h-6 text-emerald-400" />,
    stat: '10k+',
    statLabel: 'Students Reached',
    characterBg: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'leadership-ops',
    title: 'Leadership & Operations',
    subtitle: 'Driven by Leadership',
    description: 'Every milestone is backed by seamless planning, collaborative leadership, and efficient execution that turns vision into reality.',
    tags: ['Leadership', 'Planning', 'Execution'],
    accentColor: '#EC4899',
    gradient: 'from-pink-600/90 to-rose-900/90',
    icon: <Calendar className="w-6 h-6 text-pink-400" />,
    stat: '100%',
    statLabel: 'Execution Goal',
    characterBg: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=600&q=80',
  },
  {
    id: 'learning-collaboration',
    title: 'Learning & Collaboration',
    subtitle: 'Learn. Connect. Grow.',
    description: 'We believe growth begins with collaboration, mentorship, and continuous learning, empowering every member to innovate with confidence.',
    tags: ['Mentorship', 'Networking', 'Learning'],
    accentColor: '#0284C7',
    gradient: 'from-sky-600/90 to-blue-900/90',
    icon: <Users className="w-6 h-6 text-sky-400" />,
    stat: '500+',
    statLabel: 'Network Size',
    characterBg: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=600&q=80',
  },
];

export const ExploreDomains3D: React.FC = () => {
  const [activeCard, setActiveCard] = useState<string | null>(null);

  return (
    <section className="py-20 bg-transparent relative z-10 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Title & Subtitle */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-50 border border-blue-200/80 text-xs font-extrabold text-[#0D3B8C] uppercase tracking-widest shadow-sm">
            <span>Our Pillars</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight">
            Six driving forces behind every milestone we achieve
          </h2>
        </div>

        {/* 3D Cards Grid with Perspective */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 perspective-1000">
          {DOMAINS.map((domain) => {
            const isHovered = activeCard === domain.id;

            return (
              <div
                key={domain.id}
                className="relative group cursor-pointer h-[340px]"
                onMouseEnter={() => setActiveCard(domain.id)}
                onMouseLeave={() => setActiveCard(null)}
              >
                {/* Ambient Radial Glow Effect behind card */}
                <div
                  className="absolute -inset-4 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-2xl pointer-events-none -z-10"
                  style={{
                    background: `radial-gradient(circle, ${domain.accentColor}35 0%, transparent 70%)`,
                  }}
                />

                {/* 3D Tilting Card Container */}
                <motion.div
                  animate={
                    isHovered
                      ? { rotateX: 6, rotateY: -6, y: -8, scale: 1.02 }
                      : { rotateX: 0, rotateY: 0, y: 0, scale: 1 }
                  }
                  transition={{ type: 'spring', stiffness: 350, damping: 25 }}
                  className="w-full h-full rounded-3xl bg-white/90 backdrop-blur-xl border border-slate-200/90 shadow-xl group-hover:shadow-2xl overflow-hidden flex flex-col justify-between p-6 relative transform-style-3d group-hover:border-[#0D3B8C]/40 transition-colors duration-300"
                >
                  {/* Background Card Graphic Image Overlay with Blur & Darkening */}
                  <div
                    className="absolute inset-0 bg-cover bg-center opacity-10 group-hover:opacity-20 transition-opacity duration-500 rounded-3xl pointer-events-none"
                    style={{ backgroundImage: `url(${domain.characterBg})` }}
                  />

                  {/* Header Row */}
                  <div className="flex items-start justify-between relative z-10">
                    <div className="flex items-center gap-3">
                      <div className="p-3 rounded-2xl bg-slate-100 border border-slate-200/80 shadow-sm group-hover:scale-110 transition-transform duration-300">
                        {domain.icon}
                      </div>
                      <div>
                        <span className="text-[10px] font-extrabold text-[#F97316] uppercase tracking-widest block">
                          {domain.subtitle}
                        </span>
                        <h3 className="text-xl font-extrabold text-slate-900 group-hover:text-[#0D3B8C] transition-colors">
                          {domain.title}
                        </h3>
                      </div>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-slate-100/80 flex items-center justify-center text-slate-400 group-hover:bg-[#0D3B8C] group-hover:text-white transition-all duration-300">
                      <ArrowUpRight className="w-4 h-4" />
                    </div>
                  </div>

                  {/* Middle Description */}
                  <div className="relative z-10 my-3">
                    <p className="text-xs text-slate-600 leading-relaxed font-normal">
                      {domain.description}
                    </p>
                  </div>

                  {/* Tags & Metric Footer */}
                  <div className="relative z-10 pt-4 border-t border-slate-100 flex items-center justify-between">
                    <div className="flex flex-wrap gap-1.5">
                      {domain.tags.slice(0, 3).map((tag) => (
                        <span
                          key={tag}
                          className="px-2.5 py-0.5 rounded-md bg-slate-100 text-slate-700 font-bold text-[10px]"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    <div className="text-right">
                      <span className="text-sm font-black text-[#0D3B8C] block">
                        {domain.stat}
                      </span>
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tight block">
                        {domain.statLabel}
                      </span>
                    </div>
                  </div>
                </motion.div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
