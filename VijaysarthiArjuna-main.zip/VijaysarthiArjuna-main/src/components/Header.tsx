import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext';
import { VijaysarthiArjunaLogo, ECellGhrceLogo, IitbNecLogo } from './Logos';
import { PageRoute } from '../types';
import { Menu, X, ChevronRight, Sparkles } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    currentRoute,
    setCurrentRoute,
    setShowWhatIsNecModal,
  } = useApp();

  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [hoveredNav, setHoveredNav] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { label: string; route?: PageRoute; action?: () => void }[] = [
    { label: 'Home', route: 'home' },
    { label: 'Team', route: 'team' },
    { label: 'NEC Journey', route: 'nec-journey' },
    { label: 'Resources', route: 'resources' },
    { label: 'Gallery', route: 'gallery' },
    { label: 'Events', route: 'events' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs ${
        isScrolled ? 'py-2 sm:py-2.5 shadow-sm' : 'py-3 sm:py-3.5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Left: Official Logo with Enlarging Hover Effect */}
        <div
          className="flex items-center gap-3 cursor-pointer group shrink-0"
          onClick={() => setCurrentRoute('home')}
        >
          <motion.div
            whileHover={{ scale: 1.04 }}
            transition={{ type: 'spring', stiffness: 400, damping: 20 }}
            className="flex items-center gap-3"
          >
            <VijaysarthiArjunaLogo size={52} showText={true} />
          </motion.div>
        </div>

        {/* Center: Desktop Navigation - Always Visible & Fixed on Scroll */}
        <nav className="hidden md:flex items-center gap-1 p-1 bg-slate-100/80 border border-slate-200/80 rounded-full shadow-2xs">
          {navItems.map((item) => {
            const isActive = item.route ? currentRoute === item.route : false;
            const isHovered = hoveredNav === item.label;

            return (
              <button
                key={item.label}
                id={`nav-item-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                onMouseEnter={() => setHoveredNav(item.label)}
                onMouseLeave={() => setHoveredNav(null)}
                onClick={() => {
                  if (item.action) {
                    item.action();
                  } else if (item.route) {
                    setCurrentRoute(item.route);
                  }
                }}
                className={`relative px-3.5 lg:px-4 py-1.5 text-xs lg:text-sm font-semibold rounded-full transition-all duration-300 z-10 ${
                  isActive
                    ? 'text-[#0D3B8C] font-extrabold'
                    : 'text-slate-600 hover:text-[#0D3B8C]'
                }`}
              >
                {/* Active Indicator Background Pill */}
                {isActive && (
                  <motion.div
                    layoutId="activeTabPill"
                    className="absolute inset-0 bg-white rounded-full shadow-sm border border-slate-200/90 -z-10"
                    transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                  />
                )}

                {/* Hover Background Highlight (for non-active items) */}
                {!isActive && isHovered && (
                  <motion.div
                    layoutId="hoverTabHighlight"
                    className="absolute inset-0 bg-white/70 rounded-full -z-10"
                    transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                  />
                )}

                <span className="relative flex items-center gap-1.5">
                  <span>{item.label}</span>
                  {isActive && (
                    <motion.span
                      layoutId="activeDot"
                      className="w-1.5 h-1.5 bg-[#F97316] rounded-full inline-block shadow-xs"
                      transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                    />
                  )}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Right side controls */}
        <div className="flex items-center gap-2.5">
          {/* Mobile Menu Toggle Button */}
          <motion.button
            whileTap={{ scale: 0.92 }}
            id="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2.5 rounded-2xl bg-white/90 text-slate-700 hover:text-[#0D3B8C] border border-slate-200 shadow-sm transition-colors"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </motion.button>
        </div>
      </div>

      {/* Mobile Navigation Drawer with Smooth Opening Animation */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0, y: -10 }}
            animate={{ opacity: 1, height: 'auto', y: 0 }}
            exit={{ opacity: 0, height: 0, y: -10 }}
            transition={{ type: 'spring', stiffness: 350, damping: 30 }}
            className="md:hidden overflow-hidden bg-white/95 backdrop-blur-2xl border-b border-slate-200/90 px-4 pt-3 pb-6 shadow-2xl"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2">
                <ECellGhrceLogo size={28} />
                <IitbNecLogo size={28} />
              </div>
              <span className="text-xs font-extrabold text-[#0D3B8C] bg-blue-50 px-2.5 py-1 rounded-full border border-blue-100">
                NEC 2026 Edition
              </span>
            </div>

            <div className="flex flex-col gap-1.5">
              {navItems.map((item, index) => {
                const isActive = item.route ? currentRoute === item.route : false;
                return (
                  <motion.button
                    key={item.label}
                    initial={{ opacity: 0, x: -15 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.04, type: 'spring', stiffness: 400 }}
                    id={`mobile-nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                    onClick={() => {
                      setMobileMenuOpen(false);
                      if (item.action) {
                        item.action();
                      } else if (item.route) {
                        setCurrentRoute(item.route);
                      }
                    }}
                    className={`flex items-center justify-between px-4 py-3 text-sm font-semibold rounded-2xl text-left transition-all ${
                      isActive
                        ? 'bg-[#0D3B8C] text-white shadow-lg shadow-blue-900/20 font-bold'
                        : 'text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      {isActive && <Sparkles className="w-4 h-4 text-[#F97316]" />}
                      <span>{item.label}</span>
                    </span>
                    <ChevronRight className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  </motion.button>
                );
              })}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold text-[#F97316] tracking-wider">FIGHT • AIM • WIN</span>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  setShowWhatIsNecModal(true);
                }}
                className="text-[#0D3B8C] font-bold flex items-center gap-1 hover:underline"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#F97316]" />
                What is NEC?
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

