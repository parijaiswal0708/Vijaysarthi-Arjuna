import React from 'react';
import { useApp } from '../context/AppContext';
import { ECellGhrceLogo, IitbNecLogo, GhrceCollegeLogo } from './Logos';
import { X, ExternalLink, Sparkles, Award, Target, Rocket, Instagram, Linkedin, Mail, MapPin } from 'lucide-react';

export const Modals: React.FC = () => {
  const {
    showWhatIsNecModal,
    setShowWhatIsNecModal,
    showPartnerModal,
    setShowPartnerModal,
    setCurrentRoute,
  } = useApp();

  return (
    <>
      {/* WHAT IS NEC? MODAL */}
      {showWhatIsNecModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-md transition-opacity"
            onClick={() => setShowWhatIsNecModal(false)}
          ></div>

          {/* Modal Container */}
          <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl z-10 border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-200 my-8">
            {/* Header Banner */}
            <div className="p-6 bg-gradient-to-r from-[#0D3B8C] to-blue-900 text-white relative">
              <button
                onClick={() => setShowWhatIsNecModal(false)}
                className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-3 mb-2">
                <IitbNecLogo size={42} />
                <div>
                  <span className="text-xs font-bold text-orange-400 uppercase tracking-widest">
                    IIT Bombay Flagship Event
                  </span>
                  <h3 className="text-xl sm:text-2xl font-extrabold text-white">
                    National Entrepreneurship Challenge 2026
                  </h3>
                </div>
              </div>
              <p className="text-xs sm:text-sm text-blue-100 max-w-xl">
                India’s premier entrepreneurship cell competition organized by E-Cell, IIT Bombay, empowering student innovators to build sustainable startup ecosystems across India.
              </p>
            </div>

            {/* Content Body */}
            <div className="p-6 sm:p-8 space-y-6 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-100 space-y-2">
                  <div className="flex items-center gap-2 text-[#0D3B8C] font-bold text-sm">
                    <Target className="w-4 h-4 text-[#F97316]" />
                    <span>Basic Track</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Designed for newly established E-Cells to lay institutional foundations, organize introductory bootcamps, and foster awareness among engineering students.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-orange-50/80 border border-orange-100 space-y-2">
                  <div className="flex items-center gap-2 text-[#EA580C] font-bold text-sm">
                    <Award className="w-4 h-4 text-[#EA580C]" />
                    <span>Advanced Track</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    For mature E-Cells focused on incubating high-tech startups, securing angel investments, filing patents, and driving measurable venture creation.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#F97316]" />
                  <span>Key Pillars of NEC 2026</span>
                </h4>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-700">
                  <li className="flex items-start gap-2 p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <Rocket className="w-4 h-4 text-[#0D3B8C] shrink-0 mt-0.5" />
                    <span><strong>Campus Expansion:</strong> Onboarding 1000+ student entrepreneurs at GHRCE.</span>
                  </li>
                  <li className="flex items-start gap-2 p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <Award className="w-4 h-4 text-[#F97316] shrink-0 mt-0.5" />
                    <span><strong>Investor Pitching:</strong> Direct access to seed funding and incubation grants.</span>
                  </li>
                  <li className="flex items-start gap-2 p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <Sparkles className="w-4 h-4 text-[#0D3B8C] shrink-0 mt-0.5" />
                    <span><strong>IIT Bombay Mentorship:</strong> Guidance from national startup leaders and mentors.</span>
                  </li>
                  <li className="flex items-start gap-2 p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <Target className="w-4 h-4 text-[#F97316] shrink-0 mt-0.5" />
                    <span><strong>Grand Finale:</strong> On-stage presentation at IIT Bombay campus in Mumbai.</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Footer Actions */}
            <div className="p-4 sm:p-6 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-4">
              <button
                onClick={() => setShowWhatIsNecModal(false)}
                className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-semibold text-xs hover:bg-slate-100 transition-colors"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setShowWhatIsNecModal(false);
                  setCurrentRoute('nec-journey');
                }}
                className="px-6 py-2.5 rounded-xl bg-[#0D3B8C] hover:bg-blue-900 text-white font-bold text-xs shadow-lg shadow-blue-900/20 transition-all flex items-center gap-2"
              >
                <span>Explore Our NEC Journey</span>
                <ExternalLink className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* E-CELL GHRCE PARTNER MODAL */}
      {showPartnerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-md transition-opacity"
            onClick={() => setShowPartnerModal(false)}
          ></div>

          {/* Modal Container */}
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl z-10 border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-200 my-8">
            <div className="p-6 bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 text-white relative">
              <button
                onClick={() => setShowPartnerModal(false)}
                className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-4 mb-4">
                <ECellGhrceLogo size={44} lightText={true} />
                <div className="bg-white px-3.5 py-1.5 rounded-xl border border-slate-100 flex items-center shadow-md">
                  <GhrceCollegeLogo size={32} showText={true} />
                </div>
              </div>
              <h3 className="text-2xl font-extrabold text-white">E-Cell GHRCE Nagpur</h3>
              <p className="text-xs text-purple-200 mt-1">
                G.H. Raisoni College of Engineering • Autonomous Institution Affiliated to RTMNU
              </p>
            </div>

            <div className="p-6 space-y-5">
              <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                E-Cell GHRCE is a student-driven organization dedicated to fostering an entrepreneurial mindset, nurturing innovative ideas, and converting campus prototypes into commercially viable technology ventures.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-[#F97316]" />
                    <span>Campus Location</span>
                  </div>
                  <p className="text-slate-600">CRPF Gate No. 3, Hingna Road, Digdoh Hills, Nagpur, Maharashtra - 440016</p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                  <div className="font-bold text-slate-900 flex items-center gap-1.5">
                    <Mail className="w-4 h-4 text-[#0D3B8C]" />
                    <span>Official Contact</span>
                  </div>
                  <p className="text-slate-600">Email: ecell@ghrce.edu.in</p>
                  <p className="text-slate-600">Phone: +91 712 2281000</p>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">Connect on Socials:</span>
                <div className="flex gap-2">
                  <a
                    href="https://www.instagram.com/ecellghrce?igsh=MW1hZGQ0NGRucDh6OQ=="
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 rounded-xl bg-pink-50 text-pink-600 hover:bg-pink-100 transition-colors flex items-center gap-1.5 text-xs font-bold"
                  >
                    <Instagram className="w-4 h-4" />
                    <span>Instagram</span>
                  </a>
                  <a
                    href="https://www.linkedin.com/company/e-cell-ghrce/"
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors flex items-center gap-1.5 text-xs font-bold"
                  >
                    <Linkedin className="w-4 h-4" />
                    <span>LinkedIn</span>
                  </a>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setShowPartnerModal(false)}
                className="px-5 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition-colors"
              >
                Close Partner Info
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
