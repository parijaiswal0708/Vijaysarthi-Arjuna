import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';

export const PremiumBackground: React.FC = () => {
  const { currentRoute, settings } = useApp();
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (settings.reducedMotion) return;
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({
        x: (e.clientX / window.innerWidth - 0.5) * 20,
        y: (e.clientY / window.innerHeight - 0.5) * 20,
      });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [settings.reducedMotion]);

  const densityOpacity =
    settings.particleDensity === 'low'
      ? 'opacity-5'
      : settings.particleDensity === 'high'
      ? 'opacity-25'
      : 'opacity-15';

  const isReduced = settings.reducedMotion;

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none transition-all duration-700">
      {/* 1. Base Marble Clean Light Background */}
      <div className="absolute inset-0 bg-[#FAFAFD]" />

      {/* 2. Drifting Multi-stop Radial Aurora Gradient Mesh (Subtle & Soft) */}
      <div
        className="absolute -top-[15vh] -left-[15vw] w-[130vw] h-[130vh] opacity-30 transition-transform duration-1000 ease-out"
        style={{
          background: `
            radial-gradient(circle at 45vw 10vh, rgba(106, 0, 219, 0.05) 0%, transparent 55vw),
            radial-gradient(circle at 85vw -20vh, rgba(13, 59, 140, 0.06) 0%, transparent 65vw),
            radial-gradient(circle at 20vw 70vh, rgba(249, 115, 22, 0.04) 0%, transparent 50vw)
          `,
          transform: isReduced ? 'none' : `translate(${mousePos.x * 0.8}px, ${mousePos.y * 0.8}px)`,
        }}
      />

      {/* 3. Floating Skewed Glassmorphic Frames Array */}
      <div className={`absolute -left-[5vw] top-[-20vh] w-[110vw] flex gap-[2vw] ${densityOpacity} ${isReduced ? '' : 'animate-float'} pointer-events-none transform skew-y-12`}>
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div
            key={i}
            className="flex-none w-[16vw] max-w-[220px] h-[60vh] rounded-3xl bg-gradient-to-br from-white/30 via-white/5 to-transparent border-t border-l border-white/60 border-r border-b border-white/10 shadow-lg backdrop-blur-md"
          />
        ))}
      </div>

      <div className={`absolute -left-[2vw] top-[-45vh] w-[110vw] flex gap-[2vw] ${densityOpacity} ${isReduced ? '' : 'animate-float-reverse'} pointer-events-none transform skew-y-12`}>
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div
            key={i}
            className="flex-none w-[16vw] max-w-[220px] h-[60vh] rounded-3xl bg-gradient-to-br from-blue-100/20 via-white/5 to-transparent border-t border-l border-white/60 border-r border-b border-white/10 shadow-lg backdrop-blur-md"
          />
        ))}
      </div>

      {/* 4. Soft Mouse-tracking Accent Glows */}
      <div
        className="absolute top-[10%] right-[10%] w-[550px] h-[550px] rounded-full bg-gradient-to-br from-[#0D3B8C]/4 to-[#6A00DB]/4 blur-[120px] transition-transform duration-700 ease-out"
        style={{ transform: isReduced ? 'none' : `translate(${mousePos.x * 1.5}px, ${mousePos.y * 1.5}px)` }}
      />

      <div
        className="absolute bottom-[10%] left-[5%] w-[600px] h-[600px] rounded-full bg-gradient-to-tr from-[#F97316]/4 to-amber-200/5 blur-[130px] transition-transform duration-700 ease-out"
        style={{ transform: isReduced ? 'none' : `translate(${-mousePos.x * 1.2}px, ${-mousePos.y * 1.2}px)` }}
      />

      {/* 5. Subtle Faint Circuit Grid Overlay */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.03] pointer-events-none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="circuit-grid" width="80" height="80" patternUnits="userSpaceOnUse">
            <path d="M 80 0 L 0 0 0 80" fill="none" stroke="#0D3B8C" strokeWidth="1.5" />
            <circle cx="80" cy="0" r="3" fill="#F97316" />
            <circle cx="0" cy="80" r="3" fill="#0D3B8C" />
            <path d="M 20 20 L 60 20 L 60 60" fill="none" stroke="#F97316" strokeWidth="1" strokeDasharray="3,3" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#circuit-grid)" />
      </svg>
    </div>
  );
};


