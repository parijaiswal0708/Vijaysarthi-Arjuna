import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { VijaysarthiArjunaLogo } from './Logos';
import { Sparkles, ArrowRight, ShieldCheck, Trophy } from 'lucide-react';

interface BrandedPageLoaderProps {
  pageName?: string;
  onComplete?: () => void;
}

export const BrandedPageLoader: React.FC<BrandedPageLoaderProps> = ({
  pageName = 'Vijaysarthi Arjuna',
  onComplete,
}) => {
  const [phase, setPhase] = useState<'fly' | 'reveal' | 'fade'>('fly');
  const onCompleteRef = useRef(onComplete);

  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  useEffect(() => {
    // Smoother, elegant animation timeline - runs strictly ONCE on mount
    const revealTimer = setTimeout(() => {
      setPhase('reveal');
    }, 850);

    const fadeTimer = setTimeout(() => {
      setPhase('fade');
    }, 1750);

    const completeTimer = setTimeout(() => {
      if (onCompleteRef.current) onCompleteRef.current();
    }, 2050);

    return () => {
      clearTimeout(revealTimer);
      clearTimeout(fadeTimer);
      clearTimeout(completeTimer);
    };
  }, []);

  return (
    <AnimatePresence>
      {phase !== 'fade' && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.03, filter: 'blur(8px)', transition: { duration: 0.25, ease: 'easeOut' } }}
          className="fixed inset-0 z-[100] bg-gradient-to-b from-slate-50 via-blue-50/60 to-slate-100 backdrop-blur-3xl flex flex-col items-center justify-center text-slate-900 select-none overflow-hidden"
        >
          {/* Light Ambient Background Aura */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <motion.div
              animate={{
                scale: phase === 'reveal' ? [0.9, 1.2, 1] : [0.8, 1],
                opacity: phase === 'reveal' ? 0.6 : 0.3,
              }}
              transition={{ duration: 0.6 }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full bg-radial from-[#F97316]/20 via-[#0D3B8C]/15 to-transparent blur-3xl"
            />
            {/* Grid overlay */}
            <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#0D3B8C_1px,transparent_1px)] [background-size:24px_24px]" />
          </div>

          {/* ARROW ANIMATION STAGE (Arrow coming from left of screen) */}
          <div className="absolute inset-0 flex items-center pointer-events-none overflow-hidden">
            {/* Speed trail line */}
            <motion.div
              initial={{ x: '-100%', opacity: 0 }}
              animate={
                phase === 'fly'
                  ? { x: ['-100%', '0%', '100%'], opacity: [0, 1, 0.8] }
                  : { x: '100%', opacity: 0 }
              }
              transition={{ duration: 0.9, ease: 'easeInOut' }}
              className="w-full h-1 bg-gradient-to-r from-transparent via-[#F97316] to-[#0D3B8C] shadow-[0_0_20px_#F97316]"
            />

            {/* Flying Arrow */}
            <motion.div
              initial={{ x: '-25vw', opacity: 0 }}
              animate={
                phase === 'fly'
                  ? { x: ['-25vw', '45vw', '125vw'], opacity: [0, 1, 0] }
                  : { x: '125vw', opacity: 0 }
              }
              transition={{ duration: 0.95, ease: [0.22, 1, 0.36, 1] }}
              className="absolute top-1/2 -translate-y-1/2 flex items-center gap-1 z-20"
            >
              {/* Glowing Arrow Trail */}
              <div className="w-48 sm:w-80 h-1.5 bg-gradient-to-r from-transparent via-[#F97316] to-amber-400 rounded-full shadow-[0_0_15px_#F97316]" />

              {/* Sleek SVG Arrowhead */}
              <svg className="w-16 h-10 overflow-visible drop-shadow-[0_0_12px_rgba(249,115,22,0.8)]" viewBox="0 0 60 40" fill="none">
                <path
                  d="M0 20 L40 20 M30 5 L55 20 L30 35 L38 20 Z"
                  fill="url(#arrowGrad)"
                  stroke="#EA580C"
                  strokeWidth="1.5"
                />
                <defs>
                  <linearGradient id="arrowGrad" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#F97316" />
                    <stop offset="60%" stopColor="#FBBF24" />
                    <stop offset="100%" stopColor="#0D3B8C" />
                  </linearGradient>
                </defs>
              </svg>
            </motion.div>
          </div>

          {/* INFO PAGE REVEAL SECTION (Appears smoothly after arrow flies across) */}
          <AnimatePresence>
            {phase === 'reveal' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.92, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                className="relative z-10 flex flex-col items-center text-center px-6 max-w-lg mx-auto"
              >
                {/* Team Badge */}
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05, duration: 0.25 }}
                  className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/90 border border-blue-200 shadow-md backdrop-blur-md mb-6"
                >
                  <VijaysarthiArjunaLogo size={22} showText={false} />
                  <span className="text-xs font-black tracking-widest text-[#0D3B8C] uppercase">VIJAYSARTHI ARJUNA</span>
                  <span className="h-3 w-[1px] bg-slate-300" />
                  <span className="text-[10px] font-extrabold text-[#F97316] uppercase tracking-wider">GHRCE</span>
                </motion.div>

                {/* Main Heading / Info Banner */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1, duration: 0.25 }}
                  className="space-y-3"
                >
                  <h2 className="text-2xl sm:text-3xl font-black text-[#0D3B8C] tracking-tight leading-snug">
                    {pageName}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-600 font-semibold tracking-wide">
                    IIT BOMBAY NATIONAL ENTREPRENEURSHIP CHALLENGE 2026
                  </p>
                </motion.div>

                {/* Progress bar line */}
                <motion.div
                  initial={{ opacity: 0, width: '0%' }}
                  animate={{ opacity: 1, width: '100%' }}
                  transition={{ delay: 0.15, duration: 0.3 }}
                  className="w-48 sm:w-64 bg-slate-200 h-1.5 rounded-full overflow-hidden mt-6 relative shadow-inner"
                >
                  <motion.div
                    initial={{ width: '0%' }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 0.3, ease: 'easeOut' }}
                    className="h-full bg-gradient-to-r from-[#0D3B8C] via-[#F97316] to-amber-500 rounded-full"
                  />
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

