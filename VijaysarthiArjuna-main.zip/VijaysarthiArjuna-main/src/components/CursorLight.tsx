import React, { useEffect, useState } from 'react';
import { motion, useSpring } from 'motion/react';

export const CursorLight: React.FC = () => {
  const [isPointer, setIsPointer] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  const springConfig = { damping: 28, stiffness: 220, mass: 0.5 };
  const cursorX = useSpring(-100, springConfig);
  const cursorY = useSpring(-100, springConfig);

  useEffect(() => {
    // Disable on touch devices
    if (typeof window === 'undefined' || window.matchMedia('(pointer: coarse)').matches) return;

    const handleMouseMove = (e: MouseEvent) => {
      cursorX.set(e.clientX);
      cursorY.set(e.clientY);
      setIsVisible(true);

      // Check if hovering over interactive elements
      const rawTarget = e.target as Node | null;
      const target = (rawTarget instanceof Element
        ? rawTarget
        : rawTarget?.parentElement) as Element | null;

      if (
        target &&
        typeof target.closest === 'function' &&
        (target.tagName === 'BUTTON' ||
          target.tagName === 'A' ||
          target.closest('button') ||
          target.closest('a') ||
          target.getAttribute?.('role') === 'button')
      ) {
        setIsPointer(true);
      } else {
        setIsPointer(false);
      }
    };

    const handleMouseLeave = () => setIsVisible(false);
    const handleMouseEnter = () => setIsVisible(true);

    window.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
    };
  }, [cursorX, cursorY]);

  return (
    <motion.div
      className="fixed top-0 left-0 pointer-events-none z-50 rounded-full mix-blend-soft-light"
      style={{
        x: cursorX,
        y: cursorY,
        translateX: '-50%',
        translateY: '-50%',
        width: isPointer ? 320 : 240,
        height: isPointer ? 320 : 240,
        opacity: isVisible ? 1 : 0,
        background: isPointer
          ? 'radial-gradient(circle, rgba(249, 115, 22, 0.18) 0%, rgba(13, 59, 140, 0.12) 40%, transparent 70%)'
          : 'radial-gradient(circle, rgba(13, 59, 140, 0.14) 0%, rgba(249, 115, 22, 0.08) 45%, transparent 70%)',
        transition: 'width 0.3s ease, height 0.3s ease, background 0.3s ease, opacity 0.3s ease',
      }}
    />
  );
};
