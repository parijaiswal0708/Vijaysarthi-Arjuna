import React from 'react';
import { Sparkles, Shield } from 'lucide-react';

export const ArjunaInteractiveCanvas: React.FC = () => {
  return (
    <div id="our-story-section" className="py-20 bg-slate-50 relative overflow-hidden">
      {/* Background Geometric Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#CBD5E1_1px,transparent_1px)] [background-size:32px_32px] opacity-40"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-100/80 border border-blue-200 text-xs font-extrabold text-[#0D3B8C] uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#F97316]" />
            <span>Brand Narrative</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight">
            Our Story: <span className="text-[#0D3B8C]">The Spirit of Arjuna</span>
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-3">
            In ancient lore, Arjuna was defined by singular focus and unyielding aim. Experience how Team Vijaysarthi Arjuna channels that determination into groundbreaking entrepreneurial innovation.
          </p>
        </div>

        {/* Story Content Stage */}
        <div className="geo-card rounded-3xl p-6 md:p-10 border border-slate-200 bg-white shadow-xl relative overflow-hidden max-w-4xl mx-auto">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-orange-100 text-[#EA580C] font-bold text-xs">
              <Shield className="w-3.5 h-3.5" />
              <span>GHRCE at IIT Bombay NEC 2026</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-tight">
              Turning Determination into Innovation, & Innovation into Lasting Impact.
            </h3>

            <div className="space-y-3 text-sm sm:text-base text-slate-600 leading-relaxed">
              <p>
                Representing <strong>G.H. Raisoni College of Engineering (GHRCE)</strong>, Nagpur, Team <strong>VIJAYSARTHI ARJUNA</strong> is forged on the principle that true victory in entrepreneurship comes from absolute focus on the target.
              </p>
              <p>
                As we compete in IIT Bombay’s flagship <strong>National Entrepreneurship Challenge 2026</strong>, our team brings together cross-disciplinary student leaders, engineers, researchers, and visionaries to establish a world-class startup ecosystem right here on our campus.
              </p>
            </div>

            <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-slate-100 text-center">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-2xl font-extrabold text-[#0D3B8C]">1200+</div>
                <div className="text-xs text-slate-500 font-medium mt-0.5">Students Engaged</div>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-2xl font-extrabold text-[#F97316]">15+</div>
                <div className="text-xs text-slate-500 font-medium mt-0.5">Campus Bootcamps</div>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-2xl font-extrabold text-[#0D3B8C]">100%</div>
                <div className="text-xs text-slate-500 font-medium mt-0.5">NEC Commitment</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
