import React from 'react';
import { motion } from 'motion/react';
import { Target, Zap, ShieldCheck } from 'lucide-react';

export const ArjunaHeroIllustration: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`relative flex items-center justify-center select-none ${className}`}>
      {/* Layer 1: Ambient Theme-Matched Light Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] h-[340px] sm:w-[480px] sm:h-[480px] rounded-full bg-radial from-[#0D3B8C]/15 via-[#F97316]/10 to-transparent blur-3xl pointer-events-none"></div>

      {/* Layer 2: Geometric Branded Tech Ring Accents */}
      <div className="absolute w-[320px] h-[320px] sm:w-[420px] sm:h-[420px] rounded-full border border-[#0D3B8C]/10 border-dashed animate-[spin_60s_linear_infinite] pointer-events-none"></div>
      <div className="absolute w-[280px] h-[280px] sm:w-[360px] sm:h-[360px] rounded-full border border-[#F97316]/15 pointer-events-none"></div>

      {/* Main Image Frame with Soft Gradient Masking & Theme Blending */}
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 w-full max-w-[320px] sm:max-w-[400px] lg:max-w-[440px]"
      >
        <div className="relative rounded-3xl p-2 bg-gradient-to-b from-white/90 via-slate-50/70 to-white/40 backdrop-blur-md border border-slate-200/80 shadow-[0_20px_50px_-15px_rgba(13,59,140,0.18)] group overflow-hidden">
          {/* Edge Light Reflection */}
          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/40 to-transparent pointer-events-none z-20"></div>

          {/* The Hero Image with transparent background and soft glowing highlight */}
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-slate-900/90 via-[#0D3B8C]/80 to-slate-950 p-4 pt-6 pb-10 min-h-[420px] flex items-center justify-center">
            {/* Radial background aura behind Arjuna */}
            <div className="absolute inset-0 bg-radial from-amber-400/20 via-[#F97316]/10 to-transparent blur-xl pointer-events-none"></div>

            <img
              src="https://i.ibb.co/3yd9f03z/new-arjuna-removebg-preview.png"
              alt="new arjuna removebg preview"
              referrerPolicy="no-referrer"
              className="relative z-10 max-h-[440px] w-auto h-auto object-contain mx-auto drop-shadow-[0_12px_24px_rgba(0,0,0,0.4)] transform transition-transform duration-700 ease-out group-hover:scale-105"
            />

            {/* Bottom Seamless Gradient Fade for Watermark contrast */}
            <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-slate-950 via-slate-950/70 to-transparent pointer-events-none z-10"></div>

            {/* Subtle Brand Slogan Watermark Overlay */}
            <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-white/90 z-20">
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#F97316] drop-shadow-md flex items-center gap-1">
                <Target className="w-3 h-3 text-[#F97316]" /> Gandiva Focus
              </span>
              <span className="text-[9px] font-bold text-slate-300 uppercase tracking-wider drop-shadow-md">
                IIT Bombay NEC '26
              </span>
            </div>
          </div>
        </div>

        {/* Human-Crafted Floating Badge 1: Left */}
        <motion.div
          animate={{ y: [0, -6, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -left-4 sm:-left-8 top-12 z-20 hidden xs:flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-white/95 backdrop-blur-xl border border-slate-200 shadow-xl shadow-blue-900/10"
        >
          <div className="p-1.5 rounded-xl bg-orange-50 text-[#F97316] border border-orange-100">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[10px] font-extrabold uppercase text-[#0D3B8C] tracking-wide">
              FIGHT • AIM • WIN
            </div>
            <div className="text-[9px] text-slate-500 font-medium">Unwavering Precision</div>
          </div>
        </motion.div>

        {/* Human-Crafted Floating Badge 2: Right Bottom */}
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 4.5, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
          className="absolute -right-3 sm:-right-6 bottom-8 z-20 hidden xs:flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-white/95 backdrop-blur-xl border border-slate-200 shadow-xl shadow-blue-900/10"
        >
          <div className="p-1.5 rounded-xl bg-blue-50 text-[#0D3B8C] border border-blue-100">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[10px] font-extrabold uppercase text-slate-900 tracking-wide">
              GHRCE Representation
            </div>
            <div className="text-[9px] text-slate-500 font-medium">National Challenge</div>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};



