import React from 'react';
import { motion } from 'motion/react';
import { ExternalLink, Instagram, Linkedin, Info } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const OrganizingPartnersSection: React.FC = () => {
  const { setShowPartnerModal } = useApp();

  return (
    <section className="py-16 bg-transparent relative z-10">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header - Slide from Right */}
        <motion.div
          initial={{ opacity: 0, x: 60 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="text-center max-w-2xl mx-auto space-y-3"
        >
          <h2 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight">
            Our Organizing Partner
          </h2>
          <p className="text-sm sm:text-base text-slate-600 font-medium leading-relaxed">
            Empowered by E-Cell GHRCE and G.H. Raisoni College of Engineering, Nagpur.
          </p>
        </motion.div>

        {/* Partner Card - Slide from Left */}
        <motion.div
          initial={{ opacity: 0, x: -60, scale: 0.96 }}
          whileInView={{ opacity: 1, x: 0, scale: 1 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          onClick={() => setShowPartnerModal(true)}
          className="mt-10 max-w-4xl mx-auto bg-white/95 backdrop-blur-xl rounded-[2rem] p-6 sm:p-10 border border-slate-200/90 shadow-xl cursor-pointer hover:border-[#0D3B8C]/40 hover:shadow-2xl transition-all group relative"
        >
          <div className="flex flex-col md:flex-row items-center md:items-center gap-6 sm:gap-8">
            {/* Logo Graphic Box */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 flex items-center justify-center w-full md:w-64 h-36 shrink-0 group-hover:bg-blue-50/50 transition-colors">
              <img
                src="https://i.ibb.co/Mxdf8bqN/ecell.png"
                alt="E-Cell Logo"
                referrerPolicy="no-referrer"
                className="max-h-28 w-auto object-contain"
              />
            </div>

            {/* Info Column */}
            <div className="flex-1 text-left space-y-3">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowPartnerModal(true);
                  }}
                  className="group/title flex items-center gap-2 text-2xl sm:text-3xl font-black text-slate-900 hover:text-[#0D3B8C] transition-colors text-left"
                >
                  <span>E-Cell GHRCE Nagpur</span>
                  <ExternalLink className="w-5 h-5 text-slate-400 group-hover/title:text-[#0D3B8C] transition-colors shrink-0" />
                </button>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-[#0D3B8C] text-xs font-bold border border-blue-200/60 shadow-sm">
                  <Info className="w-3.5 h-3.5" /> Click for details
                </span>
              </div>

              <p className="text-sm sm:text-base text-slate-600 font-medium leading-relaxed">
                The official Entrepreneurship Cell of G.H. Raisoni College of Engineering, dedicated to cultivating founders, organizing hackathons, and managing campus incubation facilities.
              </p>

              {/* Social Links */}
              <div className="flex flex-wrap items-center gap-5 pt-2">
                <a
                  href="https://www.instagram.com/ecellghrce?igsh=MW1hZGQ0NGRucDh6OQ=="
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-extrabold text-[#F97316] hover:text-[#0D3B8C] transition-colors"
                >
                  <Instagram className="w-4 h-4" />
                  <span>@ecellghrce</span>
                </a>

                <a
                  href="https://www.linkedin.com/company/e-cell-ghrce/"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-extrabold text-[#0D3B8C] hover:text-[#F97316] transition-colors"
                >
                  <Linkedin className="w-4 h-4" />
                  <span>E-Cell GHRCE</span>
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
