import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
}

export class ErrorBoundary extends Component<Props, State> {
  declare props: Readonly<Props>;

  state: State = {
    hasError: false,
  };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('ErrorBoundary caught error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-6 text-center">
          <div className="max-w-md space-y-4 bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto text-xl font-bold">
              !
            </div>
            <h2 className="text-xl font-extrabold text-white">Vijaysarthi Arjuna Application</h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              An unexpected display issue occurred. You can safely refresh the application or reset local data.
            </p>
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => {
                  try {
                    localStorage.clear();
                  } catch (e) {
                    console.warn(e);
                  }
                  window.location.reload();
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-[#0D3B8C] hover:bg-blue-800 text-white font-bold text-xs transition-colors"
              >
                Reset & Reload
              </button>
              <button
                onClick={() => window.location.reload()}
                className="flex-1 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition-colors"
              >
                Reload Page
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
