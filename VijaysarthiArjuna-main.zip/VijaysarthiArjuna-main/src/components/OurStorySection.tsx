import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck } from 'lucide-react';

export const OurStorySection: React.FC = () => {
  return (
    <section className="py-20 bg-transparent relative z-10 overflow-hidden">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header - Animates in from Left */}
        <motion.div
          initial={{ opacity: 0, x: -60 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="text-center max-w-3xl mx-auto space-y-4"
        >
          {/* Brand Narrative Pill Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/60 backdrop-blur-md border border-blue-200/80 text-xs font-bold text-[#0D3B8C] uppercase tracking-wider shadow-sm shadow-blue-950/5">
            <span>Our Story</span>
          </div>

          {/* Heading */}
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-tight">
            Built with Purpose. <span className="text-[#0D3B8C]">Driven by Vision.</span>
          </h2>

          {/* Subtitle */}
          <p className="text-sm sm:text-base text-slate-600 font-medium leading-relaxed max-w-2xl mx-auto">
            Not just another student team. A generation of builders rewriting what&apos;s possible. Representing G.H. Raisoni College of Engineering (GHRCE), Nagpur, VijaySarthi Arjuna is our pursuit of innovation through entrepreneurship.
          </p>
        </motion.div>

        {/* Content Card - Animates in from Right */}
        <motion.div
          initial={{ opacity: 0, x: 60, scale: 0.97 }}
          whileInView={{ opacity: 1, x: 0, scale: 1 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="mt-12 bg-white/40 backdrop-blur-2xl rounded-3xl p-6 sm:p-10 border border-white/80 shadow-2xl shadow-blue-950/10 relative overflow-hidden text-left"
        >
          <div className="space-y-6">
            {/* Badge inside card with glass effect */}
            <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-2xl bg-white/60 backdrop-blur-xl text-[#EA580C] border border-white/90 shadow-lg shadow-orange-500/10 text-xs font-extrabold uppercase tracking-wide relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 via-amber-500/10 to-orange-500/10 opacity-70 pointer-events-none" />
              <ShieldCheck className="w-4 h-4 text-[#EA580C] relative z-10" />
              <span className="relative z-10">Inspired by Arjuna. Built for Impact</span>
            </div>

            {/* Main Card Headline */}
            <h3 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight leading-tight">
              Every startup begins with an idea. Every revolution begins with people who refuse to settle.
            </h3>

            {/* Card Body Paragraphs */}
            <div className="space-y-4 text-sm sm:text-base text-slate-600 leading-relaxed font-medium">
              <p>
                We&apos;re <strong className="text-slate-900 font-extrabold">VijaySarthi Arjuna</strong> - a team of ambitious students representing <strong className="text-slate-900 font-extrabold">GHRCE</strong> at IIT Bombay&apos;s National Entrepreneurship Challenge 2026. United by curiosity and driven by purpose, we&apos;re building more than projects - we&apos;re building a culture of innovation that inspires every student to dream bigger.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
