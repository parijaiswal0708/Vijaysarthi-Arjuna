import React from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Shield,
  Volume2,
  VolumeX,
  Sparkles,
  Type,
  Eye,
  Mail,
  Info,
  Sliders,
  CheckCircle2,
  RotateCcw,
  Database
} from 'lucide-react';

export const SettingsDrawer: React.FC = () => {
  const {
    showSettingsDrawer,
    setShowSettingsDrawer,
    settings,
    updateSettings,
    setShowAdminModal,
    setCurrentRoute,
    resetToDefaultData,
    isSupabaseActive,
    syncStatus,
    dbError,
  } = useApp();

  if (!showSettingsDrawer) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity"
        onClick={() => setShowSettingsDrawer(false)}
      ></div>

      {/* Slide-over Drawer Panel */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl z-10 flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-300 border-l border-slate-200">
        {/* Header */}
        <div>
          <div className="p-6 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-[#0D3B8C] text-white">
                <Sliders className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Settings & Admin</h3>
                <p className="text-xs text-slate-500">Configure experience & access control</p>
              </div>
            </div>
            <button
              onClick={() => setShowSettingsDrawer(false)}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 space-y-6">
            {/* Supabase Database Status */}
            <div className={`p-4 rounded-2xl border space-y-2 ${
              isSupabaseActive
                ? syncStatus === 'synced'
                  ? 'bg-emerald-50/80 border-emerald-200'
                  : syncStatus === 'error'
                  ? 'bg-rose-50/80 border-rose-200'
                  : 'bg-blue-50/80 border-blue-200'
                : 'bg-slate-50 border-slate-200'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Database className={`w-4 h-4 ${
                    isSupabaseActive ? 'text-emerald-600' : 'text-slate-500'
                  }`} />
                  <span className="text-xs font-bold text-slate-900">
                    Supabase Database
                  </span>
                </div>
                <span className={`text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                  syncStatus === 'synced'
                    ? 'bg-emerald-200 text-emerald-900'
                    : syncStatus === 'error'
                    ? 'bg-rose-200 text-rose-900'
                    : 'bg-slate-200 text-slate-800'
                }`}>
                  {isSupabaseActive ? syncStatus : 'Memory Mode'}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {isSupabaseActive
                  ? syncStatus === 'synced'
                    ? 'All data is synchronized live with Supabase cloud database across all devices.'
                    : syncStatus === 'error'
                    ? dbError || 'Supabase connection issue.'
                    : 'Connecting & syncing with Supabase...'
                  : 'Supabase URL & Key not provided. Using in-memory database mode.'}
              </p>
            </div>

            {/* Admin Portal Quick Access */}
            <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-amber-600" />
                  <span className="text-sm font-bold text-amber-900">Admin Portal</span>
                </div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-200 text-amber-900">
                  Secure
                </span>
              </div>
              <p className="text-xs text-amber-800 leading-relaxed">
                Manage Team, Gallery, Resources, Timeline Milestones, FAQs, and Contact Form submissions.
              </p>
              <button
                id="drawer-admin-portal-button"
                onClick={() => {
                  setShowSettingsDrawer(false);
                  setShowAdminModal(true);
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-md shadow-amber-600/20 transition-all flex items-center justify-center gap-2"
              >
                <Shield className="w-4 h-4" />
                <span>Launch Admin Dashboard</span>
              </button>
            </div>

            {/* Audio & Haptics */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Sound & Animation FX
              </h4>
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center gap-3">
                  {settings.soundEnabled ? (
                    <Volume2 className="w-5 h-5 text-[#0D3B8C]" />
                  ) : (
                    <VolumeX className="w-5 h-5 text-slate-400" />
                  )}
                  <div>
                    <div className="text-sm font-semibold text-slate-800">Sound Effects</div>
                    <div className="text-xs text-slate-500">Arjuna bow release sound FX</div>
                  </div>
                </div>
                <button
                  onClick={() => updateSettings({ soundEnabled: !settings.soundEnabled })}
                  className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                    settings.soundEnabled ? 'bg-[#0D3B8C]' : 'bg-slate-300'
                  }`}
                >
                  <div
                    className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                      settings.soundEnabled ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  ></div>
                </button>
              </div>

              {/* Particle Density */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-sm font-semibold text-slate-800">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#F97316]" />
                    <span>Background Particles</span>
                  </div>
                  <span className="text-xs capitalize font-bold text-[#0D3B8C]">
                    {settings.particleDensity}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 pt-1">
                  {(['low', 'medium', 'high'] as const).map((density) => (
                    <button
                      key={density}
                      onClick={() => updateSettings({ particleDensity: density })}
                      className={`py-1.5 text-xs font-bold rounded-lg border transition-all capitalize ${
                        settings.particleDensity === density
                          ? 'bg-[#0D3B8C] text-white border-[#0D3B8C]'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {density}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Accessibility Options */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Accessibility & Display
              </h4>

              {/* Font Scaling */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-800">
                  <Type className="w-4 h-4 text-[#0D3B8C]" />
                  <span>Text Size Scale</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {(['normal', 'large', 'xlarge'] as const).map((scale) => (
                    <button
                      key={scale}
                      onClick={() => updateSettings({ fontSizeScale: scale })}
                      className={`py-1.5 text-xs font-bold rounded-lg border transition-all capitalize ${
                        settings.fontSizeScale === scale
                          ? 'bg-[#0D3B8C] text-white border-[#0D3B8C]'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {scale === 'xlarge' ? 'XL' : scale}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reduced Motion Toggle */}
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center gap-3">
                  <Eye className="w-5 h-5 text-slate-600" />
                  <div>
                    <div className="text-sm font-semibold text-slate-800">Reduce Motion</div>
                    <div className="text-xs text-slate-500">Minimize complex animations</div>
                  </div>
                </div>
                <button
                  onClick={() => updateSettings({ reducedMotion: !settings.reducedMotion })}
                  className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                    settings.reducedMotion ? 'bg-[#0D3B8C]' : 'bg-slate-300'
                  }`}
                >
                  <div
                    className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                      settings.reducedMotion ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  ></div>
                </button>
              </div>
            </div>

            {/* Contact & Actions */}
            <div className="space-y-3 pt-2">
              <button
                onClick={() => {
                  setShowSettingsDrawer(false);
                  setCurrentRoute('home');
                  setTimeout(() => {
                    const el = document.getElementById('terminal-contact-section');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }, 200);
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs border border-slate-300 transition-all flex items-center justify-center gap-2"
              >
                <Mail className="w-4 h-4 text-[#F97316]" />
                <span>Open Terminal Contact Form</span>
              </button>

              <button
                onClick={() => {
                  if (confirm('Reset website state to original seed data? Custom edits in admin portal will be replaced.')) {
                    resetToDefaultData();
                    alert('State reset successfully!');
                  }
                }}
                className="w-full py-2 px-4 rounded-xl text-slate-500 hover:text-red-600 text-xs font-medium transition-colors flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Local Data Cache</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 text-center text-xs text-slate-500 space-y-1">
          <div className="flex items-center justify-center gap-1.5 font-bold text-slate-700">
            <Info className="w-3.5 h-3.5 text-[#0D3B8C]" />
            <span>VIJAYSARTHI ARJUNA v2.6.0</span>
          </div>
          <div>IIT Bombay National Entrepreneurship Challenge 2026</div>
        </div>
      </div>
    </div>
  );
};
