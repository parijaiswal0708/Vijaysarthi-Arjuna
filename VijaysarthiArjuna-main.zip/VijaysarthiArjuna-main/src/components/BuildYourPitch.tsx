import React, { useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Rocket, Trophy, Target, Award, CheckCircle2, ShieldCheck, Sparkles, ExternalLink } from 'lucide-react';

export const BuildYourPitch: React.FC = () => {
  const triggerRef = useRef<HTMLDivElement>(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isInView) {
          setIsInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (triggerRef.current) {
      observer.observe(triggerRef.current);
    }

    return () => observer.disconnect();
  }, [isInView]);

  return (
    <section className="py-20 bg-transparent relative z-10 overflow-hidden" ref={triggerRef}>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Section Header */}
        <div className="mb-12 space-y-2">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-xs font-extrabold text-[#0D3B8C] uppercase tracking-widest shadow-sm">
            <span>The journey we choose</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black text-[#0D3B8C] tracking-tight">
            Built with Purpose. Driven by Progress.
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 font-medium max-w-2xl mx-auto">
            Every challenge we complete, every idea we validate, and every milestone we achieve is a step toward creating lasting impact beyond the competition.
          </p>
        </div>

        {/* 3D Stack Container with Fly-in Cards */}
        <motion.div
          variants={{
            hidden: {
              backgroundColor: 'rgba(255,255,255,0)',
              boxShadow: '0px 0px 0px rgba(0,0,0,0)',
              scale: 1,
            },
            visible: {
              backgroundColor: '#ffffff',
              boxShadow: '0px 25px 60px rgba(13, 59, 140, 0.12)',
              scale: [1, 1, 1.02, 1],
              transition: {
                backgroundColor: { delay: 1.2, duration: 0.6 },
                boxShadow: { delay: 1.2, duration: 0.6 },
                scale: { delay: 1.8, duration: 1, times: [0, 0.4, 0.7, 1], ease: 'easeInOut' },
              },
            },
          }}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          className="relative w-full max-w-2xl mx-auto rounded-3xl p-6 sm:p-10 border border-slate-200/90 flex flex-col gap-6 transform-style-3d text-left"
        >
          {/* Sweeping Glass Shine Overlay */}
          <div className="absolute inset-0 rounded-3xl overflow-hidden pointer-events-none z-20">
            <motion.div
              variants={{
                hidden: { left: '-150%' },
                visible: {
                  left: '150%',
                  transition: { delay: 2, duration: 0.8, ease: 'easeInOut' },
                },
              }}
              className="absolute top-0 w-[120%] h-full bg-gradient-to-r from-transparent via-white/80 to-transparent -skew-x-12 pointer-events-none"
            />
          </div>

          <motion.h3
            variants={{
              hidden: { opacity: 0, y: -20 },
              visible: { opacity: 1, y: 0, transition: { delay: 1.2, duration: 0.6 } },
            }}
            className="text-center text-slate-400 font-extrabold text-sm uppercase tracking-widest"
          >
            Vijaysarthi Pitch Deck
          </motion.h3>

          {/* Fly-in Card 1: Team Profile */}
          <motion.div
            variants={{
              hidden: {
                x: '100vw',
                y: '-30vh',
                z: -800,
                scale: 5,
                rotateX: 60,
                rotateY: -75,
                rotateZ: 25,
                opacity: 0,
              },
              visible: {
                x: 0,
                y: 0,
                z: 0,
                scale: 1,
                rotateX: 0,
                rotateY: 0,
                rotateZ: 0,
                opacity: 1,
                transition: { duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: 0 },
              },
            }}
            className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center gap-5 shadow-sm"
          >
            <div className="w-16 h-16 rounded-full bg-[#0D3B8C] text-white flex items-center justify-center font-black text-xl shrink-0 shadow-lg shadow-blue-900/20">
              <Rocket className="w-8 h-8 text-[#F97316]" />
            </div>
            <div className="flex-1 space-y-1">
              <span className="text-[10px] font-black text-[#0D3B8C] uppercase tracking-widest">
                GHRCE Official Delegation
              </span>
              <h4 className="text-lg font-extrabold text-slate-900">Official team representing GHRCE</h4>
              <p className="text-xs text-slate-600 font-medium leading-relaxed">
                Competing in IIT Bombay&apos;s National Entrepreneurship Challenge 2026 with one shared mission - to learn, innovate, and lead.
              </p>
            </div>
          </motion.div>

          {/* Fly-in Card 2: Innovation Milestones */}
          <motion.div
            variants={{
              hidden: {
                x: '-100vw',
                y: '-15vh',
                z: -800,
                scale: 2.2,
                rotateX: 60,
                rotateY: 75,
                rotateZ: -25,
                opacity: 0,
              },
              visible: {
                x: 0,
                y: 0,
                z: 0,
                scale: 1,
                rotateX: 0,
                rotateY: 0,
                rotateZ: 0,
                opacity: 1,
                transition: { duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: 0.2 },
              },
            }}
            className="p-5 rounded-2xl bg-white border border-slate-200 shadow-md space-y-2"
          >
            <div className="flex items-center justify-between">
              <h4 className="text-base font-extrabold text-slate-900">Entrepreneurial Journey</h4>
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>100% Tracked</span>
              </span>
            </div>
            <p className="text-xs text-slate-600 font-medium">
              Learning through real-world challenges, mentorship, and execution.
            </p>
          </motion.div>

          {/* Fly-in Card 3: Execution Support */}
          <motion.div
            variants={{
              hidden: {
                x: '100vw',
                y: '10vh',
                z: -800,
                scale: 2.2,
                rotateX: 60,
                rotateY: -75,
                rotateZ: 25,
                opacity: 0,
              },
              visible: {
                x: 0,
                y: 0,
                z: 0,
                scale: 1,
                rotateX: 0,
                rotateY: 0,
                rotateZ: 0,
                opacity: 1,
                transition: { duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: 0.4 },
              },
            }}
            className="p-5 rounded-2xl bg-white border border-slate-200 shadow-md space-y-2"
          >
            <div className="flex items-center justify-between">
              <h4 className="text-base font-extrabold text-slate-900">Mission in Progress</h4>
              <span className="text-xs font-bold text-[#F97316] bg-orange-50 px-2.5 py-1 rounded-full border border-orange-100 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Verified</span>
              </span>
            </div>
            <p className="text-xs text-slate-600 font-medium">
              Turning ideas into measurable impact - one milestone at a time.
            </p>
          </motion.div>

          {/* Fly-in Card 4: National Ranking */}
          <motion.div
            variants={{
              hidden: {
                x: '-100vw',
                y: '25vh',
                z: -800,
                scale: 2.2,
                rotateX: 60,
                rotateY: 75,
                rotateZ: -25,
                opacity: 0,
              },
              visible: {
                x: 0,
                y: 0,
                z: 0,
                scale: 1,
                rotateX: 0,
                rotateY: 0,
                rotateZ: 0,
                opacity: 1,
                transition: { duration: 1.2, ease: [0.22, 1, 0.36, 1], delay: 0.6 },
              },
            }}
            className="p-5 rounded-2xl bg-gradient-to-r from-blue-50/80 to-orange-50/80 border border-slate-200 shadow-md flex items-center justify-between"
          >
            <div>
              <h4 className="text-base font-extrabold text-[#0D3B8C]">Vision Ahead</h4>
              <p className="text-xs text-slate-600 font-medium mt-0.5">
                Creating a legacy of innovation that inspires future entrepreneurs at GHRCE.
              </p>
            </div>
            <div className="p-2.5 rounded-full bg-[#0D3B8C] text-white shrink-0 shadow-md">
              <Award className="w-5 h-5 text-[#F97316]" />
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};
