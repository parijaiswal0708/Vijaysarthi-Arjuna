import React, { useState } from 'react';
import { motion } from 'motion/react';
import confetti from 'canvas-confetti';
import { useApp } from '../context/AppContext';
import { Terminal, Send, CheckCircle2, AlertCircle, Sparkles, RefreshCw } from 'lucide-react';

export const TerminalContact: React.FC = () => {
  const { addContactMessage } = useApp();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [logs, setLogs] = useState<string[]>([
    'System Ready. Connected to Vijaysarthi Arjuna Gateway v2.6.',
    'Type your name, email ID, and message to dispatch directly to GHRCE E-Cell.',
  ]);
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !message) return;

    setIsSubmitting(true);
    setLogs((prev) => [
      ...prev,
      `$ ./send_message.sh --name "${name || 'Visitor'}" --email "${email}"`,
      '[STATUS] Transmitting message to Supabase Cloud Database...',
    ]);

    const res = await addContactMessage(email, message, name ? `From ${name}` : 'General Inquiry');

    if (res?.success) {
      setLogs((prev) => [
        ...prev,
        `[SUCCESS 200 OK] Message saved live to Supabase 'contact_messages' table!`,
        `[INFO] Target email: vijaysarthiarjuna@gmail.com`,
      ]);
    } else {
      setLogs((prev) => [
        ...prev,
        `[NOTICE] Stored in local app state. Supabase return error: ${res?.error || 'Table missing or RLS restriction.'}`,
        `[ACTION NEEDED] Ensure 'contact_messages' table exists by running 'supabase-schema.sql' in your Supabase SQL Editor.`,
      ]);
    }

    setIsSubmitting(false);
    setIsSent(true);

    const fireConfetti = typeof confetti === 'function' ? confetti : (confetti as any)?.default;
    if (typeof fireConfetti === 'function') {
      try {
        fireConfetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.7 },
          colors: ['#22C55E', '#0D3B8C', '#F97316'],
        });
      } catch (err) {
        console.warn('Confetti trigger failed:', err);
      }
    }
  };

  const handleResetForm = () => {
    setName('');
    setEmail('');
    setMessage('');
    setIsSent(false);
    setLogs([
      'System Ready. Connected to Vijaysarthi Arjuna Gateway v2.6.',
      'Type your email, subject, and message to dispatch directly to GHRCE E-Cell.',
    ]);
  };

  return (
    <div id="terminal-contact-section" className="py-20 bg-transparent relative z-10 overflow-hidden scroll-mt-24">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header - Slide from Left */}
        <motion.div
          initial={{ opacity: 0, x: -60 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="text-center max-w-2xl mx-auto mb-10"
        >
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
            <Terminal className="w-3.5 h-3.5 text-[#0D3B8C]" />
            <span>Developer Terminal Contact</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Connect With Team Vijaysarthi Arjuna
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-2">
            Send direct inquiries, partnership proposals, or mentorship requests via our command-line terminal interface.
          </p>
        </motion.div>

        {/* Terminal Window Card - Light Theme */}
        <motion.div
          initial={{ opacity: 0, x: 60, scale: 0.96 }}
          whileInView={{ opacity: 1, x: 0, scale: 1 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="rounded-2xl bg-white/80 backdrop-blur-xl text-slate-800 shadow-xl shadow-blue-950/5 border border-slate-200/90 overflow-hidden"
        >
          <div className="p-6 sm:p-8 text-xs sm:text-sm max-w-2xl mx-auto" style={{ fontFamily: '"Times New Roman", Times, serif' }}>
            {/* Form Input Area */}
            <div className="space-y-4">
              {!isSent ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-slate-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      Name
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Enter your full name"
                      style={{ fontFamily: '"Times New Roman", Times, serif' }}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 placeholder-slate-400 focus:outline-none focus:border-[#F97316] focus:bg-white transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      Email ID
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="your.email@domain.com"
                      style={{ fontFamily: '"Times New Roman", Times, serif' }}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 placeholder-slate-400 focus:outline-none focus:border-[#0D3B8C] focus:bg-white transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      Message
                    </label>
                    <textarea
                      required
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Type your message or query for Team Vijaysarthi Arjuna..."
                      style={{ fontFamily: '"Times New Roman", Times, serif' }}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-900 placeholder-slate-400 focus:outline-none focus:border-[#F97316] focus:bg-white transition-colors resize-none"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3 px-6 rounded-xl bg-[#F97316] hover:bg-orange-600 text-white font-bold font-sans text-sm shadow-lg shadow-orange-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Transmitting to Server...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Send Message</span>
                      </>
                    )}
                  </button>
                </form>
              ) : (
                <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-200/80 space-y-4">
                  <div className="flex items-center gap-3 text-emerald-600">
                    <CheckCircle2 className="w-8 h-8 shrink-0" />
                    <div>
                      <h4 className="font-bold font-sans text-base text-emerald-950">
                        Transmission Confirmed!
                      </h4>
                      <p className="text-xs text-emerald-700">
                        Your message has been routed to vijaysarthiarjuna@gmail.com
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={handleResetForm}
                    className="py-2 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-700 text-xs font-sans font-bold border border-slate-200 transition-colors flex items-center gap-2 shadow-sm"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Send Another Command</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
