import React from 'react';

interface LogoProps {
  className?: string;
  size?: number | string;
  showText?: boolean;
}

export const VijaysarthiArjunaIcon: React.FC<{ size?: number; className?: string }> = ({
  size = 48,
  className = '',
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 200 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 ${className}`}
    >
      {/* Left Side: Orange Growth Bar Chart */}
      <g>
        {/* Slanted Base Line */}
        <path d="M48 124 L94 102 L94 107 L48 129 Z" fill="#0D3B8C" />
        {/* Bar 1 */}
        <rect x="52" y="90" width="11" height="30" fill="#F97316" rx="1" />
        {/* Bar 2 */}
        <rect x="66" y="74" width="11" height="42" fill="#F97316" rx="1" />
        {/* Bar 3 */}
        <rect x="80" y="58" width="11" height="54" fill="#F97316" rx="1" />
      </g>

      {/* Right Side: Blue Tech Circuit Traces */}
      <g stroke="#0D3B8C" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round">
        {/* Path 1 */}
        <path d="M103 66 H145 L165 48 H182" />
        <circle cx="186" cy="48" r="4.5" fill="#FFFFFF" stroke="#0D3B8C" strokeWidth="3" />

        {/* Path 2 */}
        <path d="M103 80 H135 L150 64 H170" />
        <circle cx="174" cy="64" r="4.5" fill="#0D3B8C" stroke="none" />

        {/* Path 3 */}
        <path d="M103 94 H140 L155 80 H170" />
        <circle cx="174" cy="80" r="4.5" fill="#FFFFFF" stroke="#0D3B8C" strokeWidth="3" />

        {/* Path 4 */}
        <path d="M103 106 H130 L148 94 H182" />
        <circle cx="186" cy="94" r="4.5" fill="#0D3B8C" stroke="none" />

        {/* Path 5 */}
        <path d="M103 118 H124 L142 132 H170" />
        <circle cx="174" cy="132" r="4.5" fill="#FFFFFF" stroke="#0D3B8C" strokeWidth="3" />
      </g>

      {/* Central Upward Arrow */}
      {/* Arrowhead */}
      <path d="M100 12 L118 46 H105 V130 H95 V46 H82 L100 12 Z" fill="#0D3B8C" />

      {/* Fletching (Tail) with Orange Stripes */}
      <path d="M84 126 L100 148 L116 126 V164 L100 184 L84 164 Z" fill="#0D3B8C" />
      <path d="M88 136 L100 152 L112 136 L112 144 L100 160 L88 144 Z" fill="#F97316" />
      <path d="M88 152 L100 168 L112 152 L112 160 L100 176 L88 160 Z" fill="#F97316" />
    </svg>
  );
};

export const VijaysarthiArjunaLogo: React.FC<LogoProps> = ({
  className = '',
  size = 48,
  showText = true,
}) => {
  const [imgError, setImgError] = React.useState(false);
  const numSize = typeof size === 'number' ? size : parseInt(String(size)) || 48;

  return (
    <div className={`inline-flex items-center gap-3 transition-all duration-300 ${className}`}>
      <div className="bg-white p-1 rounded-xl shrink-0 flex items-center justify-center border border-slate-100 shadow-2xs">
        {!imgError ? (
          <img
            src="https://i.ibb.co/MDTWNkfx/logo-jpeg-removebg-preview.png"
            alt="Vijaysarthi Arjuna Logo"
            referrerPolicy="no-referrer"
            className="shrink-0 object-contain rounded-lg"
            style={{ width: `${numSize}px`, height: `${numSize}px` }}
            onError={() => setImgError(true)}
          />
        ) : (
          <VijaysarthiArjunaIcon size={numSize} />
        )}
      </div>

      {showText && (
        <div className="flex flex-col">
          <span className="font-extrabold text-base md:text-lg tracking-wider text-[#0D3B8C] leading-none uppercase">
            VIJAYSARTHI
          </span>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="h-[2px] w-3 bg-[#F97316] rounded-full"></span>
            <span className="text-[10px] md:text-xs font-bold tracking-widest text-[#F97316] uppercase">
              ARJUNA
            </span>
            <span className="h-[2px] w-3 bg-[#F97316] rounded-full"></span>
          </div>
          <span className="text-[9px] md:text-[10px] font-extrabold tracking-widest text-slate-500 uppercase mt-0.5">
            FIGHT • AIM • WIN
          </span>
        </div>
      )}
    </div>
  );
};

export const ECellGhrceLogo: React.FC<{ className?: string; size?: number; lightText?: boolean }> = ({
  className = '',
  size = 38,
  lightText = false,
}) => {
  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Official GHRCE E-Cell Emblem Image */}
      <img
        src="https://i.ibb.co/Mxdf8bqN/ecell.png"
        alt="GHRCE E-Cell Logo"
        referrerPolicy="no-referrer"
        className="shrink-0 object-contain"
        style={{ height: `${size}px`, width: 'auto' }}
      />

      {/* Typography: GHRCE E-CELL */}

      {/* Typography: GHRCE E-CELL */}
      <div className="flex flex-col text-left leading-none justify-center">
        <span
          className={`font-sans font-bold uppercase tracking-widest text-[11px] sm:text-[12px] mb-[2px] ${
            lightText ? 'text-slate-300' : 'text-slate-600'
          }`}
        >
          GHRCE
        </span>
        <span
          className={`font-serif font-black uppercase tracking-tight text-[17px] sm:text-[19px] ${
            lightText ? 'text-purple-300' : 'text-[#5B2192]'
          }`}
          style={{ fontFamily: 'Georgia, serif', fontWeight: 900 }}
        >
          E-CELL
        </span>
      </div>
    </div>
  );
};

export const GhrceCollegeLogo: React.FC<{ className?: string; size?: number; showText?: boolean }> = ({
  className = '',
  size = 38,
  showText = true,
}) => {
  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* GH Raisoni Lion Shield Symbol */}
      <svg
        width={size}
        height={Math.round(size * 1.05)}
        viewBox="0 0 100 105"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
      >
        {/* Outer Shield Box with Purple Border */}
        <rect x="3" y="3" width="94" height="99" rx="16" fill="#FFFFFF" stroke="#592B88" strokeWidth="6" />

        {/* Right Orange Fill */}
        <path d="M64 6 H80 C89 6 96 13 96 22 V83 C96 92 89 99 80 99 H64 V6 Z" fill="#E05226" />

        {/* Four-Point Sparkle in Top Right Orange Area */}
        <path d="M80 18 L82 23 L87 25 L82 27 L80 32 L78 27 L73 25 L78 23 Z" fill="#592B88" />

        {/* Left Purple Lion Background */}
        <path
          d="M12 28 C12 18 20 10 30 10 H64 V95 H30 C20 95 12 87 12 77 V28 Z"
          fill="#592B88"
        />

        {/* White Lion Profile Lines & Head */}
        <path
          d="M18 36 C24 30 32 32 38 38 C42 32 50 32 54 38 C60 32 68 36 72 44 C76 52 74 62 68 68 C62 74 54 76 48 70 C42 76 34 76 28 70 C24 68 20 60 22 50 C24 42 18 40 18 36 Z"
          fill="#FFFFFF"
        />

        {/* Inner Purple Mane Detailing */}
        <path d="M22 42 C26 38 32 40 36 46" stroke="#592B88" strokeWidth="3" strokeLinecap="round" fill="none" />
        <path d="M26 52 C30 48 36 50 40 56" stroke="#592B88" strokeWidth="3" strokeLinecap="round" fill="none" />
        <path d="M30 62 C34 58 40 60 44 66" stroke="#592B88" strokeWidth="3" strokeLinecap="round" fill="none" />

        {/* Lion Eye */}
        <circle cx="58" cy="46" r="3" fill="#592B88" />

        {/* Orange Snout Contour */}
        <path d="M68 54 C74 56 74 64 66 68" stroke="#E05226" strokeWidth="4" strokeLinecap="round" fill="none" />
      </svg>

      {showText && (
        <div className="flex flex-col text-left font-sans leading-none">
          <div className="flex items-baseline gap-[2px]">
            <span className="text-[#592B88] font-black text-[15px] tracking-tight">G H</span>
            <span className="text-[#592B88] font-extrabold text-[15px] tracking-tight lowercase">raisoni</span>
          </div>
          <span className="text-[#E05226] font-black text-[12px] tracking-wider uppercase mt-[2px] mb-[2px]">
            COLLEGE
          </span>
          <div className="h-[1.5px] w-full bg-[#592B88] my-[1px]" />
          <span className="text-[#4A5568] font-medium text-[10px] tracking-tight mt-[1px]">
            Engineering
          </span>
          <span className="text-[#E05226] font-bold text-[10px] tracking-tight">
            Nagpur
          </span>
        </div>
      )}
    </div>
  );
};

export const IitbNecLogo: React.FC<{ className?: string; size?: number }> = ({
  className = '',
  size = 36,
}) => {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="100" height="100" rx="20" fill="#0D3B8C" />
        <path d="M50 18 L68 75 H32 L50 18 Z" fill="#2563EB" />
        <path d="M50 18 L58 75 H42 L50 18 Z" fill="#60A5FA" />
        <circle cx="50" cy="42" r="8" fill="#F97316" />
        <path d="M42 82 H58" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" />
      </svg>
      <div className="flex flex-col">
        <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest leading-none">IIT BOMBAY</span>
        <span className="text-xs font-extrabold text-[#0D3B8C] leading-none">NEC 2026</span>
      </div>
    </div>
  );
};
