import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Shield,
  LogOut,
  Plus,
  Trash2,
  Edit,
  Users,
  Image as ImageIcon,
  FileText,
  HelpCircle,
  Clock,
  Mail,
  Linkedin,
  Instagram,
  CheckCircle2,
  X,
  Lock,
  RotateCcw,
  Calendar,
  Sparkles,
  Zap,
  Settings,
  Database,
  RefreshCw,
  Volume2,
  VolumeX,
  Type,
  Eye,
  UploadCloud,
  Sliders,
} from 'lucide-react';
import { TeamMember, GalleryItem, ResourceItem, FAQItem, MilestoneItem, EventItem } from '../types';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

export const AdminDashboard: React.FC = () => {
  const {
    isAdminLoggedIn,
    setIsAdminLoggedIn,
    showAdminModal,
    setShowAdminModal,
    setShowSettingsDrawer,
    settings,
    updateSettings,
    isSupabaseActive,
    syncStatus,
    dbError,
    pushAllDataToSupabase,
    refetchAllData,
    teamMembers,
    addTeamMember,
    updateTeamMember,
    deleteTeamMember,
    galleryItems,
    addGalleryItem,
    updateGalleryItem,
    deleteGalleryItem,
    resources,
    addResource,
    updateResource,
    deleteResource,
    faqs,
    addFAQ,
    updateFAQ,
    deleteFAQ,
    milestones,
    addMilestone,
    updateMilestone,
    deleteMilestone,
    contactMessages,
    markMessageReplied,
    deleteContactMessage,
    events,
    addEvent,
    updateEvent,
    deleteEvent,
    resetToDefaultData,
  } = useApp();

  // Login Form State
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Active Admin Tab
  const [adminTab, setAdminTab] = useState<
    'events' | 'team' | 'gallery' | 'resources' | 'faq' | 'timeline' | 'messages' | 'settings'
  >('events');

  // Status Banner State
  const [actionBanner, setActionBanner] = useState<string | null>(null);
  const [isSyncingData, setIsSyncingData] = useState(false);

  const showNotification = (msg: string) => {
    setActionBanner(msg);
    setTimeout(() => setActionBanner(null), 4000);
  };

  const handlePushAllData = async () => {
    setIsSyncingData(true);
    const res = await pushAllDataToSupabase();
    setIsSyncingData(false);
    showNotification(res.message);
  };

  const handleRefetchData = async () => {
    setIsSyncingData(true);
    await refetchAllData();
    setIsSyncingData(false);
    showNotification('Latest data successfully fetched from database!');
  };

  // Editing Modals
  const [editingTeam, setEditingTeam] = useState<Partial<TeamMember> | null>(null);
  const [editingGallery, setEditingGallery] = useState<Partial<GalleryItem> | null>(null);
  const [editingResource, setEditingResource] = useState<Partial<ResourceItem> | null>(null);
  const [editingFaq, setEditingFaq] = useState<Partial<FAQItem> | null>(null);
  const [editingMilestone, setEditingMilestone] = useState<Partial<MilestoneItem> | null>(null);
  const [editingEvent, setEditingEvent] = useState<Partial<EventItem> | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    // Try Supabase Auth if credentials configured
    if (isSupabaseConfigured) {
      try {
        const { error } = await supabase.auth.signInWithPassword({
          email: username.includes('@') ? username : `${username}@ecell.internal`,
          password,
        });

        if (!error) {
          setIsAdminLoggedIn(true);
          return;
        }
      } catch (err) {
        console.warn('Supabase Auth login attempt:', err);
      }
    }

    // Default password check
    if (username === 'admin' && password === 'nec2026') {
      setIsAdminLoggedIn(true);
      setLoginError('');
    } else {
      setLoginError('Invalid username or password');
    }
  };

  const closeAdminPortal = () => {
    setShowAdminModal(false);
    setShowSettingsDrawer(false);
  };

  if (!showAdminModal) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/70 backdrop-blur-md transition-opacity"
        onClick={closeAdminPortal}
      ></div>

      {/* Main Admin Modal Container */}
      <div className="relative w-full max-w-5xl bg-white rounded-3xl shadow-2xl z-10 border border-slate-200 overflow-hidden my-8 animate-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500 text-slate-950 font-bold">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Admin Management Portal</h3>
              <p className="text-xs text-slate-400">
                Manage Vijaysarthi Arjuna website content & resources
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAdminLoggedIn && (
              <button
                onClick={() => setIsAdminLoggedIn(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5 text-amber-400" />
                <span>Logout</span>
              </button>
            )}
            <button
              onClick={closeAdminPortal}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Area */}
        {!isAdminLoggedIn ? (
          /* LOGIN SCREEN */
          <div className="p-8 sm:p-12 text-center max-w-md mx-auto my-auto space-y-6">
            <div className="p-4 rounded-3xl bg-amber-50 border border-amber-200 inline-block text-amber-600">
              <Lock className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h4 className="text-2xl font-extrabold text-slate-900">Admin Authentication</h4>
              <p className="text-xs text-slate-500">
                Enter your administrative credentials to manage content.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4 text-left">
              {loginError && (
                <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-600 text-xs font-bold text-center">
                  {loginError}
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Username
                </label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter username"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Password
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-amber-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-sm shadow-md transition-all"
              >
                Authenticate Dashboard
              </button>
            </form>
          </div>
        ) : (
          /* LOGGED IN DASHBOARD */
          <div className="flex-1 overflow-hidden flex flex-col">
            {/* Tabs Bar */}
            <div className="bg-slate-100 border-b border-slate-200 px-6 pt-3 flex items-center gap-2 overflow-x-auto shrink-0">
              {[
                { id: 'events', label: 'Events', icon: Calendar, count: events.length },
                { id: 'team', label: 'Team Members', icon: Users, count: teamMembers.length },
                { id: 'gallery', label: 'Gallery', icon: ImageIcon, count: galleryItems.length },
                { id: 'resources', label: 'Resources', icon: FileText, count: resources.length },
                { id: 'timeline', label: 'Timeline', icon: Clock, count: milestones.length },
                { id: 'faq', label: 'FAQs', icon: HelpCircle, count: faqs.length },
                { id: 'messages', label: 'Messages', icon: Mail, count: contactMessages.length },
                { id: 'settings', label: 'Site Settings & DB', icon: Settings, count: 'Global' },
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = adminTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setAdminTab(tab.id as typeof adminTab)}
                    className={`px-4 py-2.5 rounded-t-xl text-xs font-bold transition-all flex items-center gap-2 border-t border-x shrink-0 ${
                      isActive
                        ? 'bg-white text-[#0D3B8C] border-slate-200 font-extrabold'
                        : 'bg-slate-100 text-slate-600 border-transparent hover:bg-slate-200'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                    <span className="px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 text-[10px]">
                      {tab.count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Tab Body View */}
            <div className="p-6 overflow-y-auto flex-1 space-y-6">
              {/* TAB 0: MANAGE EVENTS */}
              {adminTab === 'events' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-lg font-bold text-slate-900">Manage Events & Registrations</h4>
                      <p className="text-xs text-slate-500">Add, edit, or delete events, descriptions, photos, and Luma registration links.</p>
                    </div>
                    <button
                      onClick={() =>
                        setEditingEvent({
                          title: '',
                          tagline: '',
                          category: 'Competition',
                          status: 'Registration Open',
                          date: 'March 2026',
                          time: '10:00 AM IST',
                          venue: 'GHRCE Campus',
                          prizePool: '₹10,000 Cash Prizes',
                          description: '',
                          highlights: ['Mentorship & Certificate', 'Networking Opportunity'],
                          eligibility: 'Open to all students',
                          lumaEventId: 'evt-3hgeOcdbkW0vOQn',
                          lumaUrl: 'https://luma.com/event/evt-3hgeOcdbkW0vOQn',
                          imageUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&q=80&w=1200',
                          isFeatured: false,
                        })
                      }
                      className="px-4 py-2 rounded-xl bg-[#0D3B8C] text-white text-xs font-bold flex items-center gap-1.5 shadow-md hover:bg-blue-900 transition-colors cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add New Event</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {events.map((evt) => (
                      <div
                        key={evt.id}
                        className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between space-y-3"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-[#0D3B8C] font-extrabold text-[10px] uppercase">
                                {evt.category}
                              </span>
                              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                                {evt.status}
                              </span>
                              {evt.isFeatured && (
                                <span className="px-2 py-0.5 rounded-full bg-orange-100 text-orange-700 font-extrabold text-[10px]">
                                  Featured
                                </span>
                              )}
                            </div>
                            <h5 className="font-bold text-slate-900 text-base">{evt.title}</h5>
                            <p className="text-xs text-orange-600 font-medium">{evt.tagline}</p>
                          </div>

                          {evt.imageUrl && (
                            <img
                              src={evt.imageUrl}
                              alt={evt.title}
                              className="w-16 h-16 rounded-xl object-cover shrink-0 border border-slate-200"
                            />
                          )}
                        </div>

                        <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                          {evt.description}
                        </p>

                        <div className="text-[11px] text-slate-500 space-y-1 bg-white p-2.5 rounded-xl border border-slate-150">
                          <div><strong className="text-slate-700">Date:</strong> {evt.date} {evt.time ? `• ${evt.time}` : ''}</div>
                          <div><strong className="text-slate-700">Venue:</strong> {evt.venue}</div>
                          {evt.lumaUrl && (
                            <div className="truncate"><strong className="text-slate-700">Luma Link:</strong> <a href={evt.lumaUrl} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">{evt.lumaUrl}</a></div>
                          )}
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                          <span className="text-[10px] text-slate-400 font-medium">ID: {evt.id}</span>
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => setEditingEvent(evt)}
                              className="px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                            >
                              <Edit className="w-3.5 h-3.5" />
                              <span>Edit</span>
                            </button>
                            <button
                              onClick={() => deleteEvent(evt.id)}
                              className="px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Delete</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 1: MANAGE TEAM */}
              {adminTab === 'team' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-lg font-bold text-slate-900">Manage Team Members</h4>
                    <button
                      onClick={() =>
                        setEditingTeam({
                          name: '',
                          role: '',
                          category: 'domain',
                          department: 'CSE',
                          year: '3rd Year',
                          image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=600',
                          description: '',
                          linkedin: 'https://linkedin.com',
                          instagram: 'https://instagram.com',
                          email: 'member@ghrce.edu.in',
                        })
                      }
                      className="px-4 py-2 rounded-xl bg-[#0D3B8C] text-white text-xs font-bold flex items-center gap-1.5 shadow-md"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Member</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {teamMembers.map((m) => (
                      <div
                        key={m.id}
                        className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between gap-3 shadow-2xs hover:shadow-xs transition-shadow"
                      >
                        <div className="flex items-center justify-between gap-3">
                          <div className="flex items-center gap-3 min-w-0">
                            <img
                              src={m.image}
                              alt={m.name}
                              className="w-12 h-12 rounded-xl object-cover shrink-0 border border-slate-200"
                            />
                            <div className="min-w-0 flex-1">
                              <div className="text-xs font-bold text-slate-900 truncate">{m.name}</div>
                              <div className="text-[11px] text-[#F97316] font-semibold truncate">{m.role}</div>
                              <div className="text-[10px] text-slate-400 capitalize">{m.category} team</div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              onClick={() => setEditingTeam(m)}
                              className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-100 transition-colors"
                              title="Edit Member"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => deleteTeamMember(m.id)}
                              className="p-1.5 rounded-lg text-red-600 hover:bg-red-100 transition-colors"
                              title="Delete Member"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {/* Clickable Social Links Row */}
                        <div className="pt-2 border-t border-slate-200/80 flex items-center gap-1.5 flex-wrap">
                          {m.linkedin ? (
                            <a
                              href={m.linkedin}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-blue-50 hover:bg-blue-100 border border-blue-200 text-[#0D3B8C] font-semibold text-[11px] transition-colors"
                              title={`Open ${m.name}'s LinkedIn`}
                            >
                              <Linkedin className="w-3 h-3 text-blue-600 shrink-0" />
                              <span>LinkedIn</span>
                            </a>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-100 text-slate-400 text-[10px] font-medium">
                              No LinkedIn
                            </span>
                          )}

                          {m.instagram ? (
                            <a
                              href={m.instagram}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-pink-50 hover:bg-pink-100 border border-pink-200 text-pink-700 font-semibold text-[11px] transition-colors"
                              title={`Open ${m.name}'s Instagram`}
                            >
                              <Instagram className="w-3 h-3 text-pink-600 shrink-0" />
                              <span>Insta</span>
                            </a>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-100 text-slate-400 text-[10px] font-medium">
                              No Insta
                            </span>
                          )}

                          {m.email ? (
                            <a
                              href={`mailto:${m.email}`}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 font-semibold text-[11px] transition-colors"
                              title={`Email ${m.name}`}
                            >
                              <Mail className="w-3 h-3 text-emerald-600 shrink-0" />
                              <span>Email</span>
                            </a>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-100 text-slate-400 text-[10px] font-medium">
                              No Email
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 2: MANAGE GALLERY */}
              {adminTab === 'gallery' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-lg font-bold text-slate-900">Manage Gallery & Media</h4>
                    <button
                      onClick={() =>
                        setEditingGallery({
                          title: '',
                          description: '',
                          type: 'image',
                          category: 'Featured Photos',
                          url: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&q=80&w=1200',
                          uploadDate: new Date().toISOString().split('T')[0],
                        })
                      }
                      className="px-4 py-2 rounded-xl bg-[#0D3B8C] text-white text-xs font-bold flex items-center gap-1.5 shadow-md"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Media Item</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {galleryItems.map((g) => (
                      <div
                        key={g.id}
                        className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between space-y-2"
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={g.thumbnail || g.url}
                            alt={g.title}
                            className="w-16 h-12 rounded-xl object-cover shrink-0"
                          />
                          <div className="overflow-hidden">
                            <div className="text-xs font-bold text-slate-900 truncate">
                              {g.title}
                            </div>
                            <div className="text-[10px] text-slate-500">{g.category}</div>
                          </div>
                        </div>

                        <div className="flex items-center justify-end gap-1 pt-2 border-t border-slate-200">
                          <button
                            onClick={() => setEditingGallery(g)}
                            className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-100"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => deleteGalleryItem(g.id)}
                            className="p-1.5 rounded-lg text-red-600 hover:bg-red-100"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: MANAGE RESOURCES */}
              {adminTab === 'resources' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-lg font-bold text-slate-900">Manage Resources & PPTs</h4>
                    <button
                      onClick={() =>
                        setEditingResource({
                          title: '',
                          description: '',
                          category: 'Reports',
                          fileType: 'pdf',
                          fileSize: '2.5 MB',
                          downloadUrl: '#',
                          uploadDate: new Date().toISOString().split('T')[0],
                          tags: ['NEC 2026', 'GHRCE'],
                        })
                      }
                      className="px-4 py-2 rounded-xl bg-[#0D3B8C] text-white text-xs font-bold flex items-center gap-1.5 shadow-md"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Upload Resource</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    {resources.map((r) => (
                      <div
                        key={r.id}
                        className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <div className="text-sm font-bold text-slate-900">{r.title}</div>
                          <div className="text-xs text-slate-500">
                            {r.category} • {r.fileType.toUpperCase()} ({r.fileSize}) • Downloads: {r.downloadsCount}
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => setEditingResource(r)}
                            className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-100"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => deleteResource(r.id)}
                            className="p-1.5 rounded-lg text-red-600 hover:bg-red-100"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 4: MANAGE TIMELINE */}
              {adminTab === 'timeline' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-lg font-bold text-slate-900">Manage Timeline & Milestones</h4>
                    <button
                      onClick={() =>
                        setEditingMilestone({
                          title: '',
                          phase: 'Phase 1',
                          date: '2026',
                          status: 'Upcoming',
                          description: '',
                          deliverables: ['Deliverable 1'],
                        })
                      }
                      className="px-4 py-2 rounded-xl bg-[#0D3B8C] text-white text-xs font-bold flex items-center gap-1.5 shadow-md"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Milestone</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    {milestones.map((m) => (
                      <div
                        key={m.id}
                        className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-4"
                      >
                        <div>
                          <div className="text-sm font-bold text-slate-900">{m.title}</div>
                          <div className="text-xs text-slate-500">
                            {m.phase} • {m.date} • <strong className="text-[#F97316]">{m.status}</strong>
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => setEditingMilestone(m)}
                            className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-100"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => deleteMilestone(m.id)}
                            className="p-1.5 rounded-lg text-red-600 hover:bg-red-100"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 5: MANAGE FAQS */}
              {adminTab === 'faq' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-lg font-bold text-slate-900">Manage FAQs</h4>
                    <button
                      onClick={() =>
                        setEditingFaq({
                          question: '',
                          answer: '',
                          category: 'General',
                        })
                      }
                      className="px-4 py-2 rounded-xl bg-[#0D3B8C] text-white text-xs font-bold flex items-center gap-1.5 shadow-md"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add FAQ</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    {faqs.map((f) => (
                      <div
                        key={f.id}
                        className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-4"
                      >
                        <div>
                          <div className="text-sm font-bold text-slate-900">{f.question}</div>
                          <div className="text-xs text-slate-500">{f.answer}</div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => setEditingFaq(f)}
                            className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-100"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => deleteFAQ(f.id)}
                            className="p-1.5 rounded-lg text-red-600 hover:bg-red-100"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 6: CONTACT MESSAGES */}
              {adminTab === 'messages' && (
                <div className="space-y-4">
                  <h4 className="text-lg font-bold text-slate-900">Contact Terminal Inquiries</h4>
                  <div className="space-y-3">
                    {contactMessages.map((msg) => (
                      <div
                        key={msg.id}
                        className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-[#0D3B8C]">{msg.email}</span>
                          <span className="text-[10px] text-slate-400">{msg.timestamp}</span>
                        </div>
                        <div className="text-xs font-bold text-slate-800">{msg.subject}</div>
                        <p className="text-xs text-slate-600">{msg.message}</p>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs">
                          <span className="text-[10px] font-bold">
                            Status:{' '}
                            {msg.replied ? (
                              <span className="text-emerald-600">Replied</span>
                            ) : (
                              <span className="text-amber-600">Pending Response</span>
                            )}
                          </span>

                          <div className="flex items-center gap-2">
                            {!msg.replied && (
                              <button
                                onClick={() => markMessageReplied(msg.id)}
                                className="px-3 py-1 rounded-lg bg-emerald-100 text-emerald-800 font-bold text-[10px]"
                              >
                                Mark Replied
                              </button>
                            )}
                            <button
                              onClick={() => deleteContactMessage(msg.id)}
                              className="p-1 text-red-600 hover:bg-red-100 rounded"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 7: SITE SETTINGS & CLOUD DB CONTROL */}
              {adminTab === 'settings' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-lg font-bold text-slate-900">Site Settings & Global Cloud DB Synchronization</h4>
                      <p className="text-xs text-slate-500">
                        Manage global platform settings, audio FX, layout display, and sync local data with Supabase Cloud DB.
                      </p>
                    </div>
                    {actionBanner && (
                      <div className="px-3.5 py-1.5 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-900 text-xs font-bold flex items-center gap-1.5 animate-bounce">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>{actionBanner}</span>
                      </div>
                    )}
                  </div>

                  {/* 1. Supabase Cloud Database Control Center */}
                  <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-[#0D3B8C] text-white space-y-4 shadow-xl">
                    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-3">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-md">
                          <Database className="w-5 h-5 text-amber-400" />
                        </div>
                        <div>
                          <div className="text-sm font-bold flex items-center gap-2">
                            <span>Supabase Cloud Database</span>
                            <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                              syncStatus === 'synced'
                                ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-500/50'
                                : syncStatus === 'error'
                                ? 'bg-rose-500/30 text-rose-300 border border-rose-500/50'
                                : 'bg-amber-500/30 text-amber-300 border border-amber-500/50'
                            }`}>
                              {isSupabaseActive ? syncStatus : 'Memory Mode'}
                            </span>
                          </div>
                          <p className="text-xs text-slate-300 mt-0.5">
                            {isSupabaseActive
                              ? 'Connected & synchronized globally. Real-time updates active.'
                              : 'Credentials not configured in environment. Data runs in memory mode.'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={handlePushAllData}
                          disabled={isSyncingData}
                          className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all flex items-center gap-2 shadow-md cursor-pointer disabled:opacity-50"
                        >
                          <UploadCloud className="w-4 h-4" />
                          <span>{isSyncingData ? 'Uploading to DB...' : 'Push All Local Data to Supabase DB'}</span>
                        </button>

                        <button
                          onClick={handleRefetchData}
                          className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer"
                        >
                          <RefreshCw className={`w-3.5 h-3.5 ${isSyncingData ? 'animate-spin' : ''}`} />
                          <span>Fetch Latest</span>
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                      <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1">
                        <div className="text-slate-400 font-medium">Realtime Subscriptions</div>
                        <div className="font-bold text-emerald-400 flex items-center gap-1">
                          <Zap className="w-3.5 h-3.5" />
                          <span>Active (PostgreSQL Channels)</span>
                        </div>
                      </div>
                      <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1">
                        <div className="text-slate-400 font-medium">Total Collections Managed</div>
                        <div className="font-bold text-white">7 Tables + App Settings</div>
                      </div>
                      <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1">
                        <div className="text-slate-400 font-medium">Global Synchronization</div>
                        <div className="font-bold text-amber-400">Updates live on hosted site</div>
                      </div>
                    </div>
                  </div>

                  {/* 2. Site-wide Audio & Visual Preferences */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Audio & Sound FX */}
                    <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                      <div className="flex items-center gap-2 text-sm font-bold text-slate-900 border-b border-slate-200 pb-2">
                        <Volume2 className="w-4 h-4 text-[#0D3B8C]" />
                        <span>Audio & Sound Effects</span>
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-xs font-bold text-slate-800">Sound Effects Enabled</div>
                          <div className="text-[11px] text-slate-500">Play archery bow release & interactive sounds</div>
                        </div>
                        <button
                          onClick={() => {
                            updateSettings({ soundEnabled: !settings.soundEnabled });
                            showNotification('Sound FX preference updated!');
                          }}
                          className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                            settings.soundEnabled ? 'bg-[#0D3B8C]' : 'bg-slate-300'
                          }`}
                        >
                          <div
                            className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                              settings.soundEnabled ? 'translate-x-6' : 'translate-x-0'
                            }`}
                          ></div>
                        </button>
                      </div>
                    </div>

                    {/* Background Particles */}
                    <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                      <div className="flex items-center gap-2 text-sm font-bold text-slate-900 border-b border-slate-200 pb-2">
                        <Sparkles className="w-4 h-4 text-orange-500" />
                        <span>Background Particle Density</span>
                      </div>

                      <div className="space-y-2">
                        <div className="text-xs font-bold text-slate-800">Particle FX Density</div>
                        <div className="grid grid-cols-3 gap-2">
                          {(['low', 'medium', 'high'] as const).map((density) => (
                            <button
                              key={density}
                              onClick={() => {
                                updateSettings({ particleDensity: density });
                                showNotification(`Particle density set to ${density}`);
                              }}
                              className={`py-2 text-xs font-bold rounded-xl border transition-all capitalize ${
                                settings.particleDensity === density
                                  ? 'bg-[#0D3B8C] text-white border-[#0D3B8C] shadow-xs'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                              }`}
                            >
                              {density}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Accessibility & Scaling */}
                    <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                      <div className="flex items-center gap-2 text-sm font-bold text-slate-900 border-b border-slate-200 pb-2">
                        <Type className="w-4 h-4 text-[#0D3B8C]" />
                        <span>Text Size & Typography Scaling</span>
                      </div>

                      <div className="space-y-2">
                        <div className="text-xs font-bold text-slate-800">Font Scale Across Website</div>
                        <div className="grid grid-cols-3 gap-2">
                          {(['normal', 'large', 'xlarge'] as const).map((scale) => (
                            <button
                              key={scale}
                              onClick={() => {
                                updateSettings({ fontSizeScale: scale });
                                showNotification(`Text scale set to ${scale}`);
                              }}
                              className={`py-2 text-xs font-bold rounded-xl border transition-all capitalize ${
                                settings.fontSizeScale === scale
                                  ? 'bg-[#0D3B8C] text-white border-[#0D3B8C] shadow-xs'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                              }`}
                            >
                              {scale === 'xlarge' ? 'XL (115%)' : scale === 'large' ? 'Large (105%)' : 'Normal (100%)'}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Accessibility Toggles */}
                    <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                      <div className="flex items-center gap-2 text-sm font-bold text-slate-900 border-b border-slate-200 pb-2">
                        <Eye className="w-4 h-4 text-slate-700" />
                        <span>Accessibility Controls</span>
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-xs font-bold text-slate-800">Reduced Motion</div>
                            <div className="text-[11px] text-slate-500">Simplify complex canvas animations</div>
                          </div>
                          <button
                            onClick={() => {
                              updateSettings({ reducedMotion: !settings.reducedMotion });
                              showNotification('Reduced motion toggle updated!');
                            }}
                            className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                              settings.reducedMotion ? 'bg-[#0D3B8C]' : 'bg-slate-300'
                            }`}
                          >
                            <div
                              className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                                settings.reducedMotion ? 'translate-x-6' : 'translate-x-0'
                              }`}
                            ></div>
                          </button>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                          <div>
                            <div className="text-xs font-bold text-slate-800">High Contrast Mode</div>
                            <div className="text-[11px] text-slate-500">Enhanced border & text contrast</div>
                          </div>
                          <button
                            onClick={() => {
                              updateSettings({ highContrast: !settings.highContrast });
                              showNotification('High contrast toggle updated!');
                            }}
                            className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                              settings.highContrast ? 'bg-[#0D3B8C]' : 'bg-slate-300'
                            }`}
                          >
                            <div
                              className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                                settings.highContrast ? 'translate-x-6' : 'translate-x-0'
                              }`}
                            ></div>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 3. Database Factory Reset Action */}
                  <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                    <div className="space-y-0.5">
                      <div className="font-bold text-amber-900 flex items-center gap-1.5">
                        <RotateCcw className="w-4 h-4 text-amber-600" />
                        <span>Reset All Platform Data to Default Seed State</span>
                      </div>
                      <p className="text-amber-800">Replaces database tables with original NEC 2026 Vijaysarthi seed content.</p>
                    </div>
                    <button
                      onClick={() => {
                        if (confirm('Are you sure you want to reset all database collections to default seed data?')) {
                          resetToDefaultData();
                          showNotification('Database reset to seed data!');
                        }
                      }}
                      className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition-colors shadow-xs cursor-pointer"
                    >
                      Reset Seed Data
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TEAM MEMBER FORM MODAL */}
        {editingTeam && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <div className="bg-white p-6 rounded-3xl w-full max-w-lg space-y-4 shadow-2xl">
              <h4 className="text-lg font-bold text-slate-900">
                {editingTeam.id ? 'Edit Team Member' : 'Add Team Member'}
              </h4>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold mb-1">Full Name</label>
                  <input
                    type="text"
                    value={editingTeam.name || ''}
                    onChange={(e) => setEditingTeam({ ...editingTeam, name: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">Role / Designation</label>
                  <input
                    type="text"
                    value={editingTeam.role || ''}
                    onChange={(e) => setEditingTeam({ ...editingTeam, role: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold mb-1">Category</label>
                    <select
                      value={editingTeam.category || 'domain'}
                      onChange={(e) =>
                        setEditingTeam({
                          ...editingTeam,
                          category: e.target.value as 'core' | 'domain' | 'member',
                        })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    >
                      <option value="core">Core Team</option>
                      <option value="domain">Domain Lead</option>
                      <option value="member">Associate</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold mb-1">Department</label>
                    <input
                      type="text"
                      value={editingTeam.department || ''}
                      onChange={(e) =>
                        setEditingTeam({ ...editingTeam, department: e.target.value })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold mb-1">Year</label>
                    <input
                      type="text"
                      value={editingTeam.year || ''}
                      onChange={(e) =>
                        setEditingTeam({ ...editingTeam, year: e.target.value })
                      }
                      placeholder="e.g. 3rd Year"
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>
                  <div>
                    <label className="block font-bold mb-1">Email</label>
                    <input
                      type="email"
                      value={editingTeam.email || ''}
                      onChange={(e) =>
                        setEditingTeam({ ...editingTeam, email: e.target.value })
                      }
                      placeholder="email@ghrce.edu.in"
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold mb-1">LinkedIn URL</label>
                    <input
                      type="text"
                      value={editingTeam.linkedin || ''}
                      onChange={(e) =>
                        setEditingTeam({ ...editingTeam, linkedin: e.target.value })
                      }
                      placeholder="https://linkedin.com/in/..."
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>
                  <div>
                    <label className="block font-bold mb-1">Instagram URL</label>
                    <input
                      type="text"
                      value={editingTeam.instagram || ''}
                      onChange={(e) =>
                        setEditingTeam({ ...editingTeam, instagram: e.target.value })
                      }
                      placeholder="https://instagram.com/..."
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold mb-1">Image URL</label>
                  <input
                    type="text"
                    value={editingTeam.image || ''}
                    onChange={(e) => setEditingTeam({ ...editingTeam, image: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">Bio / Role Description</label>
                  <textarea
                    rows={2}
                    value={editingTeam.description || ''}
                    onChange={(e) =>
                      setEditingTeam({ ...editingTeam, description: e.target.value })
                    }
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  ></textarea>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  onClick={() => setEditingTeam(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (editingTeam.id) {
                      updateTeamMember(editingTeam.id, editingTeam);
                    } else {
                      addTeamMember(editingTeam as Omit<TeamMember, 'id'>);
                    }
                    setEditingTeam(null);
                  }}
                  className="px-5 py-2 rounded-xl bg-[#0D3B8C] text-white text-xs font-bold shadow"
                >
                  Save Member
                </button>
              </div>
            </div>
          </div>
        )}

        {/* GALLERY ITEM FORM MODAL */}
        {editingGallery && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <div className="bg-white p-6 rounded-3xl w-full max-w-lg space-y-4 shadow-2xl">
              <h4 className="text-lg font-bold text-slate-900">
                {editingGallery.id ? 'Edit Gallery Media' : 'Add Gallery Media'}
              </h4>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold mb-1">Title</label>
                  <input
                    type="text"
                    value={editingGallery.title || ''}
                    onChange={(e) => setEditingGallery({ ...editingGallery, title: e.target.value })}
                    placeholder="Media Title"
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold mb-1">Category</label>
                    <select
                      value={editingGallery.category || 'Featured Photos'}
                      onChange={(e) =>
                        setEditingGallery({
                          ...editingGallery,
                          category: e.target.value as 'Achievements' | 'Featured Photos' | 'Featured Videos',
                        })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    >
                      <option value="Featured Photos">Featured Photos</option>
                      <option value="Featured Videos">Featured Videos</option>
                      <option value="Achievements">Achievements</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold mb-1">Type</label>
                    <select
                      value={editingGallery.type || 'image'}
                      onChange={(e) =>
                        setEditingGallery({
                          ...editingGallery,
                          type: e.target.value as 'image' | 'video',
                        })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    >
                      <option value="image">Image</option>
                      <option value="video">Video</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-bold mb-1">Media URL / Embed Source</label>
                  <input
                    type="text"
                    value={editingGallery.url || ''}
                    onChange={(e) => setEditingGallery({ ...editingGallery, url: e.target.value })}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">Thumbnail URL (Optional for videos)</label>
                  <input
                    type="text"
                    value={editingGallery.thumbnail || ''}
                    onChange={(e) => setEditingGallery({ ...editingGallery, thumbnail: e.target.value })}
                    placeholder="https://..."
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">Description</label>
                  <textarea
                    rows={2}
                    value={editingGallery.description || ''}
                    onChange={(e) => setEditingGallery({ ...editingGallery, description: e.target.value })}
                    placeholder="Brief highlight details..."
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  ></textarea>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  onClick={() => setEditingGallery(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (editingGallery.id) {
                      updateGalleryItem(editingGallery.id, editingGallery);
                    } else {
                      addGalleryItem(editingGallery as Omit<GalleryItem, 'id'>);
                    }
                    setEditingGallery(null);
                  }}
                  className="px-5 py-2 rounded-xl bg-[#0D3B8C] text-white text-xs font-bold shadow"
                >
                  Save Media
                </button>
              </div>
            </div>
          </div>
        )}

        {/* RESOURCE ITEM FORM MODAL */}
        {editingResource && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <div className="bg-white p-6 rounded-3xl w-full max-w-lg space-y-4 shadow-2xl">
              <h4 className="text-lg font-bold text-slate-900">
                {editingResource.id ? 'Edit Resource' : 'Upload New Resource'}
              </h4>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold mb-1">Resource Title</label>
                  <input
                    type="text"
                    value={editingResource.title || ''}
                    onChange={(e) => setEditingResource({ ...editingResource, title: e.target.value })}
                    placeholder="e.g. Brand Your E-Cell"
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block font-bold mb-1">Category</label>
                    <input
                      type="text"
                      value={editingResource.category || ''}
                      onChange={(e) => setEditingResource({ ...editingResource, category: e.target.value })}
                      placeholder="Preliminary Task"
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>

                  <div>
                    <label className="block font-bold mb-1">File Type</label>
                    <select
                      value={editingResource.fileType || 'pdf'}
                      onChange={(e) => setEditingResource({ ...editingResource, fileType: e.target.value as any })}
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    >
                      <option value="pdf">PDF</option>
                      <option value="pptx">PPTX</option>
                      <option value="docx">DOCX</option>
                      <option value="zip">ZIP</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold mb-1">File Size</label>
                    <input
                      type="text"
                      value={editingResource.fileSize || ''}
                      onChange={(e) => setEditingResource({ ...editingResource, fileSize: e.target.value })}
                      placeholder="2.4 MB"
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold mb-1">Download URL / Drive Link</label>
                  <input
                    type="text"
                    value={editingResource.downloadUrl || ''}
                    onChange={(e) => setEditingResource({ ...editingResource, downloadUrl: e.target.value })}
                    placeholder="https://drive.google.com/..."
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">Preview Summary (Short Card Teaser)</label>
                  <textarea
                    rows={2}
                    value={editingResource.previewSummary || ''}
                    onChange={(e) => setEditingResource({ ...editingResource, previewSummary: e.target.value })}
                    placeholder="Brief summary shown on resource card..."
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  ></textarea>
                </div>

                <div>
                  <label className="block font-bold mb-1">Full Description</label>
                  <textarea
                    rows={3}
                    value={editingResource.description || ''}
                    onChange={(e) => setEditingResource({ ...editingResource, description: e.target.value })}
                    placeholder="Detailed overview of task or report..."
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  ></textarea>
                </div>

                <div>
                  <label className="block font-bold mb-1">Tags (Comma-separated)</label>
                  <input
                    type="text"
                    value={Array.isArray(editingResource.tags) ? editingResource.tags.join(', ') : ''}
                    onChange={(e) =>
                      setEditingResource({
                        ...editingResource,
                        tags: e.target.value.split(',').map((t) => t.trim()).filter(Boolean),
                      })
                    }
                    placeholder="Branding, Strategy, NEC 2026"
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  onClick={() => setEditingResource(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (editingResource.id) {
                      updateResource(editingResource.id, editingResource);
                    } else {
                      addResource(editingResource as Omit<ResourceItem, 'id' | 'downloadsCount'>);
                    }
                    setEditingResource(null);
                  }}
                  className="px-5 py-2 rounded-xl bg-[#0D3B8C] text-white text-xs font-bold shadow"
                >
                  Save Resource
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TIMELINE MILESTONE FORM MODAL */}
        {editingMilestone && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <div className="bg-white p-6 rounded-3xl w-full max-w-lg space-y-4 shadow-2xl">
              <h4 className="text-lg font-bold text-slate-900">
                {editingMilestone.id ? 'Edit Milestone' : 'Add Milestone'}
              </h4>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold mb-1">Milestone Title</label>
                  <input
                    type="text"
                    value={editingMilestone.title || ''}
                    onChange={(e) => setEditingMilestone({ ...editingMilestone, title: e.target.value })}
                    placeholder="e.g. Preliminary Task Submission"
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block font-bold mb-1">Phase</label>
                    <input
                      type="text"
                      value={editingMilestone.phase || ''}
                      onChange={(e) => setEditingMilestone({ ...editingMilestone, phase: e.target.value })}
                      placeholder="Phase 01"
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>

                  <div>
                    <label className="block font-bold mb-1">Date / Timeline</label>
                    <input
                      type="text"
                      value={editingMilestone.date || ''}
                      onChange={(e) => setEditingMilestone({ ...editingMilestone, date: e.target.value })}
                      placeholder="28 June – 2 Aug 2026"
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>

                  <div>
                    <label className="block font-bold mb-1">Status</label>
                    <select
                      value={editingMilestone.status || 'Upcoming'}
                      onChange={(e) =>
                        setEditingMilestone({
                          ...editingMilestone,
                          status: e.target.value as 'Completed' | 'Under Evaluation' | 'Upcoming',
                        })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    >
                      <option value="Completed">Completed</option>
                      <option value="Under Evaluation">Under Evaluation</option>
                      <option value="Upcoming">Upcoming</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-bold mb-1">Description</label>
                  <textarea
                    rows={3}
                    value={editingMilestone.description || ''}
                    onChange={(e) => setEditingMilestone({ ...editingMilestone, description: e.target.value })}
                    placeholder="Phase goals & overview..."
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  ></textarea>
                </div>

                <div>
                  <label className="block font-bold mb-1">Deliverables (One per line)</label>
                  <textarea
                    rows={3}
                    value={Array.isArray(editingMilestone.deliverables) ? editingMilestone.deliverables.join('\n') : ''}
                    onChange={(e) =>
                      setEditingMilestone({
                        ...editingMilestone,
                        deliverables: e.target.value.split('\n').filter((line) => line.trim().length > 0),
                      })
                    }
                    placeholder="Deliverable 1&#10;Deliverable 2"
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  ></textarea>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  onClick={() => setEditingMilestone(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (editingMilestone.id) {
                      updateMilestone(editingMilestone.id, editingMilestone);
                    } else {
                      addMilestone(editingMilestone as Omit<MilestoneItem, 'id'>);
                    }
                    setEditingMilestone(null);
                  }}
                  className="px-5 py-2 rounded-xl bg-[#0D3B8C] text-white text-xs font-bold shadow"
                >
                  Save Milestone
                </button>
              </div>
            </div>
          </div>
        )}

        {/* FAQ ITEM FORM MODAL */}
        {editingFaq && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <div className="bg-white p-6 rounded-3xl w-full max-w-lg space-y-4 shadow-2xl">
              <h4 className="text-lg font-bold text-slate-900">
                {editingFaq.id ? 'Edit FAQ' : 'Add FAQ'}
              </h4>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold mb-1">Question</label>
                  <input
                    type="text"
                    value={editingFaq.question || ''}
                    onChange={(e) => setEditingFaq({ ...editingFaq, question: e.target.value })}
                    placeholder="Frequently asked question..."
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">Category</label>
                  <input
                    type="text"
                    value={editingFaq.category || ''}
                    onChange={(e) => setEditingFaq({ ...editingFaq, category: e.target.value })}
                    placeholder="General / Challenge / Submissions"
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">Answer</label>
                  <textarea
                    rows={4}
                    value={editingFaq.answer || ''}
                    onChange={(e) => setEditingFaq({ ...editingFaq, answer: e.target.value })}
                    placeholder="Detailed clear response..."
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  ></textarea>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  onClick={() => setEditingFaq(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (editingFaq.id) {
                      updateFAQ(editingFaq.id, editingFaq);
                    } else {
                      addFAQ(editingFaq as Omit<FAQItem, 'id'>);
                    }
                    setEditingFaq(null);
                  }}
                  className="px-5 py-2 rounded-xl bg-[#0D3B8C] text-white text-xs font-bold shadow"
                >
                  Save FAQ
                </button>
              </div>
            </div>
          </div>
        )}

        {/* EVENT EDIT / ADD FORM MODAL */}
        {editingEvent && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
            <div className="bg-white p-6 rounded-3xl w-full max-w-xl space-y-4 shadow-2xl my-8 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h4 className="text-lg font-bold text-slate-900">
                  {editingEvent.id ? 'Edit Event Settings' : 'Add New Event'}
                </h4>
                <button
                  onClick={() => setEditingEvent(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold mb-1">Event Title *</label>
                  <input
                    type="text"
                    required
                    value={editingEvent.title || ''}
                    onChange={(e) => setEditingEvent({ ...editingEvent, title: e.target.value })}
                    placeholder="e.g. Eureka! 2026 or IPL Auction"
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-bold mb-1">Tagline / Subtitle</label>
                  <input
                    type="text"
                    value={editingEvent.tagline || ''}
                    onChange={(e) => setEditingEvent({ ...editingEvent, tagline: e.target.value })}
                    placeholder="e.g. Asia's Largest Business Model Competition"
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold mb-1">Category</label>
                    <select
                      value={editingEvent.category || 'Competition'}
                      onChange={(e) =>
                        setEditingEvent({
                          ...editingEvent,
                          category: e.target.value as EventItem['category'],
                        })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    >
                      <option value="Flagship">Flagship</option>
                      <option value="Competition">Competition</option>
                      <option value="Workshop">Workshop</option>
                      <option value="Pitching">Pitching</option>
                      <option value="Speaker Series">Speaker Series</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold mb-1">Registration Status</label>
                    <select
                      value={editingEvent.status || 'Registration Open'}
                      onChange={(e) =>
                        setEditingEvent({
                          ...editingEvent,
                          status: e.target.value as EventItem['status'],
                        })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    >
                      <option value="Registration Open">Registration Open</option>
                      <option value="Upcoming">Upcoming</option>
                      <option value="Completed">Completed</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold mb-1">Event Date / Timeline</label>
                    <input
                      type="text"
                      value={editingEvent.date || ''}
                      onChange={(e) => setEditingEvent({ ...editingEvent, date: e.target.value })}
                      placeholder="e.g. Feb 25, 2026"
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>
                  <div>
                    <label className="block font-bold mb-1">Time (Optional)</label>
                    <input
                      type="text"
                      value={editingEvent.time || ''}
                      onChange={(e) => setEditingEvent({ ...editingEvent, time: e.target.value })}
                      placeholder="e.g. 10:00 AM IST onwards"
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold mb-1">Venue / Mode</label>
                    <input
                      type="text"
                      value={editingEvent.venue || ''}
                      onChange={(e) => setEditingEvent({ ...editingEvent, venue: e.target.value })}
                      placeholder="e.g. Auditorium 2, GHRCE"
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>
                  <div>
                    <label className="block font-bold mb-1">Prize Pool / Perks</label>
                    <input
                      type="text"
                      value={editingEvent.prizePool || ''}
                      onChange={(e) => setEditingEvent({ ...editingEvent, prizePool: e.target.value })}
                      placeholder="e.g. ₹15,000 Cash Prizes"
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold mb-1">Event Photo / Banner Image URL</label>
                  <input
                    type="text"
                    value={editingEvent.imageUrl || ''}
                    onChange={(e) => setEditingEvent({ ...editingEvent, imageUrl: e.target.value })}
                    placeholder="https://images.unsplash.com/... or /images/..."
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                  {editingEvent.imageUrl && (
                    <img
                      src={editingEvent.imageUrl}
                      alt="Preview"
                      className="mt-2 h-24 w-full object-cover rounded-xl border border-slate-200"
                    />
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold mb-1">Luma Registration URL</label>
                    <input
                      type="text"
                      value={editingEvent.lumaUrl || ''}
                      onChange={(e) => setEditingEvent({ ...editingEvent, lumaUrl: e.target.value })}
                      placeholder="https://luma.com/event/evt-..."
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>
                  <div>
                    <label className="block font-bold mb-1">Luma Event ID</label>
                    <input
                      type="text"
                      value={editingEvent.lumaEventId || ''}
                      onChange={(e) => setEditingEvent({ ...editingEvent, lumaEventId: e.target.value })}
                      placeholder="evt-3hgeOcdbkW0vOQn"
                      className="w-full p-2.5 rounded-xl border border-slate-300"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold mb-1">Event Description</label>
                  <textarea
                    rows={3}
                    value={editingEvent.description || ''}
                    onChange={(e) => setEditingEvent({ ...editingEvent, description: e.target.value })}
                    placeholder="Full details about what the event is, goals, experience..."
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  ></textarea>
                </div>

                <div>
                  <label className="block font-bold mb-1">Key Highlights / Features (One per line)</label>
                  <textarea
                    rows={3}
                    value={Array.isArray(editingEvent.highlights) ? editingEvent.highlights.join('\n') : ''}
                    onChange={(e) =>
                      setEditingEvent({
                        ...editingEvent,
                        highlights: e.target.value.split('\n').filter((l) => l.trim().length > 0),
                      })
                    }
                    placeholder="1-on-1 Mentorship&#10;Cash Rewards & Grants&#10;Certificates for all"
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  ></textarea>
                </div>

                <div>
                  <label className="block font-bold mb-1">Eligibility Criteria</label>
                  <input
                    type="text"
                    value={editingEvent.eligibility || ''}
                    onChange={(e) => setEditingEvent({ ...editingEvent, eligibility: e.target.value })}
                    placeholder="e.g. Open to all students & early-stage startups"
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="isFeatured"
                    checked={editingEvent.isFeatured || false}
                    onChange={(e) => setEditingEvent({ ...editingEvent, isFeatured: e.target.checked })}
                    className="w-4 h-4 text-[#0D3B8C] rounded border-slate-300 focus:ring-[#0D3B8C]"
                  />
                  <label htmlFor="isFeatured" className="font-bold text-slate-800 cursor-pointer">
                    Set as Top Featured Flagship Event
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  onClick={() => setEditingEvent(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!editingEvent.title) return;
                    if (editingEvent.id) {
                      updateEvent(editingEvent.id, editingEvent);
                    } else {
                      addEvent({
                        title: editingEvent.title || 'New Event',
                        tagline: editingEvent.tagline || '',
                        category: editingEvent.category || 'Competition',
                        status: editingEvent.status || 'Registration Open',
                        date: editingEvent.date || 'March 2026',
                        time: editingEvent.time,
                        venue: editingEvent.venue || 'GHRCE Campus',
                        prizePool: editingEvent.prizePool,
                        description: editingEvent.description || '',
                        highlights: editingEvent.highlights || ['Mentorship & Perks'],
                        eligibility: editingEvent.eligibility || 'Open to all students',
                        lumaEventId: editingEvent.lumaEventId || 'evt-3hgeOcdbkW0vOQn',
                        lumaUrl: editingEvent.lumaUrl || 'https://luma.com/event/evt-3hgeOcdbkW0vOQn',
                        imageUrl: editingEvent.imageUrl,
                        isFeatured: editingEvent.isFeatured,
                      });
                    }
                    setEditingEvent(null);
                  }}
                  className="px-5 py-2 rounded-xl bg-[#0D3B8C] hover:bg-blue-900 text-white text-xs font-bold shadow transition-colors"
                >
                  Save Event Settings
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
