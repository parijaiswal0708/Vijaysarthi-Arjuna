import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Calendar,
  MapPin,
  Trophy,
  Users,
  Sparkles,
  ExternalLink,
  Clock,
  CheckCircle2,
  Filter,
  Search,
  ArrowRight,
  Bookmark,
  Share2,
  Info,
  Flame,
  Award,
  Zap,
} from 'lucide-react';
import { ECellGhrceLogo, IitbNecLogo, VijaysarthiArjunaLogo } from '../components/Logos';
import { useApp } from '../context/AppContext';
import { EventItem } from '../types';

export const Events: React.FC = () => {
  const { events, setCurrentRoute } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedEventModal, setSelectedEventModal] = useState<EventItem | null>(null);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  // Dynamically load Luma Checkout script on component mount
  useEffect(() => {
    const scriptId = 'luma-checkout';
    let scriptEl = document.getElementById(scriptId) as HTMLScriptElement | null;

    if (!scriptEl) {
      scriptEl = document.createElement('script');
      scriptEl.id = scriptId;
      scriptEl.src = 'https://embed.lu.ma/checkout-button.js';
      scriptEl.async = true;
      document.body.appendChild(scriptEl);
    }
  }, []);

  const categories = ['All', 'Flagship', 'Competition', 'Pitching', 'Workshop', 'Speaker Series'];

  const filteredEvents = events.filter((evt) => {
    const matchesCategory = selectedCategory === 'All' || evt.category === selectedCategory;
    const matchesSearch =
      evt.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evt.tagline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evt.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const featuredEvent = events.find((e) => e.isFeatured) || events.find((e) => e.category === 'Flagship') || events[0];

  const handleShare = (eventTitle: string) => {
    if (navigator.share) {
      navigator.share({
        title: `${eventTitle} - Vijaysarthi Arjuna E-Cell`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <div className="pt-24 pb-20 min-h-screen relative">
      {/* Background Decorative Mesh Glow */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-br from-blue-500/10 via-amber-500/10 to-orange-500/10 blur-3xl pointer-events-none -z-10 rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <motion.div
            initial={{ opacity: 0, y: -15 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-50 border border-orange-200 text-orange-700 text-xs font-bold tracking-wide uppercase mb-4 shadow-2xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#F97316]" />
            <span>E-Cell GHRCE Events & Competitions</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight"
          >
            Where Innovation Meets <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#0D3B8C] via-blue-700 to-[#F97316]">Execution</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed"
          >
            Participate in flagship competitions, pitch challenges, mentorship bootcamps, and high-impact workshops organized by <strong>Vijaysarthi Arjuna</strong>.
          </motion.p>
        </div>

        {/* FEATURED EVENT SECTION */}
        {featuredEvent && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-16 relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-[#0B1E40] to-slate-900 text-white shadow-2xl border-2 border-orange-500/40 p-6 sm:p-10 lg:p-12"
          >
            {/* Background Image overlay if available */}
            {featuredEvent.imageUrl && (
              <div className="absolute inset-0 z-0 opacity-20 bg-cover bg-center pointer-events-none" style={{ backgroundImage: `url(${featuredEvent.imageUrl})` }} />
            )}

            {/* Subtle Ambient Graphic Layer */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              {/* Left Column: Details & CTAs */}
              <div className="lg:col-span-7 space-y-6">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="px-3.5 py-1 rounded-full bg-gradient-to-r from-orange-500 to-amber-500 text-white font-extrabold text-xs uppercase tracking-wider shadow-md flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 fill-white" />
                    <span>Featured Event</span>
                  </span>
                  <span className="px-3.5 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 font-bold text-xs flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{featuredEvent.status}</span>
                  </span>
                  <span className="text-xs text-slate-300 bg-white/10 px-3 py-1 rounded-full backdrop-blur-md">
                    {featuredEvent.category}
                  </span>
                </div>

                <div>
                  <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-none mb-2">
                    {featuredEvent.title}
                  </h2>
                  <p className="text-lg sm:text-xl font-semibold text-amber-300/90">
                    {featuredEvent.tagline}
                  </p>
                </div>

                <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                  {featuredEvent.description}
                </p>

                {/* Quick Info Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="flex items-center gap-3 bg-white/5 border border-white/10 p-3 rounded-2xl backdrop-blur-md">
                    <div className="p-2.5 rounded-xl bg-orange-500/20 text-orange-400">
                      <Calendar className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 font-medium">Timeline</p>
                      <p className="text-xs sm:text-sm font-bold text-white">{featuredEvent.date}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 bg-white/5 border border-white/10 p-3 rounded-2xl backdrop-blur-md">
                    <div className="p-2.5 rounded-xl bg-blue-500/20 text-blue-400">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 font-medium">Venue / Mode</p>
                      <p className="text-xs sm:text-sm font-bold text-white">{featuredEvent.venue}</p>
                    </div>
                  </div>

                  {featuredEvent.prizePool && (
                    <div className="flex items-center gap-3 bg-white/5 border border-white/10 p-3 rounded-2xl backdrop-blur-md sm:col-span-2">
                      <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400">
                        <Trophy className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-xs text-slate-400 font-medium">Prizes & Incubation Perks</p>
                        <p className="text-xs sm:text-sm font-bold text-amber-300">{featuredEvent.prizePool}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Luma Event Registration Button */}
                <div className="pt-4 flex flex-wrap items-center gap-4">
                  <div className="relative group">
                    <a
                      href={featuredEvent.lumaUrl || 'https://luma.com/event/evt-3hgeOcdbkW0vOQn'}
                      className="luma-checkout--button inline-flex items-center gap-3 px-8 py-4 rounded-2xl font-black text-base text-white bg-gradient-to-r from-[#F97316] via-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 shadow-xl shadow-orange-500/25 transition-all transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
                      data-luma-action="checkout"
                      data-luma-event-id={featuredEvent.lumaEventId || 'evt-3hgeOcdbkW0vOQn'}
                      onClick={(e) => {
                        if (typeof window !== 'undefined' && !(window as any).LumaCheckout) {
                          window.open(featuredEvent.lumaUrl || 'https://luma.com/event/evt-3hgeOcdbkW0vOQn', '_blank');
                        }
                      }}
                    >
                      <Zap className="w-5 h-5 fill-white" />
                      <span>Register for Event</span>
                      <ArrowRight className="w-5 h-5 ml-1 transition-transform group-hover:translate-x-1" />
                    </a>
                  </div>

                  <button
                    onClick={() => setSelectedEventModal(featuredEvent)}
                    className="px-6 py-4 rounded-2xl font-bold text-sm text-slate-200 bg-white/10 hover:bg-white/20 border border-white/20 transition-all flex items-center gap-2 cursor-pointer"
                  >
                    <Info className="w-4 h-4 text-blue-300" />
                    <span>View Full Event Specs</span>
                  </button>
                </div>
              </div>

              {/* Right Column: Highlights Card / Graphic */}
              <div className="lg:col-span-5 bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 sm:p-8 backdrop-blur-xl space-y-5">
                <div className="flex items-center justify-between border-b border-slate-700/80 pb-4">
                  <div className="flex items-center gap-3">
                    <Award className="w-6 h-6 text-orange-400" />
                    <h3 className="font-extrabold text-white text-lg">Why Participate?</h3>
                  </div>
                  <span className="text-xs text-orange-300 bg-orange-500/10 px-2.5 py-1 rounded-full border border-orange-500/30">
                    Key Benefits
                  </span>
                </div>

                <ul className="space-y-3.5">
                  {featuredEvent.highlights.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-sm text-slate-200">
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                      <span className="font-medium">{item}</span>
                    </li>
                  ))}
                </ul>

                <div className="pt-4 border-t border-slate-700/80 flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-2">
                    <VijaysarthiArjunaLogo size={24} />
                    <span>Hosted by Vijaysarthi Arjuna</span>
                  </div>
                  <button
                    onClick={() => handleShare(featuredEvent.title)}
                    className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-colors flex items-center gap-1.5"
                    title="Share event link"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>{copiedLink ? 'Copied!' : 'Share'}</span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* ALL EVENTS SECTION */}
        <div className="space-y-8">
          {/* Controls: Search & Category Filter */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white/80 backdrop-blur-md p-4 rounded-2xl border border-slate-200 shadow-sm">
            {/* Categories */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
              <Filter className="w-4 h-4 text-slate-400 shrink-0 ml-2 mr-1" />
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-[#0D3B8C] text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Search Box */}
            <div className="relative w-full md:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search events, workshops..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0D3B8C] focus:bg-white transition-all"
              />
            </div>
          </div>

          {/* Events Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map((event, index) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.08 }}
                className="bg-white border border-slate-200/90 rounded-2xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1 relative overflow-hidden"
              >
                {/* Top Image or Badge Row */}
                <div>
                  {event.imageUrl && (
                    <div className="mb-4 -mx-6 -mt-6 h-40 overflow-hidden bg-slate-100 relative">
                      <img
                        src={event.imageUrl}
                        alt={event.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  )}

                  <div className="flex items-center justify-between mb-3">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wider ${
                        event.category === 'Flagship'
                          ? 'bg-orange-100 text-orange-700 border border-orange-200'
                          : event.category === 'Competition'
                          ? 'bg-blue-100 text-[#0D3B8C] border border-blue-200'
                          : event.category === 'Pitching'
                          ? 'bg-purple-100 text-purple-700 border border-purple-200'
                          : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                      }`}
                    >
                      {event.category}
                    </span>

                    <span
                      className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                        event.status === 'Registration Open'
                          ? 'bg-emerald-50 text-emerald-600 border border-emerald-200'
                          : 'bg-slate-100 text-slate-600 border border-slate-200'
                      }`}
                    >
                      {event.status}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-slate-900 group-hover:text-[#0D3B8C] transition-colors line-clamp-1">
                    {event.title}
                  </h3>

                  <p className="text-xs font-semibold text-orange-600 mt-1 mb-3">
                    {event.tagline}
                  </p>

                  <p className="text-slate-600 text-xs sm:text-sm line-clamp-3 leading-relaxed mb-4">
                    {event.description}
                  </p>
                </div>

                {/* Details Footer */}
                <div className="pt-4 border-t border-slate-100 space-y-3">
                  <div className="space-y-1.5 text-xs text-slate-500 font-medium">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{event.venue}</span>
                    </div>
                    {event.prizePool && (
                      <div className="flex items-center gap-2 font-bold text-amber-600">
                        <Trophy className="w-3.5 h-3.5 text-amber-500" />
                        <span>{event.prizePool}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 pt-2">
                    <a
                      href={event.lumaUrl || 'https://luma.com/event/evt-3hgeOcdbkW0vOQn'}
                      className="luma-checkout--button flex-1 py-2.5 px-4 rounded-xl font-bold text-xs text-white bg-[#0D3B8C] hover:bg-blue-900 transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
                      data-luma-action="checkout"
                      data-luma-event-id={event.lumaEventId || 'evt-3hgeOcdbkW0vOQn'}
                      onClick={(e) => {
                        if (typeof window !== 'undefined' && !(window as any).LumaCheckout) {
                          window.open(event.lumaUrl || 'https://luma.com/event/evt-3hgeOcdbkW0vOQn', '_blank');
                        }
                      }}
                    >
                      <span>Register</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>

                    <button
                      onClick={() => setSelectedEventModal(event)}
                      className="p-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
                      title="Event Details"
                    >
                      <Info className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* ORGANIZING PARTNERS FOOTER CALLOUT */}
        <div className="mt-16 bg-slate-50 border border-slate-200 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white rounded-2xl shadow-sm border border-slate-100">
              <IitbNecLogo size={44} />
            </div>
            <div>
              <h4 className="font-extrabold text-slate-900 text-base sm:text-lg">
                Have an Idea or Want to Partner for an Event?
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
                E-Cell GHRCE collaborates with campus startups, corporate sponsors, and student innovators.
              </p>
            </div>
          </div>

          <button
            onClick={() => setCurrentRoute('home', 'terminal-contact-section')}
            className="px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-bold transition-all shadow-md whitespace-nowrap cursor-pointer hover:scale-105 active:scale-95"
          >
            Contact E-Cell Team
          </button>
        </div>
      </div>

      {/* EVENT MODAL POPUP */}
      <AnimatePresence>
        {selectedEventModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white border border-slate-200 rounded-3xl shadow-2xl max-w-2xl w-full p-6 sm:p-8 max-h-[90vh] overflow-y-auto relative"
            >
              <button
                onClick={() => setSelectedEventModal(null)}
                className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:bg-slate-100 hover:text-slate-800 transition-colors"
              >
                ✕
              </button>

              <div className="space-y-5">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-orange-100 text-orange-700 uppercase">
                  {selectedEventModal.category}
                </span>

                <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                  {selectedEventModal.title}
                </h2>

                <p className="text-sm font-bold text-orange-600">
                  {selectedEventModal.tagline}
                </p>

                <p className="text-slate-600 text-sm leading-relaxed">
                  {selectedEventModal.description}
                </p>

                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <h4 className="font-bold text-slate-900 text-sm">Key Highlights & Perks:</h4>
                  <ul className="space-y-1.5 text-xs sm:text-sm text-slate-600">
                    {selectedEventModal.highlights.map((h, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 text-xs text-slate-600 space-y-1">
                  <p>
                    <strong>Eligibility:</strong> {selectedEventModal.eligibility}
                  </p>
                  {selectedEventModal.time && (
                    <p>
                      <strong>Timing:</strong> {selectedEventModal.time}
                    </p>
                  )}
                </div>

                <div className="pt-4 flex items-center gap-3">
                  <a
                    href={selectedEventModal.lumaUrl || 'https://luma.com/event/evt-3hgeOcdbkW0vOQn'}
                    className="luma-checkout--button flex-1 py-3.5 px-6 rounded-xl font-extrabold text-sm text-white bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 transition-all flex items-center justify-center gap-2 shadow-lg shadow-orange-500/20"
                    data-luma-action="checkout"
                    data-luma-event-id={selectedEventModal.lumaEventId || 'evt-3hgeOcdbkW0vOQn'}
                  >
                    <span>Register for Event via Luma</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>

                  <button
                    onClick={() => setSelectedEventModal(null)}
                    className="py-3.5 px-5 rounded-xl font-bold text-sm text-slate-600 hover:bg-slate-100 border border-slate-200 transition-colors"
                  >
                    Close
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Events;
