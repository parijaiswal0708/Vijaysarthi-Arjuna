import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext';
import {
  Search,
  Eye,
  X,
  Tag,
  FolderOpen,
  Folder,
  Sparkles,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  ArrowDown
} from 'lucide-react';
import { ResourceItem } from '../types';

export const Resources: React.FC = () => {
  const { resources, setCurrentRoute } = useApp();

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [previewResource, setPreviewResource] = useState<ResourceItem | null>(null);
  
  // Expanded state for "See More" inline details on cards
  const [expandedCardIds, setExpandedCardIds] = useState<Record<string, boolean>>({});
  
  // "See More Resources" expansion for grid pagination
  const [displayCount, setDisplayCount] = useState<number>(12);

  const categories = [
    'All',
    'Announcements',
    'Preliminary Task',
    'Ignite Propel',
    'Venture Quest',
    'Grand Finale',
  ];

  const toggleCardExpansion = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setExpandedCardIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const filteredResources = resources.filter((r) => {
    const searchLower = search.trim().toLowerCase();
    const matchesSearch =
      !searchLower ||
      r.title.toLowerCase().includes(searchLower) ||
      r.description.toLowerCase().includes(searchLower) ||
      (r.previewSummary && r.previewSummary.toLowerCase().includes(searchLower)) ||
      r.tags.some((t) => t.toLowerCase().includes(searchLower));

    const selectedNorm = selectedCategory.trim().toLowerCase();
    const resourceCatNorm = (r.category || '').trim().toLowerCase();

    const matchesCat =
      selectedNorm === 'all' ||
      resourceCatNorm === selectedNorm ||
      resourceCatNorm.replace(/-/g, ' ') === selectedNorm.replace(/-/g, ' ') ||
      (selectedNorm.includes('preliminary') && resourceCatNorm.includes('preliminary')) ||
      r.tags.some((t) => t.trim().toLowerCase() === selectedNorm);

    return matchesSearch && matchesCat;
  });

  const visibleResources = filteredResources.slice(0, displayCount);

  return (
    <div className="min-h-screen bg-transparent pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title Header */}
        <div className="text-center max-w-4xl mx-auto mb-12">
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-100/90 border border-orange-200/90 text-xs font-bold text-[#EA580C] uppercase tracking-wider mb-4 shadow-sm"
          >
            <FolderOpen className="w-4 h-4 text-[#F97316] animate-pulse" />
            <span>Official Knowledge Hub</span>
          </motion.div>
          
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-2xl sm:text-4xl md:text-5xl font-black text-slate-900 tracking-tight whitespace-nowrap"
          >
            Resources and Documentation
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-sm sm:text-base text-slate-600 mt-4 leading-relaxed max-w-3xl mx-auto"
          >
            Every phase of the National Entrepreneurship Challenge contributes to our growth as innovators and entrepreneurs. This repository brings together the official reports, presentations, documentation, and supporting resources created by Team VijaySarthi Arjuna throughout NEC 2026. From preliminary submissions to the Grand Finale, every document reflects our commitment to learning, execution, and excellence.
          </motion.p>
        </div>

        {/* Search & Category Filter Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="geo-card rounded-3xl p-4 sm:p-6 bg-white/90 backdrop-blur-xl border border-slate-200/90 shadow-xl mb-10 space-y-4"
        >
          <div className="flex flex-col lg:flex-row items-center gap-4">
            {/* Search Input with Clear Button */}
            <div className="relative w-full lg:flex-1">
              <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search reports, PPTs, templates, tags..."
                className="w-full pl-12 pr-10 py-3 rounded-2xl bg-slate-50/90 border border-slate-200 text-slate-900 text-sm focus:outline-none focus:border-[#0D3B8C] focus:bg-white focus:ring-2 focus:ring-blue-500/20 transition-all"
              />
              {search && (
                <button
                  onClick={() => setSearch('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap items-center gap-2 overflow-x-auto w-full lg:w-auto pb-1 lg:pb-0 scrollbar-none">
              {categories.map((cat) => {
                const isSelected = selectedCategory === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => {
                      setSelectedCategory(cat);
                      setDisplayCount(12);
                    }}
                    className={`relative px-4 py-2.5 rounded-2xl text-xs font-bold transition-all shrink-0 z-10 ${
                      isSelected
                        ? 'text-white font-extrabold shadow-md'
                        : 'bg-slate-100/90 text-slate-700 hover:bg-slate-200/80 hover:text-slate-900'
                    }`}
                  >
                    {isSelected && (
                      <motion.div
                        layoutId="activeCategoryPill"
                        className="absolute inset-0 bg-[#0D3B8C] rounded-2xl -z-10 shadow-md shadow-blue-900/20"
                        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                      />
                    )}
                    <span>{cat}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Filter Bar / Contact Prompt */}
          <div className="flex items-center justify-between pt-3 border-t border-slate-100/80 text-xs">
            <div className="flex flex-col gap-1">
              <span className="text-xs font-semibold text-slate-700">
                Looking for something specific?
              </span>
              <button
                onClick={() => {
                  setCurrentRoute('home');
                  setTimeout(() => {
                    const el = document.getElementById('contact');
                    if (el) {
                      el.scrollIntoView({ behavior: 'smooth' });
                    }
                  }, 150);
                }}
                className="text-xs font-bold text-[#0D3B8C] hover:text-[#F97316] hover:underline flex items-center gap-1 w-fit transition-colors"
              >
                <span>Contact Us</span>
                <span className="text-sm font-normal">→</span>
              </button>
            </div>
            {(search || selectedCategory !== 'All') && (
              <button
                onClick={() => {
                  setSearch('');
                  setSelectedCategory('All');
                }}
                className="text-[#F97316] font-bold hover:underline self-end"
              >
                Reset Filters
              </button>
            )}
          </div>
        </motion.div>

        {/* Resource Folder Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {visibleResources.map((res, idx) => {
            const isExpanded = !!expandedCardIds[res.id];

            return (
              <motion.div
                key={res.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                whileHover={{ y: -6 }}
                className="geo-card rounded-3xl p-6 bg-white/90 backdrop-blur-xl border border-slate-200/90 hover:border-[#0D3B8C]/40 shadow-lg hover:shadow-2xl transition-all duration-300 flex flex-col justify-between space-y-4 group relative overflow-hidden"
              >
                {/* Folder Header Gradient Accent */}
                <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-[#0D3B8C] via-blue-500 to-[#F97316] opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                <div className="space-y-3.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {/* Interactive 3D Folder Opening Animation Icon Container */}
                      <div className="relative w-11 h-11 rounded-2xl bg-blue-50/90 border border-blue-200/80 flex items-center justify-center text-[#0D3B8C] group-hover:bg-[#0D3B8C] group-hover:text-white group-hover:border-[#0D3B8C] transition-all duration-400 shadow-xs">
                        <Folder className="w-5 h-5 group-hover:hidden transition-all" />
                        <FolderOpen className="w-5 h-5 hidden group-hover:block animate-bounce transition-all" />
                      </div>

                      <span className="px-3 py-1 rounded-full bg-blue-50/90 border border-blue-200 text-[#0D3B8C] text-[10px] font-extrabold uppercase tracking-wider">
                        {res.category}
                      </span>
                    </div>
                  </div>

                  <h3 className="text-xl font-black text-slate-900 group-hover:text-[#0D3B8C] transition-colors leading-snug">
                    {res.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
                    {res.description}
                  </p>

                  {/* Smooth "See More" Inline Expansion for Highlights */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden pt-2"
                      >
                        <div className="p-3.5 rounded-2xl bg-blue-50/80 border border-blue-200/80 space-y-2 text-xs text-slate-700">
                          <div className="font-extrabold text-[#0D3B8C] flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-[#F97316]" />
                            <span>Executive Summary & Takeaways:</span>
                          </div>
                          <p className="leading-relaxed">
                            {res.previewSummary || res.description}
                          </p>
                          <div className="text-[10px] text-slate-500 font-mono pt-1">
                            Uploaded on: {res.uploadDate}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Tags & See More Trigger */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div className="flex flex-wrap gap-1.5">
                      {res.tags.map((tag, tIdx) => (
                        <span
                          key={tIdx}
                          className="px-2.5 py-0.5 rounded-md bg-slate-100/90 border border-slate-200/60 text-slate-600 text-[10px] font-semibold flex items-center gap-1"
                        >
                          <Tag className="w-2.5 h-2.5 text-slate-400" />
                          {tag}
                        </span>
                      ))}
                    </div>

                    <button
                      onClick={(e) => toggleCardExpansion(res.id, e)}
                      className="text-xs font-bold text-[#0D3B8C] hover:text-[#F97316] flex items-center gap-1 transition-colors ml-auto"
                    >
                      <span>{isExpanded ? 'Show Less' : 'See More'}</span>
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                {/* Card Footer Actions */}
                <div className="pt-4 border-t border-slate-100/90 flex items-center justify-end gap-3">
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => setPreviewResource(res)}
                    className="w-full py-2.5 px-4 rounded-xl bg-slate-100/90 hover:bg-[#0D3B8C] text-slate-800 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-2 border border-slate-200/80 hover:border-[#0D3B8C] shadow-xs group/prev"
                  >
                    <Eye className="w-4 h-4 text-[#0D3B8C] group-hover/prev:text-white transition-colors" />
                    <span>Quick Preview</span>
                  </motion.button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Empty Search Result Fallback */}
        {filteredResources.length === 0 && (
          <div className="text-center py-16 bg-white/80 backdrop-blur-xl rounded-3xl border border-slate-200/80 shadow-md">
            <FolderOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-slate-800">No resources matched your filter</h3>
            <p className="text-xs text-slate-500 mt-1">Try adjusting your keyword or category selection.</p>
            <button
              onClick={() => {
                setSearch('');
                setSelectedCategory('All');
              }}
              className="mt-4 px-4 py-2 rounded-xl bg-[#0D3B8C] text-white text-xs font-bold shadow-sm"
            >
              Reset Search
            </button>
          </div>
        )}

        {/* Smooth "See More Resources" Expansion for Grid */}
        {filteredResources.length > displayCount && (
          <div className="text-center pt-12">
            <motion.button
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => setDisplayCount((prev) => prev + 4)}
              className="px-8 py-3.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-800 font-extrabold text-xs sm:text-sm border border-slate-300/80 shadow-md transition-all flex items-center gap-2 mx-auto"
            >
              <span>See More Resources ({filteredResources.length - displayCount} Remaining)</span>
              <ArrowDown className="w-4 h-4 text-[#F97316] animate-bounce" />
            </motion.button>
          </div>
        )}
      </div>

      {/* PREVIEW SUMMARY MODAL */}
      <AnimatePresence>
        {previewResource && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-md transition-opacity"
              onClick={() => setPreviewResource(null)}
            ></motion.div>

            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl z-10 border border-slate-200 p-6 space-y-4"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <FolderOpen className="w-5 h-5 text-[#0D3B8C]" />
                  <span className="text-xs font-extrabold text-[#0D3B8C] uppercase tracking-wider">
                    Resource Summary Preview
                  </span>
                </div>
                <button
                  onClick={() => setPreviewResource(null)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <h3 className="text-xl font-extrabold text-slate-900">
                {previewResource.title}
              </h3>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-700 leading-relaxed space-y-2">
                <div className="font-bold text-slate-900 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#F97316]" />
                  <span>Document Key Highlights:</span>
                </div>
                <p>{previewResource.previewSummary || previewResource.description}</p>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="text-xs text-slate-500 font-medium">
                  Uploaded: {previewResource.uploadDate}
                </div>

                <button
                  onClick={() => setPreviewResource(null)}
                  className="px-6 py-2.5 rounded-xl bg-[#0D3B8C] hover:bg-blue-900 text-white font-bold text-xs shadow-md transition-all"
                >
                  Close Preview
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};


