import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext';
import {
  Image as ImageIcon,
  Video,
  Play,
  X,
  Sparkles,
  CircuitBoard,
  Calendar,
  Eye
} from 'lucide-react';
import { GalleryItem } from '../types';

export const Gallery: React.FC = () => {
  const { galleryItems } = useApp();

  const [activeTab, setActiveTab] = useState<'All' | 'Achievements' | 'Featured Photos' | 'Featured Videos'>('All');
  const [lightboxItem, setLightboxItem] = useState<GalleryItem | null>(null);

  const filteredItems = galleryItems.filter((item) =>
    activeTab === 'All' ? true : item.category === activeTab
  );

  return (
    <div className="min-h-screen bg-transparent pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-4xl mx-auto mb-12 space-y-3">
          {/* Blue Cylinder Pill */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-100/90 border border-blue-300/80 text-[#0D3B8C] shadow-xs">
            <ImageIcon className="w-4 h-4 text-[#F97316]" />
            <span className="text-xs sm:text-sm font-extrabold tracking-wider uppercase">
              MEMORIES IN MOTION
            </span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight">
            Gallery & Journey Highlights
          </h1>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-3xl mx-auto pt-1">
            Explore the moments that shaped VijaySarthi Arjuna throughout the National Entrepreneurship Challenge 2026. From team meetings and branding sessions to official submissions, collaborations, and campus initiatives, this gallery captures our journey of learning, innovation, and growth—one milestone at a time.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-10">
          {(['All', 'Achievements', 'Featured Photos', 'Featured Videos'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-5 py-2.5 rounded-2xl text-xs font-extrabold transition-all shrink-0 ${
                activeTab === tab
                  ? 'bg-[#0D3B8C] text-white shadow-lg shadow-blue-900/20'
                  : 'bg-white/90 backdrop-blur-md text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Media Grid with Zoom & Tilt */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item) => (
            <motion.div
              key={item.id}
              whileHover={{ y: -6, scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300, damping: 20 }}
              onClick={() => setLightboxItem(item)}
              className="geo-card rounded-3xl overflow-hidden bg-white/90 backdrop-blur-xl border border-slate-200/90 cursor-pointer group shadow-lg hover:shadow-2xl hover:border-[#0D3B8C]/40 transition-all flex flex-col justify-between"
            >
              <div className="relative aspect-video overflow-hidden bg-slate-900">
                <img
                  src={item.thumbnail || item.url}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />

                <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-slate-900/80 backdrop-blur-md text-white text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                  {item.type === 'video' ? (
                    <Video className="w-3 h-3 text-[#F97316]" />
                  ) : (
                    <ImageIcon className="w-3 h-3 text-blue-400" />
                  )}
                  <span>{item.category}</span>
                </div>

                {item.type === 'video' ? (
                  <div className="absolute inset-0 flex items-center justify-center bg-slate-900/30 group-hover:bg-slate-900/10 transition-colors">
                    <div className="p-4 rounded-full bg-[#F97316] text-white shadow-xl shadow-orange-500/40 group-hover:scale-110 transition-transform">
                      <Play className="w-6 h-6 fill-white ml-0.5" />
                    </div>
                  </div>
                ) : (
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                    <div className="text-white text-xs font-bold flex items-center gap-1.5">
                      <Eye className="w-4 h-4 text-[#F97316]" />
                      <span>Click to enlarge in Lightbox</span>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-5 space-y-2">
                <div className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-slate-400" />
                  <span>{item.uploadDate}</span>
                </div>
                <h3 className="text-base font-extrabold text-slate-900 group-hover:text-[#0D3B8C] transition-colors line-clamp-1">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* LIGHTBOX / VIDEO PLAYER MODAL */}
      <AnimatePresence>
        {lightboxItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-950/85 backdrop-blur-md transition-opacity"
              onClick={() => setLightboxItem(null)}
            ></motion.div>

            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ type: 'spring', stiffness: 400, damping: 30 }}
              className="relative w-full max-w-4xl bg-slate-900 rounded-3xl shadow-2xl z-10 border border-slate-800 overflow-hidden text-white my-8"
            >
              <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
                  <span className="text-orange-400 font-mono uppercase">{lightboxItem.category}</span>
                  <span>•</span>
                  <span>{lightboxItem.uploadDate}</span>
                </div>
                <button
                  onClick={() => setLightboxItem(null)}
                  className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Media Canvas */}
              <div className="relative bg-black flex items-center justify-center min-h-[300px] max-h-[500px]">
                {lightboxItem.type === 'video' ? (
                  <iframe
                    src={lightboxItem.url}
                    title={lightboxItem.title}
                    className="w-full aspect-video max-h-[480px]"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                ) : (
                  <img
                    src={lightboxItem.url}
                    alt={lightboxItem.title}
                    className="max-h-[480px] w-auto object-contain"
                  />
                )}
              </div>

              {/* Content Details */}
              <div className="p-6 space-y-2 bg-slate-900">
                <h3 className="text-xl font-extrabold text-white">
                  {lightboxItem.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {lightboxItem.description}
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

