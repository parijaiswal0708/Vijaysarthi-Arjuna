import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext';
import { TerminalContact } from '../components/TerminalContact';
import { OurStorySection } from '../components/OurStorySection';
import { ExploreDomains3D } from '../components/ExploreDomains3D';
import { BuildYourPitch } from '../components/BuildYourPitch';
import { OrganizingPartnersSection } from '../components/OrganizingPartnersSection';
import {
  Sparkles,
  Target,
  Compass,
  ArrowRight,
  HelpCircle,
  Search,
  ChevronDown,
  Zap,
  CheckCircle2,
  Trophy,
  Quote,
} from 'lucide-react';

export const Home: React.FC = () => {
  const {
    setCurrentRoute,
    setShowWhatIsNecModal,
    faqs,
  } = useApp();

  // FAQ Search & Accordion
  const [faqSearch, setFaqSearch] = useState('');
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>(faqs[0]?.id || null);

  // Hover Preview for "What is NEC?"
  const [isHoveringNec, setIsHoveringNec] = useState(false);

  // Mouse Parallax Position
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const { clientX, clientY } = e;
    const { innerWidth, innerHeight } = window;
    setMousePos({
      x: (clientX / innerWidth - 0.5) * 25,
      y: (clientY / innerHeight - 0.5) * 25,
    });
  };

  const filteredFaqs = faqs.filter(
    (f) =>
      f.question.toLowerCase().includes(faqSearch.toLowerCase()) ||
      f.answer.toLowerCase().includes(faqSearch.toLowerCase())
  );

  // Animation Variants for Hero Staggered Reveal
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.12,
        delayChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: 'spring', stiffness: 300, damping: 24 },
    },
  };

  return (
    <div className="min-h-screen bg-transparent">
      {/* HERO SECTION WITH PARALLAX & STAGGERED REVEAL */}
      <section
        onMouseMove={handleMouseMove}
        className="relative pt-28 pb-20 md:pt-36 md:pb-28 overflow-hidden"
      >
        {/* Parallax Background Glowing Highlights & Floating Particles */}
        <div
          className="absolute top-10 right-[-5%] w-[500px] h-[500px] rounded-full bg-gradient-to-br from-blue-400/6 via-blue-600/3 to-transparent blur-3xl pointer-events-none transition-transform duration-700 ease-out"
          style={{ transform: `translate(${mousePos.x * 1.5}px, ${mousePos.y * 1.5}px)` }}
        ></div>
        <div
          className="absolute bottom-10 left-[-5%] w-[500px] h-[500px] rounded-full bg-gradient-to-tr from-orange-400/6 via-[#F97316]/3 to-transparent blur-3xl pointer-events-none transition-transform duration-700 ease-out"
          style={{ transform: `translate(${-mousePos.x * 1.2}px, ${-mousePos.y * 1.2}px)` }}
        ></div>

        {/* Floating Particles */}
        <div
          className="absolute top-24 left-[15%] w-3 h-3 rounded-full bg-[#0D3B8C]/40 blur-[1px] animate-pulse pointer-events-none"
          style={{ transform: `translate(${mousePos.x * 0.8}px, ${mousePos.y * 0.8}px)` }}
        ></div>
        <div
          className="absolute top-40 right-[20%] w-4 h-4 rounded-full bg-[#F97316]/40 blur-[1px] animate-bounce pointer-events-none"
          style={{ transform: `translate(${-mousePos.x * 0.9}px, ${-mousePos.y * 0.9}px)` }}
        ></div>
        <div
          className="absolute bottom-24 right-[12%] w-2.5 h-2.5 rounded-full bg-[#0D3B8C]/50 blur-[1px] pointer-events-none"
          style={{ transform: `translate(${mousePos.x * 1.1}px, ${mousePos.y * 1.1}px)` }}
        ></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="w-full mx-auto space-y-6"
          >
            {/* Main Hero Block */}
            <motion.div
              variants={itemVariants}
              style={{
                transform: `translate3d(${mousePos.x * 0.2}px, ${mousePos.y * 0.2}px, 0)`,
                boxShadow:
                  '0 30px 60px -15px rgba(13, 59, 140, 0.12), 0 0 30px rgba(249, 115, 22, 0.06)',
              }}
              className="geo-card rounded-3xl p-8 sm:p-12 border border-slate-200/90 shadow-2xl bg-white/95 backdrop-blur-xl relative transition-transform duration-300 ease-out"
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
                {/* Left Column: Hero Text Content & CTAs */}
                <div className="lg:col-span-7 text-center lg:text-left space-y-6">


                  {/* Bold H1 Headline and Highlighted VijaySarthi Arjuna */}
                  <motion.div variants={itemVariants} className="space-y-4">
                    <motion.h1
                      variants={itemVariants}
                      className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#0D3B8C] tracking-tight leading-tight text-center lg:text-left"
                    >
                      Some chase opportunities.{' '}
                      <span className="text-[#F97316] block sm:inline mt-1 sm:mt-0">
                        We create them.
                      </span>
                    </motion.h1>

                    <motion.p
                      variants={itemVariants}
                      className="text-xl sm:text-2xl text-slate-800 font-extrabold max-w-2xl mx-auto lg:mx-0 leading-relaxed text-center lg:text-left pt-1 flex flex-wrap items-center justify-center lg:justify-start gap-x-2.5 gap-y-1.5"
                    >
                      <span className="whitespace-nowrap text-slate-800 font-extrabold">Welcome to</span>
                      <span className="inline-block px-4 py-1 rounded-xl bg-gradient-to-r from-[#F97316] to-amber-500 text-white font-black text-xl sm:text-2xl lg:text-3xl shadow-lg shadow-orange-500/25 uppercase tracking-wider border border-orange-300/40 transform hover:scale-[1.02] transition-transform">
                        VijaySarthi Arjuna
                      </span>
                      <span className="text-slate-950 font-black tracking-tight text-lg sm:text-2xl lg:text-3xl drop-shadow-sm">where vision becomes victory.</span>
                    </motion.p>
                  </motion.div>

                  {/* CTA Buttons with Independent Animations & Hover Preview */}
                  <motion.div
                    variants={itemVariants}
                    className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center lg:justify-start gap-4 mt-8 pt-4 border-t border-slate-100 relative"
                  >
                    <motion.button
                      whileHover={{ scale: 1.05, y: -2 }}
                      whileTap={{ scale: 0.95 }}
                      id="hero-explore-journey-button"
                      onClick={() => setCurrentRoute('nec-journey')}
                      className="w-full sm:w-auto px-8 py-4 rounded-full bg-[#0D3B8C] hover:bg-blue-900 text-white font-extrabold text-sm shadow-xl shadow-blue-900/25 transition-all flex items-center justify-center gap-2 group"
                    >
                      <span>Explore Our NEC Journey</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                    </motion.button>

                    {/* What is NEC button with automatic hover card preview */}
                    <div
                      className="relative w-full sm:w-auto"
                      onMouseEnter={() => setIsHoveringNec(true)}
                      onMouseLeave={() => setIsHoveringNec(false)}
                    >
                      <motion.button
                        whileHover={{ scale: 1.05, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        id="hero-what-is-nec-button"
                        onClick={() => setShowWhatIsNecModal(true)}
                        className="w-full sm:w-auto px-8 py-4 rounded-full bg-slate-100/90 hover:bg-slate-200/90 text-slate-800 font-extrabold text-sm border border-slate-300/80 transition-all flex items-center justify-center gap-2"
                      >
                        <span>What is NEC?</span>
                      </motion.button>

                      {/* AUTOMATIC HOVER CARD PREVIEW */}
                      <AnimatePresence>
                        {isHoveringNec && (
                          <motion.div
                            initial={{ opacity: 0, y: 10, scale: 0.95 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: 10, scale: 0.95 }}
                            transition={{ duration: 0.2 }}
                            className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-80 p-4 rounded-2xl bg-slate-900 text-white shadow-2xl border border-slate-700 pointer-events-none z-50 text-left"
                          >
                            <div className="flex items-center gap-2 text-xs font-mono text-[#F97316] font-bold uppercase mb-1">
                              <Trophy className="w-3.5 h-3.5" />
                              <span>IIT Bombay Flagship Event</span>
                            </div>
                            <h4 className="text-sm font-extrabold text-white mb-1">
                              National Entrepreneurship Challenge
                            </h4>
                            <p className="text-[11px] text-slate-300 leading-relaxed">
                              The largest pan-India competition organized by E-Cell IIT Bombay to transform college campuses into thriving startup hubs.
                            </p>
                            <div className="mt-2 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
                              <span className="text-emerald-400 font-bold">● Live Representation</span>
                              <span>Click to read full details</span>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </motion.div>
                </div>

                {/* Right Column: Arjuna Image */}
                <motion.div
                  variants={itemVariants}
                  className="lg:col-span-5 flex items-center justify-center relative mt-4 lg:mt-0"
                >
                  <div className="relative group w-full max-w-xs sm:max-w-sm lg:max-w-md mx-auto">
                    {/* Glowing background aura */}
                    <div className="absolute -inset-4 bg-gradient-to-r from-blue-600/20 via-orange-500/20 to-blue-600/20 rounded-full blur-2xl opacity-70 group-hover:opacity-100 transition duration-700"></div>

                    <motion.img
                      animate={{ y: [0, -10, 0] }}
                      transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
                      src="https://i.ibb.co/3yd9f03z/new-arjuna-removebg-preview.png"
                      alt="new arjuna removebg preview"
                      referrerPolicy="no-referrer"
                      className="relative z-10 max-h-[400px] sm:max-h-[460px] w-auto mx-auto object-contain drop-shadow-[0_20px_35px_rgba(13,59,140,0.3)]"
                    />
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* OUR STORY: THE SPIRIT OF ARJUNA SECTION */}
      <OurStorySection />

      {/* EXPLORE CORE DOMAINS SECTION */}
      <ExploreDomains3D />

      {/* BUILD YOUR STARTUP PITCH SECTION */}
      <BuildYourPitch />

      {/* OUR MISSION & OUR VISION SECTION */}
      <section className="py-20 bg-transparent overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: -40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="text-center max-w-3xl mx-auto mb-14"
          >
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Our Mission & Vision
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-2">
              Driven by purpose and engineered for excellence, empowering campus ventures from ideation to scale.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Our Mission Card - Slide from Left */}
            <motion.div
              initial={{ opacity: 0, x: -70 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -6 }}
              className="geo-card rounded-3xl p-8 border border-white/80 bg-white/50 backdrop-blur-xl relative space-y-4 shadow-xl shadow-blue-950/5"
            >
              <div className="p-3.5 rounded-2xl bg-orange-100 text-[#EA580C] border border-orange-200/80 inline-block shadow-md shadow-orange-500/10">
                <Target className="w-7 h-7" />
              </div>
              <h3 className="text-2xl font-extrabold text-slate-900">Our Mission</h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                To cultivate an entrepreneurial mindset by empowering students to innovate with purpose, collaborate with confidence, and transform ideas into solutions that create lasting impact.
              </p>
              <ul className="space-y-2 text-xs text-slate-700 pt-2 border-t border-slate-100">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-slate-800 shrink-0" />
                  <span>Establish 100% student founder coverage across departments</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-slate-800 shrink-0" />
                  <span>Facilitate campus startup grants & angel pitch sessions</span>
                </li>
              </ul>
            </motion.div>

            {/* Our Vision Card - Slide from Right */}
            <motion.div
              initial={{ opacity: 0, x: 70 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -6 }}
              className="geo-card rounded-3xl p-8 border border-white/80 bg-white/50 backdrop-blur-xl relative space-y-4 shadow-xl shadow-blue-950/5"
            >
              <div className="p-3.5 rounded-2xl bg-orange-100 text-[#EA580C] border border-orange-200/80 inline-block shadow-md shadow-orange-500/10">
                <Compass className="w-7 h-7" />
              </div>
              <h3 className="text-2xl font-extrabold text-slate-900">Our Vision</h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                To build a thriving ecosystem of student innovators and future founders, making VijaySarthi Arjuna a benchmark for entrepreneurship, leadership, and innovation at GHRCE and beyond.
              </p>
              <ul className="space-y-2 text-xs text-slate-700 pt-2 border-t border-slate-100">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-slate-800 shrink-0" />
                  <span>Secure top national ranking at IIT Bombay NEC 2026</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-slate-800 shrink-0" />
                  <span>Nurture sustainable startups creating long-term employment</span>
                </li>
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      {/* MOTIVATIONAL QUOTE BANNER SECTION */}
      <section className="py-12 bg-transparent overflow-hidden">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="rounded-3xl bg-[#0F172A] p-8 sm:p-12 md:p-16 text-center border border-slate-800 shadow-2xl shadow-slate-950/20 relative overflow-hidden"
          >
            {/* Subtle background glow */}
            <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 max-w-4xl mx-auto space-y-6">
              {/* Quote Icon */}
              <div className="flex justify-center">
                <Quote className="w-8 h-8 sm:w-10 sm:h-10 text-[#F97316] fill-[#F97316]/20 rotate-180" />
              </div>

              {/* Quote Text */}
              <div className="space-y-3 text-xl sm:text-2xl md:text-3xl font-extrabold tracking-tight leading-snug sm:leading-relaxed">
                <p className="text-[#F97316]">
                  &ldquo;We&apos;re not defined by the competition we enter, but by the legacy we choose to build.&rdquo;
                </p>
                <p className="text-white text-base sm:text-xl font-bold">
                  Representing GHRCE at the National Entrepreneurship Challenge 2026.
                </p>
              </div>

              {/* Quote Author */}
              <p className="text-xs sm:text-sm font-semibold text-slate-400 uppercase tracking-widest pt-4 flex items-center justify-center gap-2">
                <span className="text-slate-500 font-normal text-xs opacity-60">-</span>
                <span>
                  TEAM <strong className="font-black text-white text-sm sm:text-base tracking-widest drop-shadow-sm">VIJAYSARTHI ARJUNA</strong> • GHRCE NAGPUR
                </span>
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* OUR ORGANIZING PARTNERS SECTION */}
      <OrganizingPartnersSection />

      {/* FAQ SECTION */}
      <section className="py-16 bg-transparent overflow-hidden">
        <div className="max-w-2xl mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="text-center mb-8 space-y-2"
          >
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Frequently Asked Questions
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 font-medium">
              Quick answers to help you understand our journey and initiatives
            </p>
          </motion.div>

          {/* Search Input - Compact & Centered */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="relative mb-5 max-w-xl mx-auto"
          >
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={faqSearch}
              onChange={(e) => setFaqSearch(e.target.value)}
              placeholder="Search questions about NEC 2026, team, submissions..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/90 backdrop-blur-md border border-slate-200 text-slate-900 text-xs sm:text-sm focus:outline-none focus:border-[#0D3B8C] transition-colors shadow-sm"
            />
          </motion.div>

          {/* Animated Accordion List - Compact & Centered */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-2.5 max-w-xl mx-auto"
          >
            {filteredFaqs.map((faq) => {
              const isExpanded = expandedFaqId === faq.id;
              return (
                <div
                  key={faq.id}
                  className={`border rounded-xl overflow-hidden transition-all duration-300 ${
                    isExpanded
                      ? 'border-[#0D3B8C] bg-white shadow-md ring-2 ring-blue-500/10'
                      : 'border-slate-200/90 bg-white/80 hover:bg-white'
                  }`}
                >
                  <button
                    onClick={() => setExpandedFaqId(isExpanded ? null : faq.id)}
                    className="w-full p-3.5 sm:p-4 text-left font-bold text-xs sm:text-sm text-slate-900 flex items-center justify-between gap-3 transition-colors"
                  >
                    <span>{faq.question}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-slate-500 shrink-0 transition-transform duration-300 ${
                        isExpanded ? 'rotate-180 text-[#0D3B8C]' : ''
                      }`}
                    />
                  </button>
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.25 }}
                        className="px-3.5 pb-3.5 pt-1 sm:px-4 sm:pb-4 text-xs text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/60"
                      >
                        {faq.answer}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* TERMINAL CONTACT SECTION */}
      <TerminalContact />
    </div>
  );
};

