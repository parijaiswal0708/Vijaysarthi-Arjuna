import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext';
import {
  CircuitBoard,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  Target,
  Award,
  Calendar,
  ChevronRight,
  TrendingUp,
  Download,
  Zap,
  Activity,
  ChevronLeft,
  RotateCcw
} from 'lucide-react';

export const NECJourney: React.FC = () => {
  const { milestones, setCurrentRoute } = useApp();

  const [selectedMilestoneId, setSelectedMilestoneId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<'All' | 'Completed' | 'Under Evaluation' | 'Upcoming'>('All');
  const [flippedIds, setFlippedIds] = useState<string[]>([]);

  const toggleFlip = (id: string) => {
    setFlippedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Ref for horizontal scroll container
  const horizontalScrollRef = useRef<HTMLDivElement>(null);

  const filteredMilestones = milestones.filter((m) =>
    filterStatus === 'All' ? true : m.status === filterStatus
  );

  const completedCount = milestones.filter((m) => m.status === 'Completed').length;
  const progressPercent = Math.round((completedCount / milestones.length) * 100);

  const scrollHorizontal = (direction: 'left' | 'right') => {
    if (horizontalScrollRef.current) {
      const scrollAmount = direction === 'left' ? -300 : 300;
      horizontalScrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-transparent pt-28 pb-20 overflow-x-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Title with Animated Circuit Badge */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-100/90 border border-blue-200/90 text-xs font-bold text-[#0D3B8C] uppercase tracking-wider mb-4 shadow-sm"
          >
            
            <span>THE ROAD TO IIT BOMBAY</span>
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight"
          >
            From Campus Ambition to National Impact
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xs sm:text-sm text-slate-600 mt-3 leading-relaxed"
          >
            This is more than our competition timeline - it's the story of how VijaySarthi 
Arjuna is transforming ideas into action through the National Entrepreneurship 
Challenge, one milestone at a time
          </motion.p>
        </div>

        {/* Target Completion Progress Matrix Card */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="max-w-4xl mx-auto mb-10 bg-white/90 backdrop-blur-xl p-5 sm:p-7 rounded-3xl border border-slate-200/90 shadow-xl shadow-slate-900/5 relative overflow-hidden"
        >
          {/* Subtle ambient background glow */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl pointer-events-none" />

          {/* Top Row: Title + Subcards */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 relative z-10">
            {/* Left Header */}
            <div className="text-left">
              <div className="flex items-center gap-1.5 text-[#0D3B8C] font-extrabold text-[10px] sm:text-xs tracking-wider uppercase mb-1">
                <Sparkles className="w-3.5 h-3.5 text-[#F97316] animate-pulse" />
                <span>SCROLL-TRIGGERED PROGRESS MATRIX</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                GHRCE Target Completion Status
              </h3>
            </div>

            {/* Right Sub-Cards */}
            <div className="flex items-center gap-3 self-start sm:self-center">
              {/* Sub-Card 1: Phases Cleared */}
              <div className="bg-emerald-50/80 border border-emerald-300/80 rounded-2xl px-4 py-2.5 sm:px-5 sm:py-3 text-center min-w-[110px] shadow-xs">
                <div className="text-xl sm:text-2xl font-black text-emerald-800 leading-none">
                  {completedCount}/{milestones.length}
                </div>
                <div className="text-[9px] sm:text-[10px] font-extrabold text-emerald-700 uppercase tracking-wider mt-1">
                  PHASES CLEARED
                </div>
              </div>

              {/* Sub-Card 2: Total Progress */}
              <div className="bg-blue-50/80 border border-blue-300/80 rounded-2xl px-4 py-2.5 sm:px-5 sm:py-3 text-center min-w-[110px] shadow-xs">
                <div className="text-xl sm:text-2xl font-black text-blue-900 leading-none">
                  {progressPercent}%
                </div>
                <div className="text-[9px] sm:text-[10px] font-extrabold text-blue-700 uppercase tracking-wider mt-1">
                  TOTAL PROGRESS
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Progress Bar */}
          <div className="relative w-full h-3 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200/80 shadow-inner">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progressPercent}%` }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
              className="h-full bg-gradient-to-r from-[#0D3B8C] via-blue-500 to-[#F97316] rounded-full shadow-sm"
            />
          </div>
        </motion.div>



        {/* 4. FILTER STATUS TABS & REPORT DOWNLOAD */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-10">
          <div className="flex items-center gap-2 bg-white/90 backdrop-blur-md p-1.5 rounded-2xl border border-slate-200 shadow-xs">
            {(['All', 'Completed', 'Under Evaluation', 'Upcoming'] as const).map((status) => (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={`px-4 py-2 rounded-xl text-xs font-extrabold transition-all ${
                  filterStatus === status
                    ? 'bg-[#0D3B8C] text-white shadow-md'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {status}
              </button>
            ))}
          </div>

          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setCurrentRoute('resources')}
            className="px-4 py-2.5 rounded-xl bg-white/90 backdrop-blur-md border border-slate-300 text-slate-800 text-xs font-bold hover:border-[#0D3B8C] shadow-xs transition-all flex items-center gap-2"
          >
            <Download className="w-4 h-4 text-[#F97316]" />
            <span>Download Submission Reports</span>
          </motion.button>
        </div>

        {/* 5. CONNECTED MILESTONES VERTICAL TIMELINE WITH COMPACT ANIMATED CARDS */}
        <div className="relative pl-8 md:pl-12 space-y-6 max-w-4xl mx-auto">
          {/* Animated Connecting Line running through all items */}
          <div className="absolute left-4 md:left-6 top-6 bottom-6 w-1 bg-slate-200 rounded-full -z-10">
            <motion.div
              initial={{ height: 0 }}
              whileInView={{ height: '100%' }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, ease: 'easeInOut' }}
              className="w-full bg-gradient-to-b from-[#0D3B8C] via-blue-500 to-[#F97316] rounded-full shadow-sm"
            ></motion.div>
          </div>

          {filteredMilestones.map((m, index) => {
            const isCompleted = m.status === 'Completed';
            const isUnderEvaluation = m.status === 'Under Evaluation';
            const isOngoing = m.status === 'Ongoing';

            const containerVariants = {
              hidden: { opacity: 0, y: 30, scale: 0.97 },
              visible: {
                opacity: 1,
                y: 0,
                scale: 1,
                transition: {
                  duration: 0.5,
                  ease: [0.22, 1, 0.36, 1],
                }
              }
            };

            return (
              <motion.div
                key={m.id}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: '-40px' }}
                variants={containerVariants}
                className="relative"
              >
                {/* Circuit Node Icon */}
                <motion.div
                  whileHover={{ scale: 1.2, rotate: 180 }}
                  transition={{ type: 'spring', stiffness: 300 }}
                  className={`absolute -left-8 md:-left-12 top-5 w-7 h-7 rounded-full border-2 flex items-center justify-center z-20 cursor-pointer transition-all duration-300 ${
                    isCompleted
                      ? 'bg-[#0D3B8C] border-blue-200 text-white shadow-md shadow-blue-600/20'
                      : isUnderEvaluation || isOngoing
                      ? 'bg-[#F97316] border-orange-200 text-white shadow-lg shadow-orange-500/30 animate-pulse'
                      : 'bg-white border-slate-300 text-slate-400'
                  }`}
                >
                  {isCompleted ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                  ) : isUnderEvaluation || isOngoing ? (
                    <Clock className="w-3.5 h-3.5 text-white animate-spin" />
                  ) : (
                    <div className="w-2 h-2 rounded-full bg-slate-300"></div>
                  )}
                </motion.div>

                {/* Compact Milestone Card Container */}
                <motion.div
                  whileHover={{
                    y: -3,
                    boxShadow: '0 20px 40px -15px rgba(13, 59, 140, 0.12)'
                  }}
                  transition={{ type: 'spring', stiffness: 350, damping: 25 }}
                  className={`geo-card rounded-2xl p-5 sm:p-6 backdrop-blur-2xl border relative overflow-hidden transition-all duration-300 group ${
                    isCompleted
                      ? 'bg-white/95 border-slate-200/90 shadow-md hover:border-blue-200'
                      : isUnderEvaluation || isOngoing
                      ? 'bg-white/95 border-[#F97316] ring-2 ring-orange-500/30 shadow-lg shadow-orange-500/10'
                      : 'bg-white/90 border-slate-200/80 shadow-xs'
                  }`}
                >
                  <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5 relative z-10">
                    {/* Left Side: Title, Phase Tag & Description */}
                    <div className="space-y-2 flex-1 min-w-0">
                      {/* Phase Tag & Date */}
                      <div className="flex items-center gap-2 flex-wrap text-xs">
                        <span className="font-mono font-extrabold text-[#0D3B8C] uppercase tracking-wider bg-blue-50/90 px-2.5 py-0.5 rounded-md border border-blue-200/80">
                          {m.phase}
                        </span>
                        <span className="text-slate-300 font-bold">•</span>
                        <span className="font-bold text-slate-500 flex items-center gap-1 text-xs">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          {m.date}
                        </span>
                      </div>

                      {/* Title & Status Badge */}
                      <div className="flex items-center gap-3 flex-wrap">
                        <h3 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
                          {m.title}
                        </h3>
                        <span
                          className={`text-[10px] sm:text-xs px-2.5 py-0.5 rounded-full font-extrabold uppercase tracking-wider ${
                            isCompleted
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              : isUnderEvaluation || isOngoing
                              ? 'bg-orange-100 text-[#EA580C] border border-orange-200 animate-pulse'
                              : 'bg-slate-100 text-slate-600 border border-slate-200'
                          }`}
                        >
                          {m.status}
                        </span>
                      </div>

                      {/* Description */}
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-medium max-w-xl">
                        {m.description}
                      </p>
                    </div>

                    {/* Right Side: Key Deliverables Panel */}
                    {m.deliverables && m.deliverables.length > 0 && (
                      <div className="w-full lg:w-72 shrink-0 bg-slate-50/80 rounded-2xl p-3.5 sm:p-4 border border-slate-200/80 space-y-2">
                        <div className="flex items-center justify-between border-b border-slate-200/70 pb-2">
                          <span className="text-xs font-bold text-slate-800 tracking-tight">
                            Key Deliverables
                          </span>
                          {m.impactScore && (
                            <span className="text-[#0D3B8C] font-mono text-[11px] font-extrabold flex items-center gap-1">
                              <TrendingUp className="w-3 h-3 text-[#F97316]" />
                              Score: <strong className="text-[#0D3B8C]">{m.impactScore}/100</strong>
                            </span>
                          )}
                        </div>

                        <ul className="space-y-1.5">
                          {m.deliverables.map((item, dIdx) => (
                            <li key={dIdx} className="flex items-start gap-2 text-xs text-slate-700 font-medium leading-snug">
                              <CheckCircle2 className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${
                                isCompleted ? 'text-emerald-600' : 'text-slate-400'
                              }`} />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>

                        {/* Evaluation Status Block */}
                        {isUnderEvaluation && (
                          <div className="mt-3 pt-2.5 border-t border-slate-200/80 space-y-1 bg-orange-50/50 -mx-3.5 -mb-3.5 p-3 rounded-b-2xl">
                            <span className="text-[10px] font-extrabold text-[#0D3B8C] uppercase tracking-wider block">
                              Evaluation status
                            </span>
                            <div className="text-xs font-black text-slate-900">
                              730 Marks (Maximum Score)
                            </div>
                            <div className="text-[11px] font-medium text-orange-600 flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5 animate-spin shrink-0 text-[#F97316]" />
                              <span>Current Status : Under Evaluation by the NEC Review Committe</span>
                            </div>
                          </div>
                        )}

                        {m.status === 'Upcoming' && (
                          <div className="mt-3 pt-2.5 border-t border-slate-200/80 space-y-1 bg-blue-50/40 -mx-3.5 -mb-3.5 p-3 rounded-b-2xl">
                            <span className="text-[10px] font-extrabold text-[#0D3B8C] uppercase tracking-wider block">
                              Evaluation Status
                            </span>
                            <div className="text-xs font-black text-slate-800">
                              {m.id === 'm-5' || m.phase.includes('Grand Finale') ? 'Result:' : 'Score:'} <span className="font-extrabold text-[#0D3B8C]">To Be Announced</span>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </motion.div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};


