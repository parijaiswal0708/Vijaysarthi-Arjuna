import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import {
  Users,
  Linkedin,
  Instagram,
  Mail,
  Sparkles,
  Shield,
  Award,
  RotateCw
} from 'lucide-react';
import { TeamMember } from '../types';

export const Team: React.FC = () => {
  const { teamMembers } = useApp();

  const coreTeam = teamMembers.filter((m) => m.category === 'core');
  const domainLeads = teamMembers.filter((m) => m.category === 'domain');
  const otherMembers = teamMembers.filter((m) => m.category === 'member');

  // Flipped card state for tap interactions on touch devices
  const [flippedCardIds, setFlippedCardIds] = useState<Record<string, boolean>>({});

  const toggleFlip = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setFlippedCardIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const formatUrl = (url: string) => {
    if (!url) return '#';
    if (url.startsWith('http://') || url.startsWith('https://') || url.startsWith('mailto:')) {
      return url;
    }
    return `https://${url}`;
  };

  const renderMemberCard = (member: TeamMember, isCore = false) => {
    const isFlipped = !!flippedCardIds[member.id];

    return (
      <motion.div
        key={member.id}
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-40px' }}
        transition={{ duration: 0.4 }}
        className="w-full flex flex-col items-center group cursor-pointer"
        onClick={() => toggleFlip(member.id)}
        aria-label={`Team member card for ${member.name}, ${member.role}`}
      >
        {/* Minimalistic Lanyard Strap & Metallic Clip */}
        <div className="w-full flex flex-col items-center z-20 -mb-2 pointer-events-none">
          <div className="w-5 h-5 bg-gradient-to-b from-slate-800 via-[#0D3B8C] to-slate-700 rounded-t-xs shadow-inner opacity-90"></div>
          <div className="w-8 h-2.5 bg-gradient-to-r from-slate-300 via-slate-100 to-slate-400 rounded-md border border-slate-400/90 shadow-xs z-30 flex items-center justify-center">
            <div className="w-3 h-0.5 bg-slate-600 rounded-full"></div>
          </div>
        </div>

        {/* 3D Flip Container */}
        <div className="perspective-1000 w-full h-[390px] relative">
          <div
            className={`relative w-full h-full transform-style-3d flip-transition group-hover:rotate-y-180 ${
              isFlipped ? 'rotate-y-180' : ''
            }`}
          >
            {/* FRONT SIDE OF ID CARD */}
            <div className="absolute inset-0 w-full h-full backface-hidden rounded-2xl bg-white border border-slate-300/80 shadow-lg group-hover:shadow-2xl transition-all duration-300 flex flex-col justify-between overflow-hidden pt-3 pb-4 px-5">
              {/* Lanyard Slot Hole Cutout */}
              <div className="absolute top-2 left-1/2 -translate-x-1/2 w-8 h-2 rounded-full bg-slate-200 border border-slate-300/90 shadow-inner z-20 pointer-events-none"></div>

              {/* Watermark Grid */}
              <div className="absolute inset-0 bg-[radial-gradient(#0D3B8C_0.5px,transparent_0.5px)] [background-size:12px_12px] opacity-[0.03] pointer-events-none"></div>
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-blue-600/10 via-transparent to-transparent pointer-events-none"></div>

              {/* College Header Bar */}
              <div className="w-full mt-3 pt-2 pb-1.5 px-3 rounded-lg bg-gradient-to-r from-[#0D3B8C] via-[#1E40AF] to-[#0D3B8C] text-white flex items-center justify-between shadow-xs z-10">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-[#F97316] animate-pulse"></div>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider font-mono">GHRCE • IIT BOMBAY NEC</span>
                </div>
                <span className="text-[9px] font-mono text-blue-200 font-semibold px-1.5 py-0.5 rounded bg-white/10">ID: 2026-NEC</span>
              </div>

              {/* ID Photo & Identity Details ONLY (Photo, Name, Post, Department, Year) */}
              <div className="flex flex-col items-center justify-center my-auto z-10 text-center py-2 space-y-2">
                <div className="relative mb-1">
                  <div className="p-1 rounded-2xl bg-gradient-to-b from-slate-200 to-slate-100 border border-slate-300 shadow-md">
                    <img
                      src={member.image}
                      alt={member.name}
                      className={`rounded-xl object-cover border border-slate-200 transition-transform duration-300 ${
                        isCore ? 'w-28 h-28 sm:w-32 sm:h-32' : 'w-24 h-24 sm:w-28 sm:h-28'
                      }`}
                    />
                  </div>
                  {isCore && (
                    <div className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-[#F97316] text-white shadow-md z-20 border-2 border-white" title="Core Member">
                      <Award className="w-4 h-4" />
                    </div>
                  )}
                </div>

                <div className="space-y-1.5 w-full px-1">
                  <h3 className="text-lg font-extrabold text-slate-900 leading-snug truncate">
                    {member.name}
                  </h3>
                  <p className="text-xs sm:text-sm font-bold text-[#F97316] tracking-wide">{member.role}</p>
                  <div className="flex items-center justify-center gap-2 pt-1">
                    <span className="px-2.5 py-0.5 rounded-md bg-blue-50 border border-blue-200 text-[#0D3B8C] text-xs font-bold uppercase tracking-wider">
                      {member.department}
                    </span>
                    {member.year && (
                      <span className="text-xs text-slate-500 font-medium font-mono px-2 py-0.5 rounded bg-slate-100 border border-slate-200">
                        {member.year}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Front Footer: Flip Hint */}
              <div className="z-10 pt-2 border-t border-slate-200/90 w-full flex items-center justify-center mt-auto">
                <div className="flex items-center gap-1.5 text-[10px] font-bold text-[#0D3B8C] uppercase tracking-wider bg-blue-50 px-3 py-1 rounded-full border border-blue-200/80">
                  <RotateCw className="w-3.5 h-3.5 text-[#F97316]" />
                  <span>Hover / Tap to flip card</span>
                </div>
              </div>
            </div>

            {/* BACK SIDE OF ID CARD (Description and Social Links ONLY) */}
            <div className="absolute inset-0 w-full h-full backface-hidden rotate-y-180 rounded-2xl bg-gradient-to-b from-slate-900 via-[#0D3B8C] to-slate-950 text-white border border-slate-700/80 shadow-2xl flex flex-col justify-between overflow-hidden pt-4 pb-5 px-5 z-20 pointer-events-auto">
              {/* Lanyard Slot Hole Cutout */}
              <div className="absolute top-2 left-1/2 -translate-x-1/2 w-8 h-2 rounded-full bg-slate-800 border border-slate-700 z-20 pointer-events-none"></div>

              {/* Watermark Grid Back */}
              <div className="absolute inset-0 bg-[radial-gradient(#F97316_0.5px,transparent_0.5px)] [background-size:12px_12px] opacity-[0.05] pointer-events-none"></div>

              {/* Back Header Badge */}
              <div className="w-full mt-2 pt-1.5 pb-1 px-3 rounded-lg bg-white/10 backdrop-blur-md text-white flex items-center justify-between border border-white/10 shadow-xs z-10">
                <span className="text-[10px] font-extrabold uppercase tracking-wider font-mono text-orange-400">
                  ABOUT {member.name.split(' ')[0]}
                </span>
                <span className="text-[9px] font-mono text-slate-300 font-semibold px-1.5 py-0.5 rounded bg-black/20">
                  {member.role}
                </span>
              </div>

              {/* Full Description Box */}
              <div className="z-10 w-full my-auto flex-1 flex items-center py-2">
                <div className="w-full h-full max-h-[200px] p-3.5 rounded-xl bg-slate-900/90 border border-slate-700/80 text-xs sm:text-sm text-slate-200 leading-relaxed text-left font-normal overflow-y-auto shadow-inner">
                  <p>{member.description}</p>
                </div>
              </div>

              {/* Social Media Handles Row - Clickable Links */}
              <div className="z-30 pt-3 border-t border-slate-800/80 w-full relative pointer-events-auto">
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest text-center mb-2 font-mono">
                  CONNECT WITH {member.name.split(' ')[0].toUpperCase()}
                </p>
                <div className="grid grid-cols-3 gap-2">
                  {member.linkedin ? (
                    <a
                      href={formatUrl(member.linkedin)}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-[#0D3B8C] border border-slate-700 hover:border-blue-500 text-slate-200 hover:text-white transition-all flex items-center justify-center gap-1.5 text-xs font-bold shadow-md hover:scale-105 active:scale-95 cursor-pointer z-30"
                      title="LinkedIn Profile"
                    >
                      <Linkedin className="w-4 h-4 text-blue-400 shrink-0" />
                      <span>LinkedIn</span>
                    </a>
                  ) : (
                    <span className="p-2 rounded-xl bg-slate-800/40 border border-slate-800 text-slate-500 flex items-center justify-center gap-1.5 text-xs font-bold opacity-50 cursor-not-allowed">
                      <Linkedin className="w-4 h-4" />
                      <span>N/A</span>
                    </span>
                  )}

                  {member.instagram ? (
                    <a
                      href={formatUrl(member.instagram)}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-[#F97316] border border-slate-700 hover:border-orange-500 text-slate-200 hover:text-white transition-all flex items-center justify-center gap-1.5 text-xs font-bold shadow-md hover:scale-105 active:scale-95 cursor-pointer z-30"
                      title="Instagram Profile"
                    >
                      <Instagram className="w-4 h-4 text-pink-400 shrink-0" />
                      <span>Insta</span>
                    </a>
                  ) : (
                    <span className="p-2 rounded-xl bg-slate-800/40 border border-slate-800 text-slate-500 flex items-center justify-center gap-1.5 text-xs font-bold opacity-50 cursor-not-allowed">
                      <Instagram className="w-4 h-4" />
                      <span>N/A</span>
                    </span>
                  )}

                  {member.email ? (
                    <a
                      href={`mailto:${member.email}`}
                      onClick={(e) => e.stopPropagation()}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-emerald-600 border border-slate-700 hover:border-emerald-500 text-slate-200 hover:text-white transition-all flex items-center justify-center gap-1.5 text-xs font-bold shadow-md hover:scale-105 active:scale-95 cursor-pointer z-30"
                      title="Send Email"
                    >
                      <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>Email</span>
                    </a>
                  ) : (
                    <span className="p-2 rounded-xl bg-slate-800/40 border border-slate-800 text-slate-500 flex items-center justify-center gap-1.5 text-xs font-bold opacity-50 cursor-not-allowed">
                      <Mail className="w-4 h-4" />
                      <span>N/A</span>
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="min-h-screen bg-transparent pt-28 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title Section */}
        <div className="text-center max-w-4xl mx-auto mb-16 space-y-3">
          {/* Blue Cylinder Pill */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-100/90 border border-blue-300/80 text-[#0D3B8C] shadow-xs">
            <Users className="w-4 h-4 text-[#0D3B8C]" />
            <span className="text-xs sm:text-sm font-extrabold tracking-wider uppercase">
              THE PEOPLE BEHIND THE JOURNEY
            </span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight">
            Meet Team Vijaysarthi Arjuna
          </h1>

          <p className="text-sm sm:text-base font-bold text-[#0D3B8C] max-w-2xl mx-auto leading-snug">
            A team united by purpose, driven by innovation, and committed to representing GHRCE at the National Entrepreneurship Challenge 2026.
          </p>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-3xl mx-auto pt-1">
            Behind every milestone is a team of passionate students who believe in creating impact through innovation and collaboration. VijaySarthi Arjuna brings together aspiring entrepreneurs, designers, developers, strategists, researchers, and creators—each contributing their expertise toward one shared mission: representing G.H. Raisoni College of Engineering, Nagpur, on the national stage at IIT Bombay's National Entrepreneurship Challenge 2026.
          </p>
        </div>

        {/* CORE TEAM (4 Members - 2x2 Layout) */}
        <div className="mb-16">
          <div className="flex items-start gap-3 mb-8">
            <div className="p-2 rounded-2xl bg-blue-50 border border-blue-200 text-[#0D3B8C] shadow-xs mt-1 shrink-0">
              <Shield className="w-5 h-5 text-[#0D3B8C]" />
            </div>
            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                Core Leadership
              </h2>
              <p className="text-sm font-bold text-[#0D3B8C] mt-0.5">
                Leading with Vision. Building with Purpose.
              </p>
              <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-3xl leading-relaxed">
                The Core Leadership Team drives the strategic direction of VijaySarthi Arjuna, ensuring every initiative, decision, and milestone aligns with our mission. They coordinate cross-functional teams, oversee execution, and foster collaboration throughout our NEC journey.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {coreTeam.map((member) => renderMemberCard(member, true))}
          </div>
        </div>

        {/* DOMAIN LEADS (9 Members Grid) */}
        <div className="mb-16">
          <div className="flex items-start gap-3 mb-8">
            <div className="p-2 rounded-2xl bg-orange-50 border border-orange-200 text-[#F97316] shadow-xs mt-1 shrink-0">
              <Sparkles className="w-5 h-5 text-[#F97316]" />
            </div>
            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                Domain Leads
              </h2>
              <p className="text-sm font-bold text-[#F97316] mt-0.5">
                Specialized Minds. One Shared Mission.
              </p>
              <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-3xl leading-relaxed">
                Each domain is led by individuals with dedicated expertise, enabling our team to innovate across technology, branding, research, documentation, outreach, finance, operations, and entrepreneurship. Together, they transform ideas into impactful execution.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {domainLeads.map((member) => renderMemberCard(member, false))}
          </div>
        </div>

        {/* ADDITIONAL MEMBERS & VOLUNTEERS */}
        {otherMembers.length > 0 && (
          <div>
            <div className="flex items-start gap-3 mb-8">
              <div className="p-2 rounded-2xl bg-slate-100 border border-slate-200 text-slate-700 shadow-xs mt-1 shrink-0">
                <Users className="w-5 h-5 text-slate-700" />
              </div>
              <div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                  Team Associates
                </h2>
                <p className="text-sm font-bold text-slate-800 mt-0.5">
                  The Strength Behind Every Success.
                </p>
                <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-3xl leading-relaxed">
                  From content creation and design to development, documentation, media, and event execution, our associates ensure every project is delivered with excellence. Their commitment turns planning into action and ideas into measurable outcomes.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {otherMembers.map((member) => renderMemberCard(member, false))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

